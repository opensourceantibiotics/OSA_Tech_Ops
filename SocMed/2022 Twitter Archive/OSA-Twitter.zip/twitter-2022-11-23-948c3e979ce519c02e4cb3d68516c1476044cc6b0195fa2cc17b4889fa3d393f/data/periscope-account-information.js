window.YTD.periscope_account_information.part0 = [
  {
    "periscopeAccountInformation" : {
      "displayName" : "OSantibiotics",
      "digitsId" : "",
      "username" : "OSantibiotics",
      "twitterId" : "1111629854716428290",
      "id" : "1ayjVqbmpJqKp",
      "twitterScreenName" : "OSantibiotics",
      "isTwitterUser" : true,
      "createdAt" : "2021-01-31T13:58:23.961595354Z"
    }
  }
]