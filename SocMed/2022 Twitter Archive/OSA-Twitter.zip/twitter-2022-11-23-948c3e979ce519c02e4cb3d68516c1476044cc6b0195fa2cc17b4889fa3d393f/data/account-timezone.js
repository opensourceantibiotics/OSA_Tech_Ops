window.YTD.account_timezone.part0 = [
  {
    "accountTimezone" : {
      "accountId" : "1111629854716428290"
    }
  }
]