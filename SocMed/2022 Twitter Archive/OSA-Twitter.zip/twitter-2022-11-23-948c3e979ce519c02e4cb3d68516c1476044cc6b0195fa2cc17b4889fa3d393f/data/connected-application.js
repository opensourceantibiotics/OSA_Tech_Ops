window.YTD.connected_application.part0 = [
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Twitter, Inc.",
        "url" : ""
      },
      "name" : "Twitter for Android",
      "description" : "Twitter for Android",
      "permissions" : [
        "read",
        "write"
      ],
      "approvedAt" : "2021-01-30T22:15:15.000Z",
      "id" : "258901"
    }
  },
  {
    "connectedApplication" : {
      "organization" : {
        "name" : "Tapbots LLC",
        "url" : "https://tapbots.com/",
        "privacyPolicyUrl" : "https://tapbots.net/tweetbot4/privacy/"
      },
      "name" : "Tweetbot for Mac",
      "description" : "A Twitter client for Mac.",
      "permissions" : [
        "read",
        "write",
        "directmessages"
      ],
      "approvedAt" : "2019-03-29T15:11:54.000Z",
      "id" : "777317"
    }
  }
]