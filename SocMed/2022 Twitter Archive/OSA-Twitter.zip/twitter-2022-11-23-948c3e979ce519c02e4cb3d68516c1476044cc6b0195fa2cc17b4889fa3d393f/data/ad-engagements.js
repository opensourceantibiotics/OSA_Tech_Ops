window.YTD.ad_engagements.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92348",
                  "name" : "#capitalcom",
                  "description" : "Trade CFDs on #Capitalcom"
                },
                "advertiserInfo" : {
                  "advertiserName" : "Capital.com Worldwide",
                  "screenName" : "@capitalcom"
                },
                "impressionTime" : "2022-11-18 16:47:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-18 16:47:10",
                  "engagementType" : "TrendView"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1567520641322205188",
                  "tweetText" : "RT @BloombergUK: These are the world's most (and least) powerful passports.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bloomberg",
                  "screenName" : "@business"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@BBCNews"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@nytimes"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@TIME"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@FT"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@FinancialTimes"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@guardian"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@WSJ"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@TheEconomist"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@Reuters"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "AIQ_276401_0_1"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Bloomberg: Business News Daily IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Bloomberg: Finance Market News ANDROID All"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "AIQ_271882_0_1 - Active Subs"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2022-11-18 16:47:09"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-18 16:47:12",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1567522909194960904",
                  "tweetText" : "RT @BloombergUK: Never had Covid? You could hold the key to beating the virus — and scientists want to study you.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bloomberg",
                  "screenName" : "@business"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Business & finance"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Government/Education"
                  },
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Personal finance"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Tech news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Space and astronomy"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Science news"
                  },
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Technology"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "AIQ_276401_0_1"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Bloomberg: Business News Daily IOS All"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "AIQ_271882_0_1"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Bloomberg: Finance Market News ANDROID All"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "AIQ_271882_0_1 - Active Subs"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  }
                ],
                "impressionTime" : "2022-11-19 11:00:52"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 11:00:54",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1579201784538484736",
                  "tweetText" : "Discover our indulgent cream formulated to provide all-night hydration, while protecting skin against the ageing effects of inflammation.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Cellular Goods",
                  "screenName" : "@CellularGoods"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  },
                  {
                    "targetingType" : "Gender",
                    "targetingValue" : "Women"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 54"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  }
                ],
                "impressionTime" : "2022-11-19 10:56:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 10:56:46",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1589518477278449664",
                  "tweetText" : "James Fridman, the photoshop master, took some people's requests for edits, and the results made people regret asking him.😱",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "BetterWomanly",
                  "screenName" : "@BWomanly"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  }
                ],
                "impressionTime" : "2022-11-19 10:56:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 10:56:57",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1575416682889224196",
                  "tweetText" : "Questions about cancer and relationships? Join the Online Community today and find support from others who've been there too. 24/7 anonymous support is a click away.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Macmillan Cancer Support",
                  "screenName" : "@macmillancancer"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@CR_UK"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  }
                ],
                "impressionTime" : "2022-11-19 10:56:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 10:56:30",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1567520640877604865",
                  "tweetText" : "RT @BloombergUK: Never had Covid? You could hold the key to beating the virus — and scientists want to study you.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Bloomberg",
                  "screenName" : "@business"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@BBCNews"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@nytimes"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@TIME"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@FT"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@FinancialTimes"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@guardian"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@WSJ"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@TheEconomist"
                  },
                  {
                    "targetingType" : "Follower look-alikes",
                    "targetingValue" : "@Reuters"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "AIQ_276401_0_1"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Bloomberg: Business News Daily IOS All"
                  },
                  {
                    "targetingType" : "App Activity",
                    "targetingValue" : "Purchase Bloomberg: Finance Market News ANDROID All"
                  },
                  {
                    "targetingType" : "List",
                    "targetingValue" : "AIQ_271882_0_1 - Active Subs"
                  },
                  {
                    "targetingType" : "Languages",
                    "targetingValue" : "English"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "18 and up"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  }
                ],
                "impressionTime" : "2022-11-19 10:56:05"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 10:56:08",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1583119859755409408",
                  "tweetText" : "There’s no time like the present — especially with deals like these.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Windows UK",
                  "screenName" : "@WindowsUK"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Conversation topics",
                    "targetingValue" : "Tech news"
                  },
                  {
                    "targetingType" : "Age",
                    "targetingValue" : "25 to 49"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  }
                ],
                "impressionTime" : "2022-11-19 09:22:36"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 09:23:00",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1566792027412566016",
                  "tweetText" : "Introducing the new Snapdragon® 8 Gen 1 mobile processor. At the centre of extraordinary gaming with sharp graphics, fast rendering and long battery life.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "Snapdragon UK",
                  "screenName" : "@Snapdragon_UK"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Interests",
                    "targetingValue" : "Computer gaming"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  },
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  }
                ],
                "impressionTime" : "2022-11-19 09:21:47"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 09:21:49",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            },
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "TimelineHome",
                "promotedTweetInfo" : {
                  "tweetId" : "1574404936020131840",
                  "tweetText" : "Here are some shoes designs that have just gone wrong. Fashion can be stylish and innovative, but nobody can deny that it often crosses over into the world of funny garments at times.",
                  "urls" : [ ],
                  "mediaUrls" : [ ]
                },
                "advertiserInfo" : {
                  "advertiserName" : "WithMyLadies",
                  "screenName" : "@WithMyLadies1"
                },
                "matchedTargetingCriteria" : [
                  {
                    "targetingType" : "Locations",
                    "targetingValue" : "United Kingdom"
                  },
                  {
                    "targetingType" : "Platforms",
                    "targetingValue" : "Desktop"
                  }
                ],
                "impressionTime" : "2022-11-19 09:20:00"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-19 09:23:56",
                  "engagementType" : "ChargeableImpression"
                }
              ]
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adEngagements" : {
          "engagements" : [
            {
              "impressionAttributes" : {
                "deviceInfo" : {
                  "osType" : "Desktop"
                },
                "displayLocation" : "Trends",
                "promotedTrendInfo" : {
                  "trendId" : "92234",
                  "name" : "#SmarterThanASmartTV",
                  "description" : "What happened when Mason Mount was visited by Amelia Dimoldenberg..."
                },
                "advertiserInfo" : {
                  "advertiserName" : "Sky",
                  "screenName" : "@SkyUK"
                },
                "impressionTime" : "2022-11-21 21:46:16"
              },
              "engagementAttributes" : [
                {
                  "engagementTime" : "2022-11-21 21:46:16",
                  "engagementType" : "TrendView"
                }
              ]
            }
          ]
        }
      }
    }
  }
]