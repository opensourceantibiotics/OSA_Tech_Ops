window.YTD.ni_devices.part0 = [
  {
    "niDeviceResponse" : {
      "pushDevice" : {
        "deviceVersion" : "9.65.5-release.0",
        "udid" : "63307aeaf4312c1a",
        "deviceType" : "Twitter for Android",
        "token" : "c4aTxYf4SGO0x6D8xYBKF9:APA91bGh7IA8aVjIu0lnrZI9Sk5czd53WWDJ3q4yrv44aI1aoQazmufScr0VIKG5ol1NvZUnHHEXLXcrPKfTcsasBOPDJwojOzT8duTpLicFr__9qzUgsUDrREBN81p4CyCiqWdPd6B7",
        "updatedDate" : "2022.11.21",
        "createdDate" : "2021.01.30"
      }
    }
  },
  {
    "niDeviceResponse" : {
      "messagingDevice" : {
        "deviceType" : "Auth",
        "carrier" : "o2_uk",
        "phoneNumber" : "+447801958167",
        "createdDate" : "2019.03.29"
      }
    }
  }
]