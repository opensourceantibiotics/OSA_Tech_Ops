window.YTD.tweets.part0 = [
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1595519335858339840"
          ],
          "editableUntil" : "2022-11-23T21:17:07.641Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ethan Mollick",
            "screen_name" : "emollick",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "39125788",
            "id" : "39125788"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1595519335858339840",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1595519335858339840",
      "created_at" : "Wed Nov 23 20:47:07 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @emollick: 🤯Because of Excel, a THIRD of all genetics papers published in top journals have errors, as many genes have names like SEPT2…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1579440293673213953"
          ],
          "editableUntil" : "2022-10-10T12:24:45.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "5",
              "19"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Chris Dowson",
            "screen_name" : "dowson_c",
            "indices" : [
              "180",
              "189"
            ],
            "id_str" : "2804352177",
            "id" : "2804352177"
          },
          {
            "name" : "Atomwise",
            "screen_name" : "AtomwiseInc",
            "indices" : [
              "240",
              "252"
            ],
            "id_str" : "783284048",
            "id" : "783284048"
          },
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "253",
              "261"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "262",
              "275"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/w605NvFRZs",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/90",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "86",
              "109"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1579440293673213953/photo/1",
            "indices" : [
              "276",
              "299"
            ],
            "url" : "https://t.co/RWO1ZhbHXT",
            "media_url" : "http://pbs.twimg.com/media/FetMURlXkAExV4g.png",
            "id_str" : "1579440005524721665",
            "id" : "1579440005524721665",
            "media_url_https" : "https://pbs.twimg.com/media/FetMURlXkAExV4g.png",
            "sizes" : {
              "medium" : {
                "w" : "878",
                "h" : "482",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "373",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "878",
                "h" : "482",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RWO1ZhbHXT"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "20",
              "32"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "299"
      ],
      "favorite_count" : "1",
      "id_str" : "1579440293673213953",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1579440293673213953",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 10 11:54:45 +0000 2022",
      "favorited" : false,
      "full_text" : "Next @OSantibiotics #openscience online meeting is tomorrow, Tuesday, at 2pm UK time. https://t.co/w605NvFRZs. Key discussions on evaluation of *multi-targeting compounds* id'd by @dowson_c team and proposed by Joe Eyermann from NEU and by @AtomwiseInc @1Antruk @Wellcome_AMR https://t.co/RWO1ZhbHXT",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1579440293673213953/photo/1",
            "indices" : [
              "276",
              "299"
            ],
            "url" : "https://t.co/RWO1ZhbHXT",
            "media_url" : "http://pbs.twimg.com/media/FetMURlXkAExV4g.png",
            "id_str" : "1579440005524721665",
            "id" : "1579440005524721665",
            "media_url_https" : "https://pbs.twimg.com/media/FetMURlXkAExV4g.png",
            "sizes" : {
              "medium" : {
                "w" : "878",
                "h" : "482",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "373",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "878",
                "h" : "482",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RWO1ZhbHXT"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1569628577246609408"
          ],
          "editableUntil" : "2022-09-13T10:36:29.761Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "AstraZeneca",
            "screen_name" : "AstraZeneca",
            "indices" : [
              "127",
              "139"
            ],
            "id_str" : "62465691",
            "id" : "62465691"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1569628577246609408",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1569628577246609408",
      "created_at" : "Tue Sep 13 10:06:29 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Looking at latest data from Warwick on potentially multi-targeting inhibitors, shipping of latest variants of @AstraZeneca…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1569624225442414592"
          ],
          "editableUntil" : "2022-09-13T10:19:12.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "8",
              "22"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "208",
              "220"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "221",
              "233"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "234",
              "247"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          },
          {
            "name" : "Yuhang Wang",
            "screen_name" : "EricWan59398945",
            "indices" : [
              "248",
              "264"
            ],
            "id_str" : "1317060137606066177",
            "id" : "1317060137606066177"
          },
          {
            "name" : "Chris Dowson",
            "screen_name" : "dowson_c",
            "indices" : [
              "265",
              "274"
            ],
            "id_str" : "2804352177",
            "id" : "2804352177"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/SsL9PvQZZ4",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/88",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "110",
              "133"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1569624225442414592/photo/1",
            "indices" : [
              "275",
              "298"
            ],
            "url" : "https://t.co/wsaS1kplS0",
            "media_url" : "http://pbs.twimg.com/media/Fchs2NoXEAELV98.png",
            "id_str" : "1569624148766298113",
            "id" : "1569624148766298113",
            "media_url_https" : "https://pbs.twimg.com/media/Fchs2NoXEAELV98.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "323",
                "resize" : "fit"
              },
              "large" : {
                "w" : "750",
                "h" : "356",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "750",
                "h" : "356",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/wsaS1kplS0"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "46",
              "58"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "175",
              "187"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "188",
              "192"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "193",
              "207"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "298"
      ],
      "favorite_count" : "1",
      "id_str" : "1569624225442414592",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1569624225442414592",
      "possibly_sensitive" : false,
      "created_at" : "Tue Sep 13 09:49:12 +0000 2022",
      "favorited" : false,
      "full_text" : "Today's @OSantibiotics meeting is the monthly #OpenScience get together on Series 1, the mur ligases. Agenda: https://t.co/SsL9PvQZZ4. Everyone welcome, particularly newbies. #antibiotics #AMR #drugdiscovery @MatToddChem @LoriFerrins @Wellcome_AMR @EricWan59398945 @dowson_c https://t.co/wsaS1kplS0",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1569624225442414592/photo/1",
            "indices" : [
              "275",
              "298"
            ],
            "url" : "https://t.co/wsaS1kplS0",
            "media_url" : "http://pbs.twimg.com/media/Fchs2NoXEAELV98.png",
            "id_str" : "1569624148766298113",
            "id" : "1569624148766298113",
            "media_url_https" : "https://pbs.twimg.com/media/Fchs2NoXEAELV98.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "323",
                "resize" : "fit"
              },
              "large" : {
                "w" : "750",
                "h" : "356",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "750",
                "h" : "356",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/wsaS1kplS0"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1569417123381772289"
          ],
          "editableUntil" : "2022-09-12T20:36:15.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "140",
              "152"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "18",
              "33"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/lGBJxzWNte",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/tree/master/Student%20Thesis%20and%20Reports",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "47",
              "70"
            ]
          },
          {
            "url" : "https://t.co/5btU64Nl8n",
            "expanded_url" : "https://uk-mynotebook.labarchives.com/share/Giada%2520Sabatino/MC4wfDcyNzYvMC9UcmVlTm9kZS8xMzE2MDQyNDg4fDAuMA==",
            "display_url" : "uk-mynotebook.labarchives.com/share/Giada%25…",
            "indices" : [
              "116",
              "139"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "152"
      ],
      "favorite_count" : "2",
      "id_str" : "1569417123381772289",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1569417123381772289",
      "possibly_sensitive" : false,
      "created_at" : "Mon Sep 12 20:06:15 +0000 2022",
      "favorited" : false,
      "full_text" : "Masters thesis of @GiadasabatinoC now uploaded https://t.co/lGBJxzWNte. Thank you Giada! All data in Giada's ELN at https://t.co/5btU64Nl8n #OpenScience",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1569416554923573248"
          ],
          "editableUntil" : "2022-09-12T20:33:59.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Joαchim Goedhαrt - https://mas.to/@JoachimGoedhart",
            "screen_name" : "joachimgoedhart",
            "indices" : [
              "0",
              "16"
            ],
            "id_str" : "135266269",
            "id" : "135266269"
          },
          {
            "name" : "Egon Willigh☮gen is @egonw@scholar.social",
            "screen_name" : "egonwillighagen",
            "indices" : [
              "17",
              "33"
            ],
            "id_str" : "22911650",
            "id" : "22911650"
          },
          {
            "name" : "Open Source Malaria",
            "screen_name" : "O_S_M",
            "indices" : [
              "34",
              "40"
            ],
            "id_str" : "342023138",
            "id" : "342023138"
          },
          {
            "name" : "Open Source Mycetoma",
            "screen_name" : "MycetOS",
            "indices" : [
              "41",
              "49"
            ],
            "id_str" : "890399794878849024",
            "id" : "890399794878849024"
          },
          {
            "name" : "NFDI4Chem",
            "screen_name" : "NFDI4Chem",
            "indices" : [
              "50",
              "60"
            ],
            "id_str" : "1187636394904211461",
            "id" : "1187636394904211461"
          },
          {
            "name" : "Structural Genomics Consortium (SGC)",
            "screen_name" : "thesgconline",
            "indices" : [
              "125",
              "138"
            ],
            "id_str" : "131149338",
            "id" : "131149338"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "192",
              "204"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Egon Willigh☮gen is @egonw@scholar.social",
            "screen_name" : "egonwillighagen",
            "indices" : [
              "232",
              "248"
            ],
            "id_str" : "22911650",
            "id" : "22911650"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Rfo3mBgmKh",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/wiki/Sources-of-Data",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "97",
              "120"
            ]
          },
          {
            "url" : "https://t.co/0JnNKbs1LB",
            "expanded_url" : "https://github.com/StructuralGenomicsConsortium/CNP4-Nsp13-C-terminus-B/wiki/Sources-of-Data",
            "display_url" : "github.com/StructuralGeno…",
            "indices" : [
              "168",
              "191"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "248"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1569401703941738502",
      "id_str" : "1569416554923573248",
      "in_reply_to_user_id" : "135266269",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1569416554923573248",
      "in_reply_to_status_id" : "1569401703941738502",
      "possibly_sensitive" : false,
      "created_at" : "Mon Sep 12 20:03:59 +0000 2022",
      "favorited" : false,
      "full_text" : "@joachimgoedhart @egonwillighagen @O_S_M @MycetOS @NFDI4Chem Open Source Antibiotics waves, too. https://t.co/Rfo3mBgmKh And @thesgconline Open Chemistry Networks e.g. https://t.co/0JnNKbs1LB @MatToddChem happy to elaborate. Thanks @egonwillighagen",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "in_reply_to_screen_name" : "joachimgoedhart",
      "in_reply_to_user_id_str" : "135266269"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1536995192703787008"
          ],
          "editableUntil" : "2022-06-15T09:23:04.587Z",
          "editsRemaining" : "5",
          "isEditEligible" : false
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "70",
              "84"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "118",
              "130"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1536995192703787008",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1536995192703787008",
      "created_at" : "Wed Jun 15 08:53:04 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Low yield for this Suzuki on an aza-aromatic core in @OSantibiotics  by student (Maria) working with @LoriFerrins. Any sug…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1535238707959185408"
          ],
          "editableUntil" : "2022-06-10T13:03:25.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "176",
              "188"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "189",
              "201"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "105",
              "117"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "118",
              "128"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Daniel Gedder",
            "screen_name" : "danielgedder",
            "indices" : [
              "129",
              "142"
            ],
            "id_str" : "54017848",
            "id" : "54017848"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "143",
              "151"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "152",
              "164"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "165",
              "175"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/F1vWhDCT6W",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/115",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "39",
              "62"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "201"
      ],
      "favorite_count" : "3",
      "id_str" : "1535238707959185408",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1535238707959185408",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jun 10 12:33:25 +0000 2022",
      "favorited" : false,
      "full_text" : "Series 2 meeting today at 2pm UK time. https://t.co/F1vWhDCT6W. Latest potency, MoA, Tox, paper writing. @MatToddChem @edwintse_ @danielgedder @emeryfs @LoriFerrins @macinchem #openscience #antibiotics",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1531257006916612096"
          ],
          "editableUntil" : "2022-05-30T13:21:34.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "TCS Research",
            "screen_name" : "TCSResearch",
            "indices" : [
              "15",
              "27"
            ],
            "id_str" : "1301734219748487168",
            "id" : "1301734219748487168"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "46",
              "60"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/CsEGAL9MnK",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/78",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "141",
              "164"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1531257006916612096/photo/1",
            "indices" : [
              "253",
              "276"
            ],
            "url" : "https://t.co/dmcx7KRjT4",
            "media_url" : "http://pbs.twimg.com/media/FUAd9A3XwAIj6-U.png",
            "id_str" : "1531256807347437570",
            "id" : "1531256807347437570",
            "media_url_https" : "https://pbs.twimg.com/media/FUAd9A3XwAIj6-U.png",
            "sizes" : {
              "small" : {
                "w" : "507",
                "h" : "384",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "507",
                "h" : "384",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "507",
                "h" : "384",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/dmcx7KRjT4"
          }
        ],
        "hashtags" : [
          {
            "text" : "compchem",
            "indices" : [
              "217",
              "226"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "227",
              "239"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "240",
              "252"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "276"
      ],
      "favorite_count" : "6",
      "id_str" : "1531257006916612096",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1531257006916612096",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 30 12:51:34 +0000 2022",
      "favorited" : false,
      "full_text" : "Team number 4 (@TCSResearch) just entered the @OSantibiotics competition to predict small molecule binders of the antibacterial target MurD. https://t.co/CsEGAL9MnK Two more teams incoming. Will you be team number 7? #compchem #antibiotics #openscience https://t.co/dmcx7KRjT4",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1531257006916612096/photo/1",
            "indices" : [
              "253",
              "276"
            ],
            "url" : "https://t.co/dmcx7KRjT4",
            "media_url" : "http://pbs.twimg.com/media/FUAd9A3XwAIj6-U.png",
            "id_str" : "1531256807347437570",
            "id" : "1531256807347437570",
            "media_url_https" : "https://pbs.twimg.com/media/FUAd9A3XwAIj6-U.png",
            "sizes" : {
              "small" : {
                "w" : "507",
                "h" : "384",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "507",
                "h" : "384",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "507",
                "h" : "384",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/dmcx7KRjT4"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1531214009185316865"
          ],
          "editableUntil" : "2022-05-30T10:30:43.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "104",
              "116"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "117",
              "129"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "130",
              "140"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Daniel Gedder",
            "screen_name" : "danielgedder",
            "indices" : [
              "159",
              "172"
            ],
            "id_str" : "54017848",
            "id" : "54017848"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/F1vWhDCT6W",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/115",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "80",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "202"
      ],
      "favorite_count" : "3",
      "id_str" : "1531214009185316865",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1531214009185316865",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 30 10:00:43 +0000 2022",
      "favorited" : false,
      "full_text" : "Next online meeting for Series 2 will be June 10th at 2pm UK time, all welcome. https://t.co/F1vWhDCT6W #openscience #antibiotics @edwintse_ pls ping Alex and @danielgedder pls ping Lee for latest data.",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1524048161253306369"
          ],
          "editableUntil" : "2022-05-10T15:56:11.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/BGT9JQZO9i",
            "expanded_url" : "https://twitter.com/mtngs_io/status/1524027428770918402",
            "display_url" : "twitter.com/mtngs_io/statu…",
            "indices" : [
              "6",
              "29"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "29"
      ],
      "favorite_count" : "0",
      "id_str" : "1524048161253306369",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1524048161253306369",
      "possibly_sensitive" : false,
      "created_at" : "Tue May 10 15:26:11 +0000 2022",
      "favorited" : false,
      "full_text" : "&lt;3 https://t.co/BGT9JQZO9i",
      "lang" : "qst",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1522210626029772800"
          ],
          "editableUntil" : "2022-05-05T14:14:29.000Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Jan Jensen (@janhjensen@mastodon.social)",
            "screen_name" : "janhjensen",
            "indices" : [
              "96",
              "107"
            ],
            "id_str" : "223934260",
            "id" : "223934260"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "132",
              "142"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Chris Dowson",
            "screen_name" : "dowson_c",
            "indices" : [
              "215",
              "224"
            ],
            "id_str" : "2804352177",
            "id" : "2804352177"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/xYyEXdC5PC",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/69#issuecomment-1118479977",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "108",
              "131"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1522210626029772800/photo/1",
            "indices" : [
              "239",
              "262"
            ],
            "url" : "https://t.co/MGHNGbVQpA",
            "media_url" : "http://pbs.twimg.com/media/FR_6XWKVEAAmxq-.png",
            "id_str" : "1522210478067355648",
            "id" : "1522210478067355648",
            "media_url_https" : "https://pbs.twimg.com/media/FR_6XWKVEAAmxq-.png",
            "sizes" : {
              "large" : {
                "w" : "838",
                "h" : "512",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "838",
                "h" : "512",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "415",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/MGHNGbVQpA"
          }
        ],
        "hashtags" : [
          {
            "text" : "AI",
            "indices" : [
              "44",
              "47"
            ]
          },
          {
            "text" : "machinelearning",
            "indices" : [
              "48",
              "64"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "65",
              "79"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "226",
              "238"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "262"
      ],
      "favorite_count" : "13",
      "id_str" : "1522210626029772800",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1522210626029772800",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 05 13:44:29 +0000 2022",
      "favorited" : false,
      "full_text" : "First competition entries in the generative #AI #machinelearning #drugdiscovery challenge from \n@janhjensen https://t.co/xYyEXdC5PC @edwintse_ considering making vs buying, then they'll be biologically evaluated by @dowson_c. #antibiotics https://t.co/MGHNGbVQpA",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1522210626029772800/photo/1",
            "indices" : [
              "239",
              "262"
            ],
            "url" : "https://t.co/MGHNGbVQpA",
            "media_url" : "http://pbs.twimg.com/media/FR_6XWKVEAAmxq-.png",
            "id_str" : "1522210478067355648",
            "id" : "1522210478067355648",
            "media_url_https" : "https://pbs.twimg.com/media/FR_6XWKVEAAmxq-.png",
            "sizes" : {
              "large" : {
                "w" : "838",
                "h" : "512",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "838",
                "h" : "512",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "415",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/MGHNGbVQpA"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1513412332709425152"
          ],
          "editableUntil" : "2022-04-11T07:33:12.616Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "PeteC",
            "screen_name" : "ThatKidSampson",
            "indices" : [
              "0",
              "15"
            ],
            "id_str" : "425821053",
            "id" : "425821053"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "146"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "1513246609672388611",
      "id_str" : "1513412332709425152",
      "in_reply_to_user_id" : "425821053",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1513412332709425152",
      "in_reply_to_status_id" : "1513246609672388611",
      "created_at" : "Mon Apr 11 07:03:12 +0000 2022",
      "favorited" : false,
      "full_text" : "@ThatKidSampson Assuming SPR needed, so it'll mostly be affinity. If we get to a zone where we can judge with biochem affinity we'll be delighted.",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "in_reply_to_screen_name" : "ThatKidSampson",
      "in_reply_to_user_id_str" : "425821053"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1509855353701388308"
          ],
          "editableUntil" : "2022-04-01T11:59:02.735Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UNC Pharmacy",
            "screen_name" : "UNCPharmacy",
            "indices" : [
              "112",
              "124"
            ],
            "id_str" : "15750564",
            "id" : "15750564"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "191",
              "203"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "204",
              "214"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "215",
              "227"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "228",
              "238"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Daniel Gedder",
            "screen_name" : "danielgedder",
            "indices" : [
              "239",
              "252"
            ],
            "id_str" : "54017848",
            "id" : "54017848"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "253",
              "261"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "262",
              "274"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "274"
      ],
      "favorite_count" : "5",
      "id_str" : "1509855353701388308",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1509855353701388308",
      "created_at" : "Fri Apr 01 11:29:02 +0000 2022",
      "favorited" : false,
      "full_text" : "Postponing today's Series 2 meeting to next week Wednesday April 6th 4pm UK (11 a.m. EST) since Lee Graves from @UNCPharmacy can present MoA data then. Github issue coming. Good weekend all! @MatToddChem @macinchem @LoriFerrins @edwintse_ @danielgedder @emeryfs @mfernflower",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1509823253581541376"
          ],
          "editableUntil" : "2022-04-01T09:51:29.470Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "87",
              "95"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "96",
              "109"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          },
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "110",
              "120"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          },
          {
            "name" : "CARB-X",
            "screen_name" : "CARB_X",
            "indices" : [
              "121",
              "128"
            ],
            "id_str" : "752900258011774976",
            "id" : "752900258011774976"
          },
          {
            "name" : "CO-ADD Antibiotics",
            "screen_name" : "COADD_news",
            "indices" : [
              "129",
              "140"
            ],
            "id_str" : "3045189728",
            "id" : "3045189728"
          },
          {
            "name" : "Chris Dowson",
            "screen_name" : "dowson_c",
            "indices" : [
              "141",
              "150"
            ],
            "id_str" : "2804352177",
            "id" : "2804352177"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "151",
              "163"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "164",
              "174"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "The Alan Turing Institute",
            "screen_name" : "turinginst",
            "indices" : [
              "175",
              "186"
            ],
            "id_str" : "3697013177",
            "id" : "3697013177"
          },
          {
            "name" : "Nathan Benaich",
            "screen_name" : "nathanbenaich",
            "indices" : [
              "187",
              "201"
            ],
            "id_str" : "422388777",
            "id" : "422388777"
          },
          {
            "name" : "Optibrium",
            "screen_name" : "Optibrium",
            "indices" : [
              "202",
              "212"
            ],
            "id_str" : "77167517",
            "id" : "77167517"
          },
          {
            "name" : "BenevolentAI",
            "screen_name" : "benevolent_ai",
            "indices" : [
              "213",
              "227"
            ],
            "id_str" : "2330850942",
            "id" : "2330850942"
          },
          {
            "name" : "IBM Data, AI & Automation",
            "screen_name" : "IBMData",
            "indices" : [
              "228",
              "236"
            ],
            "id_str" : "267283568",
            "id" : "267283568"
          },
          {
            "name" : "DeepMind",
            "screen_name" : "DeepMind",
            "indices" : [
              "237",
              "246"
            ],
            "id_str" : "4783690002",
            "id" : "4783690002"
          },
          {
            "name" : "UCL School of Pharmacy",
            "screen_name" : "School_Pharmacy",
            "indices" : [
              "247",
              "263"
            ],
            "id_str" : "56353603",
            "id" : "56353603"
          },
          {
            "name" : "Cambridge Centre for AI in Medicine",
            "screen_name" : "CC4AIM",
            "indices" : [
              "264",
              "271"
            ],
            "id_str" : "1263045684468559872",
            "id" : "1263045684468559872"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "271"
      ],
      "favorite_count" : "3",
      "in_reply_to_status_id_str" : "1509821566758141963",
      "id_str" : "1509823253581541376",
      "in_reply_to_user_id" : "1111629854716428290",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1509823253581541376",
      "in_reply_to_status_id" : "1509821566758141963",
      "created_at" : "Fri Apr 01 09:21:29 +0000 2022",
      "favorited" : false,
      "full_text" : "The competition is live for only 3 months, so don't delay and pls help spread the word @1Antruk @Wellcome_AMR @gardp_amr @CARB_X @COADD_news @dowson_c @MatToddChem @edwintse_ @turinginst @nathanbenaich @optibrium @benevolent_ai @IBMData @DeepMind @School_Pharmacy @CC4AIM",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "in_reply_to_screen_name" : "OSantibiotics",
      "in_reply_to_user_id_str" : "1111629854716428290"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1509821566758141963"
          ],
          "editableUntil" : "2022-04-01T09:44:47.300Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "drugdiscovery",
            "indices" : [
              "46",
              "60"
            ]
          },
          {
            "text" : "FBDD",
            "indices" : [
              "115",
              "120"
            ]
          },
          {
            "text" : "AI",
            "indices" : [
              "226",
              "229"
            ]
          },
          {
            "text" : "ML",
            "indices" : [
              "230",
              "233"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "280"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1509821018864599046",
      "id_str" : "1509821566758141963",
      "in_reply_to_user_id" : "1111629854716428290",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1509821566758141963",
      "in_reply_to_status_id" : "1509821018864599046",
      "created_at" : "Fri Apr 01 09:14:47 +0000 2022",
      "favorited" : false,
      "full_text" : "We need small molecules that bind a promising #drugdiscovery target, MurD. We've protein structures with fragments #FBDD. We've a binding assay. We can make/buy molecules. We need binders, predicted with generative methods in #AI #ML. We'll experimentally validate predictions. 2/",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "in_reply_to_screen_name" : "OSantibiotics",
      "in_reply_to_user_id_str" : "1111629854716428290"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1509821018864599046"
          ],
          "editableUntil" : "2022-04-01T09:42:36.672Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/r3VLhtCSNF",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/69",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "249",
              "272"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1509821018864599046/photo/1",
            "indices" : [
              "276",
              "299"
            ],
            "url" : "https://t.co/Ko3s7Bd5XQ",
            "media_url" : "http://pbs.twimg.com/media/FPP2KRnXwBwMmA9.png",
            "id_str" : "1509820956486909980",
            "id" : "1509820956486909980",
            "media_url_https" : "https://pbs.twimg.com/media/FPP2KRnXwBwMmA9.png",
            "sizes" : {
              "large" : {
                "w" : "828",
                "h" : "568",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "466",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "828",
                "h" : "568",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Ko3s7Bd5XQ"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "5",
              "17"
            ]
          },
          {
            "text" : "ArtificialIntelligence",
            "indices" : [
              "53",
              "76"
            ]
          },
          {
            "text" : "MachineLearning",
            "indices" : [
              "81",
              "97"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "175",
              "179"
            ]
          },
          {
            "text" : "antibiotic",
            "indices" : [
              "180",
              "191"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "299"
      ],
      "favorite_count" : "20",
      "id_str" : "1509821018864599046",
      "truncated" : false,
      "retweet_count" : "17",
      "id" : "1509821018864599046",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 01 09:12:36 +0000 2022",
      "favorited" : false,
      "full_text" : "It's #openscience competition time! Got expertise in #ArtificialIntelligence and #MachineLearning? Developing *generative methods* for molecule prediction? Want to help fight #AMR #antibiotic resistance? Then we've a great competition for you here: https://t.co/r3VLhtCSNF 1/ https://t.co/Ko3s7Bd5XQ",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1509821018864599046/photo/1",
            "indices" : [
              "276",
              "299"
            ],
            "url" : "https://t.co/Ko3s7Bd5XQ",
            "media_url" : "http://pbs.twimg.com/media/FPP2KRnXwBwMmA9.png",
            "id_str" : "1509820956486909980",
            "id" : "1509820956486909980",
            "media_url_https" : "https://pbs.twimg.com/media/FPP2KRnXwBwMmA9.png",
            "sizes" : {
              "large" : {
                "w" : "828",
                "h" : "568",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "466",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "828",
                "h" : "568",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Ko3s7Bd5XQ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1501546642188771333"
          ],
          "editableUntil" : "2022-03-09T13:43:11.542Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "27",
              "41"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "SSGCID",
            "screen_name" : "SSGCID",
            "indices" : [
              "260",
              "267"
            ],
            "id_str" : "1327978831",
            "id" : "1327978831"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/oIz8OK4Pa9",
            "expanded_url" : "https://www.youtube.com/watch?v=Px2cmZKKtBE",
            "display_url" : "youtube.com/watch?v=Px2cmZ…",
            "indices" : [
              "82",
              "105"
            ]
          },
          {
            "url" : "https://t.co/vI5wRMQCeS",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/70",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "130",
              "153"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1501546642188771333/photo/1",
            "indices" : [
              "268",
              "291"
            ],
            "url" : "https://t.co/WRzkRvImqe",
            "media_url" : "http://pbs.twimg.com/media/FNaQqDDXoAA2sK7.jpg",
            "id_str" : "1501546577822982144",
            "id" : "1501546577822982144",
            "media_url_https" : "https://pbs.twimg.com/media/FNaQqDDXoAA2sK7.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "614",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "348",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1844",
                "h" : "944",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/WRzkRvImqe"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "154",
              "166"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "167",
              "179"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "291"
      ],
      "favorite_count" : "5",
      "id_str" : "1501546642188771333",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1501546642188771333",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 09 13:13:11 +0000 2022",
      "favorited" : false,
      "full_text" : "Recording from yesterday's @OSantibiotics meeting on the mur ligases is now up at https://t.co/oIz8OK4Pa9 with the actions etc at https://t.co/vI5wRMQCeS #openscience #antibiotics Good discussion on usefulness of truncated proteins for securing new structures @SSGCID https://t.co/WRzkRvImqe",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1501546642188771333/photo/1",
            "indices" : [
              "268",
              "291"
            ],
            "url" : "https://t.co/WRzkRvImqe",
            "media_url" : "http://pbs.twimg.com/media/FNaQqDDXoAA2sK7.jpg",
            "id_str" : "1501546577822982144",
            "id" : "1501546577822982144",
            "media_url_https" : "https://pbs.twimg.com/media/FNaQqDDXoAA2sK7.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "614",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "348",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1844",
                "h" : "944",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/WRzkRvImqe"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1500821745837748224"
          ],
          "editableUntil" : "2022-03-07T13:42:42.784Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "131",
              "143"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "144",
              "154"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "155",
              "167"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "168",
              "178"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Chris Dowson",
            "screen_name" : "dowson_c",
            "indices" : [
              "179",
              "188"
            ],
            "id_str" : "2804352177",
            "id" : "2804352177"
          },
          {
            "name" : "Jan Jensen (@janhjensen@mastodon.social)",
            "screen_name" : "janhjensen",
            "indices" : [
              "189",
              "200"
            ],
            "id_str" : "223934260",
            "id" : "223934260"
          },
          {
            "name" : "Lizbe Koekemoer",
            "screen_name" : "KoekemoerLizbe",
            "indices" : [
              "201",
              "216"
            ],
            "id_str" : "1380167491",
            "id" : "1380167491"
          },
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "217",
              "227"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          },
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "228",
              "236"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/vI5wRMQCeS",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/70",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "69",
              "92"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1500821745837748224/photo/1",
            "indices" : [
              "237",
              "260"
            ],
            "url" : "https://t.co/M9SdBHYNxN",
            "media_url" : "http://pbs.twimg.com/media/FNP9NUEXEAcPu06.png",
            "id_str" : "1500821506011631623",
            "id" : "1500821506011631623",
            "media_url_https" : "https://pbs.twimg.com/media/FNP9NUEXEAcPu06.png",
            "sizes" : {
              "medium" : {
                "w" : "817",
                "h" : "463",
                "resize" : "fit"
              },
              "large" : {
                "w" : "817",
                "h" : "463",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "385",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/M9SdBHYNxN"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "105",
              "117"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "118",
              "130"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "260"
      ],
      "favorite_count" : "7",
      "id_str" : "1500821745837748224",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1500821745837748224",
      "possibly_sensitive" : false,
      "created_at" : "Mon Mar 07 13:12:42 +0000 2022",
      "favorited" : false,
      "full_text" : "Agenda up for tomorrow's Series 1 - mur ligase meeting, 2pm UK time. https://t.co/vI5wRMQCeS All welcome #openscience #antibiotics @MatToddChem @macinchem @LoriFerrins @edwintse_ @dowson_c @janhjensen @KoekemoerLizbe @gardp_amr @1Antruk https://t.co/M9SdBHYNxN",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1500821745837748224/photo/1",
            "indices" : [
              "237",
              "260"
            ],
            "url" : "https://t.co/M9SdBHYNxN",
            "media_url" : "http://pbs.twimg.com/media/FNP9NUEXEAcPu06.png",
            "id_str" : "1500821506011631623",
            "id" : "1500821506011631623",
            "media_url_https" : "https://pbs.twimg.com/media/FNP9NUEXEAcPu06.png",
            "sizes" : {
              "medium" : {
                "w" : "817",
                "h" : "463",
                "resize" : "fit"
              },
              "large" : {
                "w" : "817",
                "h" : "463",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "385",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/M9SdBHYNxN"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1499725730405617668"
          ],
          "editableUntil" : "2022-03-04T13:07:32.342Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "189",
              "201"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "119",
              "131"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "132",
              "142"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "143",
              "153"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "154",
              "166"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "167",
              "175"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "176",
              "188"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "201"
      ],
      "favorite_count" : "3",
      "id_str" : "1499725730405617668",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1499725730405617668",
      "created_at" : "Fri Mar 04 12:37:32 +0000 2022",
      "favorited" : false,
      "full_text" : "No meeting today. Aiming for tox/DNA binding AND MoA update next Friday (11th) at 3pm UK time. Will confirm on Github. @LoriFerrins @macinchem @edwintse_ @mfernflower @emeryfs @MatToddChem #antibiotics",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1497210162200952832"
          ],
          "editableUntil" : "2022-02-25T14:31:34.145Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "18",
              "32"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "94",
              "106"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "107",
              "119"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Daniel Gedder",
            "screen_name" : "danielgedder",
            "indices" : [
              "120",
              "133"
            ],
            "id_str" : "54017848",
            "id" : "54017848"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1497210162200952832",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1497210162200952832",
      "created_at" : "Fri Feb 25 14:01:34 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @edwintse_: No @OSantibiotics meeting today. Next meeting date will be confirmed on GitHub @MatToddChem @LoriFerrins @danielgedder @maci…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1493360135976198144"
          ],
          "editableUntil" : "2022-02-14T23:32:56.363Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "60",
              "72"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "97",
              "107"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          },
          {
            "name" : "John H. Rex, MD",
            "screen_name" : "JohnRex_NewAbx",
            "indices" : [
              "108",
              "123"
            ],
            "id_str" : "825110000972464128",
            "id" : "825110000972464128"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "124",
              "137"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          },
          {
            "name" : "AMR Action Fund",
            "screen_name" : "AMRActionFund",
            "indices" : [
              "138",
              "152"
            ],
            "id_str" : "1270709401192718337",
            "id" : "1270709401192718337"
          },
          {
            "name" : "Kevin Outterson",
            "screen_name" : "koutterson",
            "indices" : [
              "153",
              "164"
            ],
            "id_str" : "55264345",
            "id" : "55264345"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "165",
              "177"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/uCvGgq1ErW",
            "expanded_url" : "https://www.bcg.com/publications/2022/subscription-model-tackling-antimicrobial-resistance",
            "display_url" : "bcg.com/publications/2…",
            "indices" : [
              "73",
              "96"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "177"
      ],
      "favorite_count" : "0",
      "id_str" : "1493360135976198144",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1493360135976198144",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 14 23:02:56 +0000 2022",
      "favorited" : false,
      "full_text" : "Big report on the Subscription Model for the funding of new #antibiotics https://t.co/uCvGgq1ErW @gardp_amr @JohnRex_NewAbx @Wellcome_AMR @AMRActionFund @koutterson @MatToddChem",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1492082676307828769"
          ],
          "editableUntil" : "2022-02-11T10:56:46.244Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "244",
              "256"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "257",
              "269"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "John H. Rex, MD",
            "screen_name" : "JohnRex_NewAbx",
            "indices" : [
              "28",
              "43"
            ],
            "id_str" : "825110000972464128",
            "id" : "825110000972464128"
          },
          {
            "name" : "CC4CARB",
            "screen_name" : "CC4CARB",
            "indices" : [
              "122",
              "130"
            ],
            "id_str" : "1380590969326821384",
            "id" : "1380590969326821384"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/GiDxrws36k",
            "expanded_url" : "https://amr.solutions/2022/02/10/cc4carb-free-rationally-designed-compound-libraries-based-on-your-ideas/",
            "display_url" : "amr.solutions/2022/02/10/cc4…",
            "indices" : [
              "44",
              "67"
            ]
          },
          {
            "url" : "https://t.co/A2BeyhdPd1",
            "expanded_url" : "https://www.cc4carb-collection.org/",
            "display_url" : "cc4carb-collection.org",
            "indices" : [
              "98",
              "121"
            ]
          },
          {
            "url" : "https://t.co/NTrBK0LTup",
            "expanded_url" : "https://wellcomeopenresearch.org/articles/6-146/v1",
            "display_url" : "wellcomeopenresearch.org/articles/6-146…",
            "indices" : [
              "220",
              "243"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "269"
      ],
      "favorite_count" : "2",
      "id_str" : "1492082676307828769",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1492082676307828769",
      "possibly_sensitive" : false,
      "created_at" : "Fri Feb 11 10:26:46 +0000 2022",
      "favorited" : false,
      "full_text" : "Thank you for the shout-out @JohnRex_NewAbx https://t.co/GiDxrws36k and for the excellent link to https://t.co/A2BeyhdPd1 @CC4CARB. Agree 100% with comments re $ for development - we've written about this exact point at https://t.co/NTrBK0LTup #antibiotics #openscience",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1491818918582923264"
          ],
          "editableUntil" : "2022-02-10T17:28:41.502Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/w0qvGI15Zf",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/104",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "85",
              "108"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1491818918582923264/photo/1",
            "indices" : [
              "135",
              "158"
            ],
            "url" : "https://t.co/4vF4Ri8bYa",
            "media_url" : "http://pbs.twimg.com/media/FLQAhHFWUAMOBf_.png",
            "id_str" : "1491817945403641859",
            "id" : "1491817945403641859",
            "media_url_https" : "https://pbs.twimg.com/media/FLQAhHFWUAMOBf_.png",
            "sizes" : {
              "medium" : {
                "w" : "694",
                "h" : "698",
                "resize" : "fit"
              },
              "small" : {
                "w" : "676",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "694",
                "h" : "698",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/4vF4Ri8bYa"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "109",
              "121"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "122",
              "134"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "158"
      ],
      "favorite_count" : "4",
      "id_str" : "1491818918582923264",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1491818918582923264",
      "possibly_sensitive" : false,
      "created_at" : "Thu Feb 10 16:58:41 +0000 2022",
      "favorited" : false,
      "full_text" : "Rat heps CLint of 8 is not terrible for this compound with a 4 ug/mL potency vs MRSA https://t.co/w0qvGI15Zf #openscience #antibiotics https://t.co/4vF4Ri8bYa",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1491818918582923264/photo/1",
            "indices" : [
              "135",
              "158"
            ],
            "url" : "https://t.co/4vF4Ri8bYa",
            "media_url" : "http://pbs.twimg.com/media/FLQAhHFWUAMOBf_.png",
            "id_str" : "1491817945403641859",
            "id" : "1491817945403641859",
            "media_url_https" : "https://pbs.twimg.com/media/FLQAhHFWUAMOBf_.png",
            "sizes" : {
              "medium" : {
                "w" : "694",
                "h" : "698",
                "resize" : "fit"
              },
              "small" : {
                "w" : "676",
                "h" : "680",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "694",
                "h" : "698",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/4vF4Ri8bYa"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1491740789768179713"
          ],
          "editableUntil" : "2022-02-10T12:18:14.141Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Yuhang Wang",
            "screen_name" : "EricWan59398945",
            "indices" : [
              "34",
              "50"
            ],
            "id_str" : "1317060137606066177",
            "id" : "1317060137606066177"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/OhkroYipRT",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/66",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "208",
              "231"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1491740789768179713/photo/1",
            "indices" : [
              "232",
              "255"
            ],
            "url" : "https://t.co/fLDaQFr6V8",
            "media_url" : "http://pbs.twimg.com/media/FLO6DHUXoAI7Oke.png",
            "id_str" : "1491740464256622594",
            "id" : "1491740464256622594",
            "media_url_https" : "https://pbs.twimg.com/media/FLO6DHUXoAI7Oke.png",
            "sizes" : {
              "medium" : {
                "w" : "733",
                "h" : "560",
                "resize" : "fit"
              },
              "large" : {
                "w" : "733",
                "h" : "560",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "520",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/fLDaQFr6V8"
          }
        ],
        "hashtags" : [
          {
            "text" : "medchem",
            "indices" : [
              "153",
              "161"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "162",
              "174"
            ]
          },
          {
            "text" : "decisionsdecisions",
            "indices" : [
              "175",
              "194"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "195",
              "207"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "255"
      ],
      "favorite_count" : "4",
      "id_str" : "1491740789768179713",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1491740789768179713",
      "possibly_sensitive" : false,
      "created_at" : "Thu Feb 10 11:48:14 +0000 2022",
      "favorited" : false,
      "full_text" : "Proposed scaffold hop proposed by @EricWan59398945 modeled by ex-AZ Joe Eyermann. Chemistry simpler, but binding looks poorer. Make matched pair anyway? #medchem #openscience #decisionsdecisions #antibiotics https://t.co/OhkroYipRT https://t.co/fLDaQFr6V8",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1491740789768179713/photo/1",
            "indices" : [
              "232",
              "255"
            ],
            "url" : "https://t.co/fLDaQFr6V8",
            "media_url" : "http://pbs.twimg.com/media/FLO6DHUXoAI7Oke.png",
            "id_str" : "1491740464256622594",
            "id" : "1491740464256622594",
            "media_url_https" : "https://pbs.twimg.com/media/FLO6DHUXoAI7Oke.png",
            "sizes" : {
              "medium" : {
                "w" : "733",
                "h" : "560",
                "resize" : "fit"
              },
              "large" : {
                "w" : "733",
                "h" : "560",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "520",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/fLDaQFr6V8"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1491549649882259456"
          ],
          "editableUntil" : "2022-02-09T23:38:42.841Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "SSGCID",
            "screen_name" : "SSGCID",
            "indices" : [
              "72",
              "79"
            ],
            "id_str" : "1327978831",
            "id" : "1327978831"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/nmzpG4Udrq",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/67#issuecomment-1034278944",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "134",
              "157"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1491549649882259456/photo/1",
            "indices" : [
              "220",
              "243"
            ],
            "url" : "https://t.co/S1BKmL3jHk",
            "media_url" : "http://pbs.twimg.com/media/FLMMAb_WQAEfVUf.png",
            "id_str" : "1491549103242756097",
            "id" : "1491549103242756097",
            "media_url_https" : "https://pbs.twimg.com/media/FLMMAb_WQAEfVUf.png",
            "sizes" : {
              "large" : {
                "w" : "810",
                "h" : "600",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "810",
                "h" : "600",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "504",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/S1BKmL3jHk"
          }
        ],
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "158",
              "170"
            ]
          },
          {
            "text" : "murligase",
            "indices" : [
              "188",
              "198"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "243"
      ],
      "favorite_count" : "3",
      "id_str" : "1491549649882259456",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1491549649882259456",
      "possibly_sensitive" : false,
      "created_at" : "Wed Feb 09 23:08:42 +0000 2022",
      "favorited" : false,
      "full_text" : "Lovely new structure of P. aeruginosa MurD with ADP bound incoming from @SSGCID and UCB's Jan Abendroth, preliminary data reported at https://t.co/nmzpG4Udrq #antibiotics A bonanza of new #murligase structures recently. https://t.co/S1BKmL3jHk",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1491549649882259456/photo/1",
            "indices" : [
              "220",
              "243"
            ],
            "url" : "https://t.co/S1BKmL3jHk",
            "media_url" : "http://pbs.twimg.com/media/FLMMAb_WQAEfVUf.png",
            "id_str" : "1491549103242756097",
            "id" : "1491549103242756097",
            "media_url_https" : "https://pbs.twimg.com/media/FLMMAb_WQAEfVUf.png",
            "sizes" : {
              "large" : {
                "w" : "810",
                "h" : "600",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "810",
                "h" : "600",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "504",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/S1BKmL3jHk"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1490706694757830661"
          ],
          "editableUntil" : "2022-02-07T15:49:06.678Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "130",
              "142"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "143",
              "147"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "148",
              "156"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          },
          {
            "name" : "Atomwise",
            "screen_name" : "AtomwiseInc",
            "indices" : [
              "244",
              "256"
            ],
            "id_str" : "783284048",
            "id" : "783284048"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/OhkroYipRT",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/66",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "106",
              "129"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "277"
      ],
      "favorite_count" : "6",
      "id_str" : "1490706694757830661",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1490706694757830661",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 07 15:19:06 +0000 2022",
      "favorited" : false,
      "full_text" : "Next online research meeting for Series 1 (the mur ligases) is tomorrow at 2pm UK time. What we'll cover: https://t.co/OhkroYipRT #antibiotics #AMR @1Antruk Key expts: 1) to confirm binding to protein of new inhibitors 2) to get structures for @AtomwiseInc compounds that bind.",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1489579059864551425"
          ],
          "editableUntil" : "2022-02-04T13:08:17.569Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "104",
              "116"
            ]
          },
          {
            "text" : "outreach",
            "indices" : [
              "117",
              "126"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1489579059864551425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1489579059864551425",
      "created_at" : "Fri Feb 04 12:38:17 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Most days I love my research group. But there are some days when I *really* love them. #OpenScience #outreach on our lab's…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1488835462047449091"
          ],
          "editableUntil" : "2022-02-02T11:53:30.034Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "113",
              "125"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "25",
              "39"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "126",
              "136"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/HVSchc4Sds",
            "expanded_url" : "https://docs.google.com/forms/d/e/1FAIpQLSf4UieL5pRQqN5rOL4q-t57qcpJhHG_jqMXV774FPUJBmnBbQ/viewform",
            "display_url" : "docs.google.com/forms/d/e/1FAI…",
            "indices" : [
              "80",
              "103"
            ]
          },
          {
            "url" : "https://t.co/L4J3i3v6Ku",
            "expanded_url" : "https://twitter.com/edwintse_/status/1488831092832579584",
            "display_url" : "twitter.com/edwintse_/stat…",
            "indices" : [
              "137",
              "160"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "160"
      ],
      "favorite_count" : "0",
      "id_str" : "1488835462047449091",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1488835462047449091",
      "possibly_sensitive" : false,
      "created_at" : "Wed Feb 02 11:23:30 +0000 2022",
      "favorited" : false,
      "full_text" : "If you'd like to receive @OSantibiotics newsletters by email, please sign up at https://t.co/HVSchc4Sds No spam! #antibiotics @gardp_amr https://t.co/L4J3i3v6Ku",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1488832052300443650"
          ],
          "editableUntil" : "2022-02-02T11:39:57.087Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "21",
              "35"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1488832052300443650",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1488832052300443650",
      "created_at" : "Wed Feb 02 11:09:57 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @edwintse_: First @OSantibiotics newsletter for 2022 is out now! Catch up on all the exciting developments in both our series! https://t…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1488827320311898112"
          ],
          "editableUntil" : "2022-02-02T11:21:08.893Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "18",
              "32"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1488827320311898112",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1488827320311898112",
      "created_at" : "Wed Feb 02 10:51:08 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @edwintse_: No @OSantibiotics meeting this week. Next meeting will be Fri 11th Feb at 3pm (instead of 2pm just for this meeting) https:/…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1487010721900728323"
          ],
          "editableUntil" : "2022-01-28T11:02:38.081Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "157",
              "169"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "170",
              "180"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "181",
              "191"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "192",
              "204"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "205",
              "217"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "218",
              "226"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/jCaafPJOlO",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/109",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "107",
              "130"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1487010721900728323/photo/1",
            "indices" : [
              "227",
              "250"
            ],
            "url" : "https://t.co/QkS6DrocVi",
            "media_url" : "http://pbs.twimg.com/media/FKLsKVEXoAAQTX2.png",
            "id_str" : "1487010489184002048",
            "id" : "1487010489184002048",
            "media_url_https" : "https://pbs.twimg.com/media/FKLsKVEXoAAQTX2.png",
            "sizes" : {
              "medium" : {
                "w" : "895",
                "h" : "569",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "432",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "895",
                "h" : "569",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/QkS6DrocVi"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "131",
              "143"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "144",
              "156"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "250"
      ],
      "favorite_count" : "6",
      "id_str" : "1487010721900728323",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1487010721900728323",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 28 10:32:38 +0000 2022",
      "favorited" : false,
      "full_text" : "No meeting today. Waiting on MoA experiments (happening) and tox (completing). New potency data to chew on https://t.co/jCaafPJOlO #openscience #antibiotics @LoriFerrins @macinchem @edwintse_ @mfernflower @MatToddChem @emeryfs https://t.co/QkS6DrocVi",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1487010721900728323/photo/1",
            "indices" : [
              "227",
              "250"
            ],
            "url" : "https://t.co/QkS6DrocVi",
            "media_url" : "http://pbs.twimg.com/media/FKLsKVEXoAAQTX2.png",
            "id_str" : "1487010489184002048",
            "id" : "1487010489184002048",
            "media_url_https" : "https://pbs.twimg.com/media/FKLsKVEXoAAQTX2.png",
            "sizes" : {
              "medium" : {
                "w" : "895",
                "h" : "569",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "432",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "895",
                "h" : "569",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/QkS6DrocVi"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1486385664384024579"
          ],
          "editableUntil" : "2022-01-26T17:38:52.756Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1486385664384024579",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1486385664384024579",
      "created_at" : "Wed Jan 26 17:08:52 +0000 2022",
      "favorited" : false,
      "full_text" : "RT @gardp_amr: Have you read the recent horizon scanning report from GARDP’s Discovery and Exploratory Research team? https://t.co/2zKKspr0…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1484472159112208384"
          ],
          "editableUntil" : "2022-01-21T10:55:17.548Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "37",
              "47"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "79",
              "91"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "207",
              "217"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "218",
              "230"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "231",
              "239"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "240",
              "252"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "273"
      ],
      "favorite_count" : "4",
      "id_str" : "1484472159112208384",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1484472159112208384",
      "created_at" : "Fri Jan 21 10:25:17 +0000 2022",
      "favorited" : false,
      "full_text" : "No meeting today on Series 2, though @edwintse_ will post new potency data and @MatToddChem will assign some paper writing tasks... MoA experiments are proceeding, but not yet done. Final tox data incoming. @macinchem @LoriFerrins @emeryfs @mfernflower Any other updates..?",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1481313746186391555"
          ],
          "editableUntil" : "2022-01-12T17:44:53.226Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "6",
              "20"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "182",
              "194"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "195",
              "205"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "206",
              "214"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "215",
              "227"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "228",
              "240"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "241",
              "251"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/mBf7GJOAP6",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/108",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "85",
              "108"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1481313746186391555/photo/1",
            "indices" : [
              "278",
              "301"
            ],
            "url" : "https://t.co/sf8wQR1nfs",
            "media_url" : "http://pbs.twimg.com/media/FI6u_AFWYAAjSrb.jpg",
            "id_str" : "1481313724828901376",
            "id" : "1481313724828901376",
            "media_url_https" : "https://pbs.twimg.com/media/FI6u_AFWYAAjSrb.jpg",
            "sizes" : {
              "large" : {
                "w" : "1178",
                "h" : "418",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "241",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1178",
                "h" : "418",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/sf8wQR1nfs"
          }
        ],
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "252",
              "264"
            ]
          },
          {
            "text" : "OpenScience",
            "indices" : [
              "265",
              "277"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "301"
      ],
      "favorite_count" : "4",
      "id_str" : "1481313746186391555",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1481313746186391555",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jan 12 17:14:53 +0000 2022",
      "favorited" : false,
      "full_text" : "First @OSantibiotics meeting of 2022 is this Friday Jan 14th at the usual time - see https://t.co/mBf7GJOAP6. Moving towards finalising data and submitting paper. Need ducks in row. @MatToddChem @macinchem @emeryfs @LoriFerrins @mfernflower @dana_klug #antibiotics #OpenScience https://t.co/sf8wQR1nfs",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1481313746186391555/photo/1",
            "indices" : [
              "278",
              "301"
            ],
            "url" : "https://t.co/sf8wQR1nfs",
            "media_url" : "http://pbs.twimg.com/media/FI6u_AFWYAAjSrb.jpg",
            "id_str" : "1481313724828901376",
            "id" : "1481313724828901376",
            "media_url_https" : "https://pbs.twimg.com/media/FI6u_AFWYAAjSrb.jpg",
            "sizes" : {
              "large" : {
                "w" : "1178",
                "h" : "418",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "241",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1178",
                "h" : "418",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/sf8wQR1nfs"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1465671393815797768"
          ],
          "editableUntil" : "2021-11-30T13:47:45.800Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "29",
              "39"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "43",
              "55"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Northeastern U.",
            "screen_name" : "Northeastern",
            "indices" : [
              "56",
              "69"
            ],
            "id_str" : "46477409",
            "id" : "46477409"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/w0qvGI15Zf",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/104",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "100",
              "123"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1465671393815797768/photo/1",
            "indices" : [
              "231",
              "254"
            ],
            "url" : "https://t.co/PMsXrddzkE",
            "media_url" : "http://pbs.twimg.com/media/FFccWQRXEAU0z-1.png",
            "id_str" : "1465671372382867461",
            "id" : "1465671372382867461",
            "media_url_https" : "https://pbs.twimg.com/media/FFccWQRXEAU0z-1.png",
            "sizes" : {
              "medium" : {
                "w" : "535",
                "h" : "322",
                "resize" : "fit"
              },
              "large" : {
                "w" : "535",
                "h" : "322",
                "resize" : "fit"
              },
              "small" : {
                "w" : "535",
                "h" : "322",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/PMsXrddzkE"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "205",
              "217"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "218",
              "230"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "254"
      ],
      "favorite_count" : "6",
      "id_str" : "1465671393815797768",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1465671393815797768",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 30 13:17:45 +0000 2021",
      "favorited" : false,
      "full_text" : "New shipment of compounds by @dana_klug to @LoriFerrins @Northeastern for in vitro PK measurements. https://t.co/w0qvGI15Zf Data will be v useful for plugging data holes in the paper that's being drafted. #openscience #antibiotics https://t.co/PMsXrddzkE",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1465671393815797768/photo/1",
            "indices" : [
              "231",
              "254"
            ],
            "url" : "https://t.co/PMsXrddzkE",
            "media_url" : "http://pbs.twimg.com/media/FFccWQRXEAU0z-1.png",
            "id_str" : "1465671372382867461",
            "id" : "1465671372382867461",
            "media_url_https" : "https://pbs.twimg.com/media/FFccWQRXEAU0z-1.png",
            "sizes" : {
              "medium" : {
                "w" : "535",
                "h" : "322",
                "resize" : "fit"
              },
              "large" : {
                "w" : "535",
                "h" : "322",
                "resize" : "fit"
              },
              "small" : {
                "w" : "535",
                "h" : "322",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/PMsXrddzkE"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1461085473468780545"
          ],
          "editableUntil" : "2021-11-17T22:04:57.187Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "47",
              "57"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6rc2c3bwRn",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/58",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "93",
              "116"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1461085473468780545/photo/1",
            "indices" : [
              "130",
              "153"
            ],
            "url" : "https://t.co/pf6ZSUdmSO",
            "media_url" : "http://pbs.twimg.com/media/FEbRZCtX0AQz9Kk.png",
            "id_str" : "1461085357282414596",
            "id" : "1461085357282414596",
            "media_url_https" : "https://pbs.twimg.com/media/FEbRZCtX0AQz9Kk.png",
            "sizes" : {
              "small" : {
                "w" : "594",
                "h" : "330",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "594",
                "h" : "330",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "594",
                "h" : "330",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/pf6ZSUdmSO"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "117",
              "129"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "153"
      ],
      "favorite_count" : "3",
      "id_str" : "1461085473468780545",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1461085473468780545",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 17 21:34:57 +0000 2021",
      "favorited" : false,
      "full_text" : "Fragment elaboration and synthesis planning by @dana_klug and Kato Leonard for a MurD binder https://t.co/6rc2c3bwRn #openscience https://t.co/pf6ZSUdmSO",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1461085473468780545/photo/1",
            "indices" : [
              "130",
              "153"
            ],
            "url" : "https://t.co/pf6ZSUdmSO",
            "media_url" : "http://pbs.twimg.com/media/FEbRZCtX0AQz9Kk.png",
            "id_str" : "1461085357282414596",
            "id" : "1461085357282414596",
            "media_url_https" : "https://pbs.twimg.com/media/FEbRZCtX0AQz9Kk.png",
            "sizes" : {
              "small" : {
                "w" : "594",
                "h" : "330",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "594",
                "h" : "330",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "594",
                "h" : "330",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/pf6ZSUdmSO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1455550788437254155"
          ],
          "editableUntil" : "2021-11-02T15:32:05.446Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "52",
              "64"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "95",
              "109"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1455550788437254155",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1455550788437254155",
      "created_at" : "Tue Nov 02 15:02:05 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: V grateful for these ££ to support #openscience drug discovery in Series 1 of @OSantibiotics. Vital support for the public…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1455550144246657026"
          ],
          "editableUntil" : "2021-11-02T15:29:31.859Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "Antibiotic",
            "indices" : [
              "33",
              "44"
            ]
          },
          {
            "text" : "AntibioticResistance",
            "indices" : [
              "94",
              "115"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1455550144246657026",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1455550144246657026",
      "created_at" : "Tue Nov 02 14:59:31 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @1Antruk: We’re funding 7 new #Antibiotic research projects totalling £200,000, supporting #AntibioticResistance research at @dmuleicest…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1451480957060517899"
          ],
          "editableUntil" : "2021-10-22T10:00:02.032Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "135",
              "145"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "146",
              "156"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "157",
              "167"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "168",
              "176"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "177",
              "189"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "190",
              "202"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/esON4JX4hV",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/98",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "111",
              "134"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1451480957060517899/photo/1",
            "indices" : [
              "203",
              "226"
            ],
            "url" : "https://t.co/7f11RQzVWL",
            "media_url" : "http://pbs.twimg.com/media/FCSyF2QXsAIfKsE.png",
            "id_str" : "1451480793453408258",
            "id" : "1451480793453408258",
            "media_url_https" : "https://pbs.twimg.com/media/FCSyF2QXsAIfKsE.png",
            "sizes" : {
              "large" : {
                "w" : "621",
                "h" : "247",
                "resize" : "fit"
              },
              "small" : {
                "w" : "621",
                "h" : "247",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "621",
                "h" : "247",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/7f11RQzVWL"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "226"
      ],
      "favorite_count" : "5",
      "id_str" : "1451480957060517899",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1451480957060517899",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 22 09:30:02 +0000 2021",
      "favorited" : false,
      "full_text" : "Waiting on lovely new potency data from Northeastern and Uni Sao Paulo, so let's postpone till next Friday, K? https://t.co/esON4JX4hV @macinchem @dana_klug @edwintse_ @emeryfs @mfernflower @LoriFerrins https://t.co/7f11RQzVWL",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1451480957060517899/photo/1",
            "indices" : [
              "203",
              "226"
            ],
            "url" : "https://t.co/7f11RQzVWL",
            "media_url" : "http://pbs.twimg.com/media/FCSyF2QXsAIfKsE.png",
            "id_str" : "1451480793453408258",
            "id" : "1451480793453408258",
            "media_url_https" : "https://pbs.twimg.com/media/FCSyF2QXsAIfKsE.png",
            "sizes" : {
              "large" : {
                "w" : "621",
                "h" : "247",
                "resize" : "fit"
              },
              "small" : {
                "w" : "621",
                "h" : "247",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "621",
                "h" : "247",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/7f11RQzVWL"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1151614431039840256"
          ],
          "editableUntil" : "2019-07-17T22:37:30.978Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "37",
              "49"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "51",
              "65"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1151614431039840256",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1151614431039840256",
      "created_at" : "Wed Jul 17 22:07:30 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Over at Open Source #antibiotics (@OSantibiotics) postdoc @Fahima_Chem has made some neat suggestions for elaborated fragm…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1150742160440012801"
          ],
          "editableUntil" : "2019-07-15T12:51:25.461Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "RSC BMCS",
            "screen_name" : "RSC_BMCS",
            "indices" : [
              "80",
              "89"
            ],
            "id_str" : "760549489895698432",
            "id" : "760549489895698432"
          },
          {
            "name" : "RSC_CICAG",
            "screen_name" : "RSC_CICAG",
            "indices" : [
              "94",
              "104"
            ],
            "id_str" : "447019817",
            "id" : "447019817"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1150742160440012801",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1150742160440012801",
      "created_at" : "Mon Jul 15 12:21:25 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @macinchem: We have had a significant unallocated student bursaries for both @RSC_BMCS and @RSC_CICAG meetings over the last few years a…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1150673425700139008"
          ],
          "editableUntil" : "2019-07-15T08:18:17.822Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/c91oaxTlxm",
            "expanded_url" : "https://opensourceantibiotics.github.io/murligase/ngl/examples/MurDwebapp.html?script=interactive/MurE_ligand-viewer",
            "display_url" : "opensourceantibiotics.github.io/murligase/ngl/…",
            "indices" : [
              "58",
              "81"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "81"
      ],
      "favorite_count" : "4",
      "id_str" : "1150673425700139008",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1150673425700139008",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 15 07:48:17 +0000 2019",
      "favorited" : false,
      "full_text" : "You can now view the Mur E fragment hits using NGL viewer https://t.co/c91oaxTlxm",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1148488916707815425"
          ],
          "editableUntil" : "2019-07-09T07:37:50.292Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "43",
              "57"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "63",
              "73"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1148488916707815425",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1148488916707815425",
      "created_at" : "Tue Jul 09 07:07:50 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Fun session talking about @OSantibiotics with @macinchem and @Fahima_Chem at @School_Pharmacy - which compounds to make ne…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1148488703934902274"
          ],
          "editableUntil" : "2019-07-09T07:36:59.563Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotic",
            "indices" : [
              "45",
              "56"
            ]
          },
          {
            "text" : "pneumonia",
            "indices" : [
              "80",
              "90"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1148488703934902274",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1148488703934902274",
      "created_at" : "Tue Jul 09 07:06:59 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @1Antruk: “In all, 93% of the overly long #antibiotic prescriptions given to #pneumonia patients were written at hospital discharge” htt…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1148164287132778497"
          ],
          "editableUntil" : "2019-07-08T10:07:52.570Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Y97tI4ZpI3",
            "expanded_url" : "https://twitter.com/RSC_BMCS/status/1148152612119859201",
            "display_url" : "twitter.com/RSC_BMCS/statu…",
            "indices" : [
              "42",
              "65"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "0",
      "id_str" : "1148164287132778497",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1148164287132778497",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 08 09:37:52 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @macinchem: This should be interesting https://t.co/Y97tI4ZpI3",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1144879920079921152"
          ],
          "editableUntil" : "2019-06-29T08:36:58.444Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          },
          {
            "name" : "The Telegraph",
            "screen_name" : "Telegraph",
            "indices" : [
              "44",
              "54"
            ],
            "id_str" : "16343974",
            "id" : "16343974"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1144879920079921152",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1144879920079921152",
      "created_at" : "Sat Jun 29 08:06:58 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @Wellcome_AMR: Interesting research from @Telegraph showing UK public think that superbugs should be the top research priority for the s…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1144879779981737986"
          ],
          "editableUntil" : "2019-06-29T08:36:25.042Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "DiseaseDetectives",
            "indices" : [
              "37",
              "55"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "",
            "screen_name" : "PHE_uk",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "-1",
            "id" : "-1"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1144879779981737986",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1144879779981737986",
      "created_at" : "Sat Jun 29 08:06:25 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @PHE_uk: In our latest edition of #DiseaseDetectives Olivier le Polain, deputy director for operations of the UK Public Health Rapid Sup…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1140989985832747008"
          ],
          "editableUntil" : "2019-06-18T14:59:45.848Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/GMZnHqAREE",
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1140922041866104832",
            "display_url" : "twitter.com/OSantibiotics/…",
            "indices" : [
              "87",
              "110"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "110"
      ],
      "favorite_count" : "0",
      "id_str" : "1140989985832747008",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1140989985832747008",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jun 18 14:29:45 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Awesome way to visualise the bound fragments and design improvements. https://t.co/GMZnHqAREE",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1140922041866104832"
          ],
          "editableUntil" : "2019-06-18T10:29:46.744Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ollxA9eb8l",
            "expanded_url" : "https://opensourceantibiotics.github.io/murligase/ngl/examples/MurDwebapp.html?script=interactive/MurD_ligand-viewer",
            "display_url" : "opensourceantibiotics.github.io/murligase/ngl/…",
            "indices" : [
              "77",
              "100"
            ]
          },
          {
            "url" : "https://t.co/1rr7oMea8a",
            "expanded_url" : "https://www.dropbox.com/s/4ur9l9fohk2vpp1/NGLviewerTemp.mov?dl=0",
            "display_url" : "dropbox.com/s/4ur9l9fohk2v…",
            "indices" : [
              "165",
              "188"
            ]
          },
          {
            "url" : "https://t.co/3bIj7sk9PW",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/1",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "221",
              "244"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "244"
      ],
      "favorite_count" : "2",
      "id_str" : "1140922041866104832",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1140922041866104832",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jun 18 09:59:46 +0000 2019",
      "favorited" : false,
      "full_text" : "There is now an interactive view of the fragments bound to Mur Ligase D here https://t.co/ollxA9eb8l if you are not sure how to use NGL viewer there is a video here https://t.co/1rr7oMea8a\n\nFull details on the issues tab https://t.co/3bIj7sk9PW",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1140921447118004224"
          ],
          "editableUntil" : "2019-06-18T10:27:24.945Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Luc Henry",
            "screen_name" : "heluc",
            "indices" : [
              "17",
              "23"
            ],
            "id_str" : "850645992",
            "id" : "850645992"
          },
          {
            "name" : "Maryn McKenna",
            "screen_name" : "marynmck",
            "indices" : [
              "24",
              "33"
            ],
            "id_str" : "15684633",
            "id" : "15684633"
          },
          {
            "name" : "WIRED",
            "screen_name" : "WIRED",
            "indices" : [
              "34",
              "40"
            ],
            "id_str" : "1344951",
            "id" : "1344951"
          },
          {
            "name" : "Peter",
            "screen_name" : "PeterRolandG",
            "indices" : [
              "41",
              "54"
            ],
            "id_str" : "2396006202",
            "id" : "2396006202"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "101",
              "115"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1140921447118004224",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1140921447118004224",
      "created_at" : "Tue Jun 18 09:57:24 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: @heluc @marynmck @WIRED @PeterRolandG Yes, need new models. Made a small start with @OSantibiotics and early stage project…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1139781213617577986"
          ],
          "editableUntil" : "2019-06-15T06:56:32.094Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "drugdiscovery",
            "indices" : [
              "45",
              "59"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "RSC_CICAG",
            "screen_name" : "RSC_CICAG",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "447019817",
            "id" : "447019817"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/94ihbPMoK2",
            "expanded_url" : "https://www.cambridgemedchemconsulting.com/news/index_files/1a4d73831c75ded42426d12050e37a79-381.html",
            "display_url" : "cambridgemedchemconsulting.com/news/index_fil…",
            "indices" : [
              "60",
              "83"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "83"
      ],
      "favorite_count" : "0",
      "id_str" : "1139781213617577986",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1139781213617577986",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jun 15 06:26:32 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @RSC_CICAG: Early career MedChem workshop #drugdiscovery https://t.co/94ihbPMoK2",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1139781175466217473"
          ],
          "editableUntil" : "2019-06-15T06:56:22.998Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Laura Piddock 💙",
            "screen_name" : "LauraPiddock",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "398581149",
            "id" : "398581149"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1139781175466217473",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1139781175466217473",
      "created_at" : "Sat Jun 15 06:26:22 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @LauraPiddock: Please RT! If anyone has any isolates of Enterobacteriaceae from patients who have been taking the anti-retroviral AZT an…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1139780473092288513"
          ],
          "editableUntil" : "2019-06-15T06:53:35.539Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "aled edwards",
            "screen_name" : "aledmedwards",
            "indices" : [
              "3",
              "16"
            ],
            "id_str" : "202836527",
            "id" : "202836527"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1139780473092288513",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1139780473092288513",
      "created_at" : "Sat Jun 15 06:23:35 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @aledmedwards: I’m looking for examples of drug re-purposing in which a library of drugs was screened in an assay in vitro (hypothesis-f…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1128195203393892352"
          ],
          "editableUntil" : "2019-05-14T07:37:51.999Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AIChem19",
            "indices" : [
              "89",
              "98"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "98"
      ],
      "favorite_count" : "0",
      "id_str" : "1128195203393892352",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1128195203393892352",
      "created_at" : "Tue May 14 07:07:51 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @macinchem: In which area is Artificial Intelligence likely to most impact Chemistry, #AIChem19",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1126475338551308288"
          ],
          "editableUntil" : "2019-05-09T13:43:44.267Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/D7ZOzLg1iP",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/4",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "93",
              "116"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1126475338551308288/photo/1",
            "indices" : [
              "117",
              "140"
            ],
            "url" : "https://t.co/miFHyQJQZD",
            "media_url" : "http://pbs.twimg.com/media/D6ILWV1W4AIyUH_.jpg",
            "id_str" : "1126475335242014722",
            "id" : "1126475335242014722",
            "media_url_https" : "https://pbs.twimg.com/media/D6ILWV1W4AIyUH_.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "389",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "220",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1422",
                "h" : "461",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/miFHyQJQZD"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "4",
      "id_str" : "1126475338551308288",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1126475338551308288",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 09 13:13:44 +0000 2019",
      "favorited" : false,
      "full_text" : "Update. We now have a few more crystal structures and another fragment binding at this site. https://t.co/D7ZOzLg1iP https://t.co/miFHyQJQZD",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1126475338551308288/photo/1",
            "indices" : [
              "117",
              "140"
            ],
            "url" : "https://t.co/miFHyQJQZD",
            "media_url" : "http://pbs.twimg.com/media/D6ILWV1W4AIyUH_.jpg",
            "id_str" : "1126475335242014722",
            "id" : "1126475335242014722",
            "media_url_https" : "https://pbs.twimg.com/media/D6ILWV1W4AIyUH_.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "389",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "220",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1422",
                "h" : "461",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/miFHyQJQZD"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1126444966887268352"
          ],
          "editableUntil" : "2019-05-09T11:43:03.098Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "106",
              "118"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1126444966887268352",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1126444966887268352",
      "created_at" : "Thu May 09 11:13:03 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @1Antruk: “A newly-discovered gene gives infectious bacteria the ability to survive even the strongest #antibiotics”  https://t.co/EUgpR…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1126444900181004289"
          ],
          "editableUntil" : "2019-05-09T11:42:47.194Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "A Woolford",
            "screen_name" : "awoolford76",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "2828747450",
            "id" : "2828747450"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1126444900181004289",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1126444900181004289",
      "created_at" : "Thu May 09 11:12:47 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @awoolford76: Registration is open is open for the \"Twenty Years of the Rule of Five\" conference,\n20th Nov 2019 \nSygnature Discovery, Bi…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1124028352577384449"
          ],
          "editableUntil" : "2019-05-02T19:40:17.348Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Practical_Fragments",
            "screen_name" : "PracticalFrag",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1094656135074697217",
            "id" : "1094656135074697217"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1124028352577384449",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1124028352577384449",
      "created_at" : "Thu May 02 19:10:17 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @PracticalFrag: Practical Fragments ventures on to Twitter. \nOpenSourceAntibiotics has hits against 2 enzymes bacteria need to make cell…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1123871610023436288"
          ],
          "editableUntil" : "2019-05-02T09:17:27.011Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "105",
              "117"
            ]
          },
          {
            "text" : "RealTimeChem",
            "indices" : [
              "119",
              "132"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/KrkNpJWYxL",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "81",
              "104"
            ]
          },
          {
            "url" : "https://t.co/HbfEO1r6bq",
            "expanded_url" : "https://twitter.com/PracticalFrag/status/1123583180898881536",
            "display_url" : "twitter.com/PracticalFrag/…",
            "indices" : [
              "133",
              "156"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "156"
      ],
      "favorite_count" : "1",
      "id_str" : "1123871610023436288",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1123871610023436288",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 02 08:47:27 +0000 2019",
      "favorited" : false,
      "full_text" : "Thanks for this! Any inputs to these fragment-based projects greatly appreciated https://t.co/KrkNpJWYxL #openscience  #RealTimeChem https://t.co/HbfEO1r6bq",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1120445291415658496"
          ],
          "editableUntil" : "2019-04-22T22:22:28.997Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Jeremy Farrar",
            "screen_name" : "JeremyFarrar",
            "indices" : [
              "40",
              "53"
            ],
            "id_str" : "1489776218",
            "id" : "1489776218"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1120445291415658496",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1120445291415658496",
      "created_at" : "Mon Apr 22 21:52:28 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Interesting article by @JeremyFarrar on the Achaogen bankruptcy: We ignore the disaster in the antibiotics market at our p…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1118906411398967296"
          ],
          "editableUntil" : "2019-04-18T16:27:31.410Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "15",
              "23"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          },
          {
            "name" : "BioSolveIT",
            "screen_name" : "biosolveit",
            "indices" : [
              "24",
              "35"
            ],
            "id_str" : "1314525222",
            "id" : "1314525222"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "36",
              "50"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Stop Superbugs",
            "screen_name" : "TheUrgentNeed",
            "indices" : [
              "51",
              "65"
            ],
            "id_str" : "384787749",
            "id" : "384787749"
          },
          {
            "name" : "APPG on Antibiotics",
            "screen_name" : "APPGantibiotics",
            "indices" : [
              "66",
              "82"
            ],
            "id_str" : "1549966591",
            "id" : "1549966591"
          },
          {
            "name" : "Enamine Ltd 🇺🇦",
            "screen_name" : "EnamineLtd",
            "indices" : [
              "83",
              "94"
            ],
            "id_str" : "1655695452",
            "id" : "1655695452"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1118906411398967296",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1118906411398967296",
      "created_at" : "Thu Apr 18 15:57:31 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @macinchem: @MrBenGP @biosolveit @OSantibiotics @TheUrgentNeed @APPGantibiotics @EnamineLtd Why not run a competition. Use the software…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1118847051134009345"
          ],
          "editableUntil" : "2019-04-18T12:31:38.820Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Susan Hopkins",
            "screen_name" : "SMHopkins",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "19585645",
            "id" : "19585645"
          },
          {
            "name" : "UCL",
            "screen_name" : "ucl",
            "indices" : [
              "11",
              "15"
            ],
            "id_str" : "322601789",
            "id" : "322601789"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "103",
              "115"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Open Source TB",
            "screen_name" : "OpenSourceTB",
            "indices" : [
              "137",
              "150"
            ],
            "id_str" : "2320704158",
            "id" : "2320704158"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/gOIddMqpnP",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "53",
              "76"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "150"
      ],
      "favorite_count" : "0",
      "in_reply_to_status_id_str" : "481450176834715648",
      "id_str" : "1118847051134009345",
      "in_reply_to_user_id" : "19585645",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1118847051134009345",
      "in_reply_to_status_id" : "481450176834715648",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 18 12:01:38 +0000 2019",
      "favorited" : false,
      "full_text" : "@SMHopkins @ucl FYI on the Mur ligases - new project https://t.co/gOIddMqpnP and a UCL connection with @MatToddChem and even potentially @OpenSourceTB",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "in_reply_to_screen_name" : "SMHopkins",
      "in_reply_to_user_id_str" : "19585645"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1118846391529496577"
          ],
          "editableUntil" : "2019-04-18T12:29:01.558Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "logistics",
            "indices" : [
              "155",
              "165"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/Ci8bMeDh8j",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/2",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "131",
              "154"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "186"
      ],
      "favorite_count" : "1",
      "id_str" : "1118846391529496577",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1118846391529496577",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 18 11:59:01 +0000 2019",
      "favorited" : false,
      "full_text" : "Open source antibiotics, Mur Ligase project. Issue 2. How are we going to do things like data/sample storage, screening, shipping. https://t.co/Ci8bMeDh8j #logistics suggestions welcome.",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1118787389898612741"
          ],
          "editableUntil" : "2019-04-18T08:34:34.473Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "113",
              "123"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Stop Superbugs",
            "screen_name" : "TheUrgentNeed",
            "indices" : [
              "197",
              "211"
            ],
            "id_str" : "384787749",
            "id" : "384787749"
          },
          {
            "name" : "APPG on Antibiotics",
            "screen_name" : "APPGantibiotics",
            "indices" : [
              "212",
              "228"
            ],
            "id_str" : "1549966591",
            "id" : "1549966591"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/3bIj7sk9PW",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/1",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "89",
              "112"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1118787389898612741/photo/1",
            "indices" : [
              "242",
              "265"
            ],
            "url" : "https://t.co/YJgBSshJxK",
            "media_url" : "http://pbs.twimg.com/media/D4a7KBhWkAAgzQP.png",
            "id_str" : "1118787338329559040",
            "id" : "1118787338329559040",
            "media_url_https" : "https://pbs.twimg.com/media/D4a7KBhWkAAgzQP.png",
            "sizes" : {
              "large" : {
                "w" : "610",
                "h" : "398",
                "resize" : "fit"
              },
              "small" : {
                "w" : "610",
                "h" : "398",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "610",
                "h" : "398",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/YJgBSshJxK"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "229",
              "241"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "265"
      ],
      "favorite_count" : "3",
      "id_str" : "1118787389898612741",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1118787389898612741",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 18 08:04:34 +0000 2019",
      "favorited" : false,
      "full_text" : "Inputs needed. Issue 1, MurD ligase. Based on current data, which fragments to buy next? https://t.co/3bIj7sk9PW @macinchem has already suggested some. Money available to purchase new suggestions. @TheUrgentNeed @APPGantibiotics #openscience https://t.co/YJgBSshJxK",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1118787389898612741/photo/1",
            "indices" : [
              "242",
              "265"
            ],
            "url" : "https://t.co/YJgBSshJxK",
            "media_url" : "http://pbs.twimg.com/media/D4a7KBhWkAAgzQP.png",
            "id_str" : "1118787338329559040",
            "id" : "1118787338329559040",
            "media_url_https" : "https://pbs.twimg.com/media/D4a7KBhWkAAgzQP.png",
            "sizes" : {
              "large" : {
                "w" : "610",
                "h" : "398",
                "resize" : "fit"
              },
              "small" : {
                "w" : "610",
                "h" : "398",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "610",
                "h" : "398",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/YJgBSshJxK"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1118787016622268416"
          ],
          "editableUntil" : "2019-04-18T08:33:05.477Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "271",
              "283"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Structural Genomics Consortium (SGC)",
            "screen_name" : "thesgconline",
            "indices" : [
              "143",
              "156"
            ],
            "id_str" : "131149338",
            "id" : "131149338"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "157",
              "167"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Life Sciences",
            "screen_name" : "WarwickLifeSci",
            "indices" : [
              "168",
              "183"
            ],
            "id_str" : "63104737",
            "id" : "63104737"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "184",
              "196"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "234",
              "244"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          },
          {
            "name" : "CO-ADD Antibiotics",
            "screen_name" : "COADD_news",
            "indices" : [
              "245",
              "256"
            ],
            "id_str" : "3045189728",
            "id" : "3045189728"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "257",
              "270"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/gOIddMqpnP",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "209",
              "232"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "283"
      ],
      "favorite_count" : "13",
      "id_str" : "1118787016622268416",
      "truncated" : false,
      "retweet_count" : "11",
      "id" : "1118787016622268416",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 18 08:03:05 +0000 2019",
      "favorited" : false,
      "full_text" : "We're LIVE. Open source principles -&gt; new antibiotics. Everything shared, anyone may take part, no patents. 1st project: Mur Ligases, feat. @thesgconline @macinchem @WarwickLifeSci @mattoddchem and .. you? https://t.co/gOIddMqpnP  @gardp_amr @COADD_news @Wellcome_AMR #OpenScience",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1111631707457884160"
          ],
          "editableUntil" : "2019-03-29T14:40:26.833Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com\" rel=\"nofollow\">Twitter Web Client</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotic",
            "indices" : [
              "124",
              "135"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "136",
              "150"
            ]
          },
          {
            "text" : "opensource",
            "indices" : [
              "151",
              "162"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/n3HYY31sq5",
            "expanded_url" : "https://github.com/opensourceantibiotics",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "60",
              "83"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "162"
      ],
      "favorite_count" : "0",
      "id_str" : "1111631707457884160",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1111631707457884160",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 29 14:10:26 +0000 2019",
      "favorited" : false,
      "full_text" : "The Open Source Antibiotics website is now up and running.\n\nhttps://t.co/n3HYY31sq5\n\nHave a browse, all welcome to join in! #antibiotic #drugdiscovery #opensource",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1443872183957311507"
          ],
          "editableUntil" : "2021-10-01T10:05:29.160Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "76",
              "90"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "135",
              "145"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "221",
              "231"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "232",
              "242"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "243",
              "255"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "256",
              "264"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/D5LK84U8oY",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/95",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "111",
              "134"
            ]
          },
          {
            "url" : "https://t.co/FsM2lVJx8T",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/94",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "184",
              "207"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1443872183957311507/photo/1",
            "indices" : [
              "265",
              "288"
            ],
            "url" : "https://t.co/vySMOrLuAX",
            "media_url" : "http://pbs.twimg.com/media/FAmqDIqX0A0kyvb.png",
            "id_str" : "1443872126390489101",
            "id" : "1443872126390489101",
            "media_url_https" : "https://pbs.twimg.com/media/FAmqDIqX0A0kyvb.png",
            "sizes" : {
              "large" : {
                "w" : "840",
                "h" : "600",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "486",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "840",
                "h" : "600",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/vySMOrLuAX"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "208",
              "220"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "288"
      ],
      "favorite_count" : "6",
      "id_str" : "1443872183957311507",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1443872183957311507",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 01 09:35:29 +0000 2021",
      "favorited" : false,
      "full_text" : "It'll be a Structure-Activity-Relationship-Matched-Pair festival in today's @OSantibiotics meeting on Series 2 https://t.co/D5LK84U8oY @dana_klug has nicely summarised where we are in https://t.co/FsM2lVJx8T #OpenScience @macinchem @edwintse_ @LoriFerrins @emeryfs https://t.co/vySMOrLuAX",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1443872183957311507/photo/1",
            "indices" : [
              "265",
              "288"
            ],
            "url" : "https://t.co/vySMOrLuAX",
            "media_url" : "http://pbs.twimg.com/media/FAmqDIqX0A0kyvb.png",
            "id_str" : "1443872126390489101",
            "id" : "1443872126390489101",
            "media_url_https" : "https://pbs.twimg.com/media/FAmqDIqX0A0kyvb.png",
            "sizes" : {
              "large" : {
                "w" : "840",
                "h" : "600",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "486",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "840",
                "h" : "600",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/vySMOrLuAX"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1440616601468895233"
          ],
          "editableUntil" : "2021-09-22T10:28:57.809Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "124",
              "134"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "135",
              "147"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "148",
              "158"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "159",
              "169"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "170",
              "178"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "179",
              "191"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "PharmAlliance",
            "screen_name" : "PhrmAlliance",
            "indices" : [
              "192",
              "205"
            ],
            "id_str" : "1278306772747456513",
            "id" : "1278306772747456513"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/hANBKUe4L2",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/93",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "100",
              "123"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "205"
      ],
      "favorite_count" : "3",
      "id_str" : "1440616601468895233",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1440616601468895233",
      "possibly_sensitive" : false,
      "created_at" : "Wed Sep 22 09:58:57 +0000 2021",
      "favorited" : false,
      "full_text" : "Postponing this week's meeting to next week - clash/holidays. Current stuff, incl new eval vs MRSA! https://t.co/hANBKUe4L2 @macinchem @MatToddChem @dana_klug @edwintse_ @emeryfs @LoriFerrins @PhrmAlliance",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1438436554716893186"
          ],
          "editableUntil" : "2021-09-16T10:06:14.160Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "128",
              "138"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "139",
              "151"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "152",
              "160"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "161",
              "173"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/5WWccjJYUW",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/89#issuecomment-920743491",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "91",
              "114"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1438436554716893186/photo/1",
            "indices" : [
              "174",
              "197"
            ],
            "url" : "https://t.co/1azMEmbcC5",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/E_Zaa1JXoAUmM88.jpg",
            "id_str" : "1438436547980926981",
            "id" : "1438436547980926981",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/E_Zaa1JXoAUmM88.jpg",
            "sizes" : {
              "medium" : {
                "w" : "498",
                "h" : "230",
                "resize" : "fit"
              },
              "small" : {
                "w" : "498",
                "h" : "230",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "498",
                "h" : "230",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/1azMEmbcC5"
          }
        ],
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "115",
              "127"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "197"
      ],
      "favorite_count" : "4",
      "id_str" : "1438436554716893186",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1438436554716893186",
      "possibly_sensitive" : false,
      "created_at" : "Thu Sep 16 09:36:14 +0000 2021",
      "favorited" : false,
      "full_text" : "Postponing this Friday's meeting to next week (24th, same time same place). Current stuff: https://t.co/5WWccjJYUW #antibiotics @macinchem @mfernflower @emeryfs @LoriFerrins https://t.co/1azMEmbcC5",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1438436554716893186/photo/1",
            "indices" : [
              "174",
              "197"
            ],
            "url" : "https://t.co/1azMEmbcC5",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/E_Zaa1JXoAUmM88.jpg",
            "id_str" : "1438436547980926981",
            "video_info" : {
              "aspect_ratio" : [
                "249",
                "115"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/E_Zaa1JXoAUmM88.mp4"
                }
              ]
            },
            "id" : "1438436547980926981",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/E_Zaa1JXoAUmM88.jpg",
            "sizes" : {
              "medium" : {
                "w" : "498",
                "h" : "230",
                "resize" : "fit"
              },
              "small" : {
                "w" : "498",
                "h" : "230",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "498",
                "h" : "230",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/1azMEmbcC5"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1436326479781056520"
          ],
          "editableUntil" : "2021-09-10T14:21:33.092Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MRSA",
            "indices" : [
              "12",
              "17"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "193",
              "205"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "165",
              "175"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "UCL School of Pharmacy",
            "screen_name" : "School_Pharmacy",
            "indices" : [
              "176",
              "192"
            ],
            "id_str" : "56353603",
            "id" : "56353603"
          },
          {
            "name" : "The Pew Trusts",
            "screen_name" : "pewtrusts",
            "indices" : [
              "206",
              "216"
            ],
            "id_str" : "15738935",
            "id" : "15738935"
          },
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "217",
              "225"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          },
          {
            "name" : "CO-ADD Antibiotics",
            "screen_name" : "COADD_news",
            "indices" : [
              "226",
              "237"
            ],
            "id_str" : "3045189728",
            "id" : "3045189728"
          },
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "238",
              "248"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "249",
              "262"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          },
          {
            "name" : "IMI AMR ACCELERATOR",
            "screen_name" : "AMRAccelerator",
            "indices" : [
              "263",
              "278"
            ],
            "id_str" : "1202241406615588864",
            "id" : "1202241406615588864"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Enl0Cm1n4m",
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1430545366408212481",
            "display_url" : "twitter.com/OSantibiotics/…",
            "indices" : [
              "279",
              "302"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "302"
      ],
      "favorite_count" : "1",
      "id_str" : "1436326479781056520",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1436326479781056520",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 10 13:51:33 +0000 2021",
      "favorited" : false,
      "full_text" : "Anyone have #MRSA lysate? We need it for some mechanism of action experiments. Please RT or suggest academic/industrial groups who might know! Ideally North America @macinchem @School_Pharmacy #antibiotics @pewtrusts @1Antruk @COADD_news @gardp_amr @Wellcome_AMR @AMRAccelerator https://t.co/Enl0Cm1n4m",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1435941750024155147"
          ],
          "editableUntil" : "2021-09-09T12:52:46.370Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "20",
              "34"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/RLBDYM3CgV",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/89",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "108",
              "131"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1435941750024155147",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1435941750024155147",
      "possibly_sensitive" : false,
      "created_at" : "Thu Sep 09 12:22:46 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @edwintse_: Next @OSantibiotics meeting tomorrow (Friday 10th Sept) 2 pm UK time. Agenda for the meeting https://t.co/RLBDYM3CgV #antibi…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1434909449936846852"
          ],
          "editableUntil" : "2021-09-06T16:30:46.850Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "205",
              "217"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "218",
              "230"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/K1I7ksIdz8",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/50",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "58",
              "81"
            ]
          },
          {
            "url" : "https://t.co/7YJUoUIe5F",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/51",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "114",
              "137"
            ]
          },
          {
            "url" : "https://t.co/HVSchc4Sds",
            "expanded_url" : "https://docs.google.com/forms/d/e/1FAIpQLSf4UieL5pRQqN5rOL4q-t57qcpJhHG_jqMXV774FPUJBmnBbQ/viewform",
            "display_url" : "docs.google.com/forms/d/e/1FAI…",
            "indices" : [
              "181",
              "204"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "230"
      ],
      "favorite_count" : "0",
      "id_str" : "1434909449936846852",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1434909449936846852",
      "possibly_sensitive" : false,
      "created_at" : "Mon Sep 06 16:00:46 +0000 2021",
      "favorited" : false,
      "full_text" : "Series 1 - mur ligases. Doing written updates this month (https://t.co/K1I7ksIdz8) -next meeting will be Oct 5th: https://t.co/7YJUoUIe5F Want to be kept in loop? Sign up to alerts https://t.co/HVSchc4Sds #antibiotics #openscience",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1430791598783307779"
          ],
          "editableUntil" : "2021-08-26T07:47:54.629Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/pFf54w7En6",
            "expanded_url" : "https://pubs.acs.org/doi/10.1021/acs.jchemed.1c00289#.YSdACrt_o6w.twitter",
            "display_url" : "pubs.acs.org/doi/10.1021/ac…",
            "indices" : [
              "195",
              "218"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "218"
      ],
      "favorite_count" : "4",
      "id_str" : "1430791598783307779",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1430791598783307779",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 26 07:17:54 +0000 2021",
      "favorited" : false,
      "full_text" : "Molecular Docking with Open Access Software: Development of an Online Laboratory Handbook and Remote Workflow for Chemistry and Pharmacy Master’s Students to Undertake Computer-Aided Drug Design https://t.co/pFf54w7En6",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1430545366408212481"
          ],
          "editableUntil" : "2021-08-25T15:29:28.256Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "MRSA",
            "indices" : [
              "30",
              "35"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UNC Pharmacy",
            "screen_name" : "UNCPharmacy",
            "indices" : [
              "197",
              "209"
            ],
            "id_str" : "15750564",
            "id" : "15750564"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "210",
              "220"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "221",
              "231"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "232",
              "240"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "241",
              "253"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "254",
              "264"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/LlsQBuecyD",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/15",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "85",
              "108"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "264"
      ],
      "favorite_count" : "3",
      "id_str" : "1430545366408212481",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1430545366408212481",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 25 14:59:28 +0000 2021",
      "favorited" : false,
      "full_text" : "We need to secure a sample of #MRSA lysate for some mechanism of action experiments. https://t.co/LlsQBuecyD Our original source has dried up. Does anyone have any? Destined for Lee Graves' lab at @UNCPharmacy @dana_klug @edwintse_ @MrBenGP @LoriFerrins @gardp_amr",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1427182874202083328"
          ],
          "editableUntil" : "2021-08-16T08:48:07.642Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Jan Jensen (@janhjensen@mastodon.social)",
            "screen_name" : "janhjensen",
            "indices" : [
              "34",
              "45"
            ],
            "id_str" : "223934260",
            "id" : "223934260"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1427182874202083328",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1427182874202083328",
      "created_at" : "Mon Aug 16 08:18:07 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Nice analysis by @janhjensen of value of docking algorithms e.g. Glide in predicting binders, and applying this to mur lig…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1423258787159359490"
          ],
          "editableUntil" : "2021-08-05T12:55:12.385Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "113",
              "125"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "126",
              "136"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "137",
              "147"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "148",
              "158"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "159",
              "174"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "175",
              "187"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "188",
              "196"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "197",
              "209"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/kHkKNETTax",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/87",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "89",
              "112"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1423258787159359490/photo/1",
            "indices" : [
              "223",
              "246"
            ],
            "url" : "https://t.co/hSaOQ36cDa",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/E8BuUfHXoAAUvr2.jpg",
            "id_str" : "1423258780477923328",
            "id" : "1423258780477923328",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/E8BuUfHXoAAUvr2.jpg",
            "sizes" : {
              "small" : {
                "w" : "500",
                "h" : "282",
                "resize" : "fit"
              },
              "large" : {
                "w" : "500",
                "h" : "282",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "500",
                "h" : "282",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/hSaOQ36cDa"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "210",
              "222"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "246"
      ],
      "favorite_count" : "4",
      "id_str" : "1423258787159359490",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1423258787159359490",
      "possibly_sensitive" : false,
      "created_at" : "Thu Aug 05 12:25:12 +0000 2021",
      "favorited" : false,
      "full_text" : "Draft agenda posted for tomorrow's meeting, but probably incomplete. Please add/tweak... https://t.co/kHkKNETTax @MatToddChem @macinchem @dana_klug @edwintse_ @GiadasabatinoC @mfernflower @emeryfs @LoriFerrins #OpenScience https://t.co/hSaOQ36cDa",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1423258787159359490/photo/1",
            "indices" : [
              "223",
              "246"
            ],
            "url" : "https://t.co/hSaOQ36cDa",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/E8BuUfHXoAAUvr2.jpg",
            "id_str" : "1423258780477923328",
            "video_info" : {
              "aspect_ratio" : [
                "250",
                "141"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/E8BuUfHXoAAUvr2.mp4"
                }
              ]
            },
            "id" : "1423258780477923328",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/E8BuUfHXoAAUvr2.jpg",
            "sizes" : {
              "small" : {
                "w" : "500",
                "h" : "282",
                "resize" : "fit"
              },
              "large" : {
                "w" : "500",
                "h" : "282",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "500",
                "h" : "282",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/hSaOQ36cDa"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1422137235344867328"
          ],
          "editableUntil" : "2021-08-02T10:38:33.595Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Northeastern U.",
            "screen_name" : "Northeastern",
            "indices" : [
              "33",
              "46"
            ],
            "id_str" : "46477409",
            "id" : "46477409"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "50",
              "60"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Drugs for Neglected Diseases initiative",
            "screen_name" : "DNDi",
            "indices" : [
              "76",
              "81"
            ],
            "id_str" : "256440168",
            "id" : "256440168"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/7o8X0agJZ9",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/86",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "128",
              "151"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1422137235344867328/photo/1",
            "indices" : [
              "184",
              "207"
            ],
            "url" : "https://t.co/pQtahQ6Vwp",
            "media_url" : "http://pbs.twimg.com/media/E7xxwHOXoAEGOSw.png",
            "id_str" : "1422136653729210369",
            "id" : "1422136653729210369",
            "media_url_https" : "https://pbs.twimg.com/media/E7xxwHOXoAEGOSw.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "446",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "870",
                "h" : "570",
                "resize" : "fit"
              },
              "large" : {
                "w" : "870",
                "h" : "570",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/pQtahQ6Vwp"
          }
        ],
        "hashtags" : [
          {
            "text" : "NTDs",
            "indices" : [
              "152",
              "157"
            ]
          },
          {
            "text" : "repurposing",
            "indices" : [
              "158",
              "170"
            ]
          },
          {
            "text" : "OpenScience",
            "indices" : [
              "171",
              "183"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "207"
      ],
      "favorite_count" : "6",
      "id_str" : "1422137235344867328",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1422137235344867328",
      "possibly_sensitive" : false,
      "created_at" : "Mon Aug 02 10:08:33 +0000 2021",
      "favorited" : false,
      "full_text" : "Antibiotic candidates shipped to @Northeastern by @dana_klug for evaluation @DNDi against T. cruzi, T. brucei, and L. infantum. https://t.co/7o8X0agJZ9 #NTDs #repurposing #OpenScience https://t.co/pQtahQ6Vwp",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1422137235344867328/photo/1",
            "indices" : [
              "184",
              "207"
            ],
            "url" : "https://t.co/pQtahQ6Vwp",
            "media_url" : "http://pbs.twimg.com/media/E7xxwHOXoAEGOSw.png",
            "id_str" : "1422136653729210369",
            "id" : "1422136653729210369",
            "media_url_https" : "https://pbs.twimg.com/media/E7xxwHOXoAEGOSw.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "446",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "870",
                "h" : "570",
                "resize" : "fit"
              },
              "large" : {
                "w" : "870",
                "h" : "570",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/pQtahQ6Vwp"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1419781859261751299"
          ],
          "editableUntil" : "2021-07-26T22:39:08.176Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UCL School of Pharmacy",
            "screen_name" : "School_Pharmacy",
            "indices" : [
              "68",
              "84"
            ],
            "id_str" : "56353603",
            "id" : "56353603"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "124",
              "134"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "135",
              "147"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "148",
              "163"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/h6Pl9cTZKt",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/84",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "190",
              "213"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1419781859261751299/photo/1",
            "indices" : [
              "214",
              "237"
            ],
            "url" : "https://t.co/qnNDOrvoMO",
            "media_url" : "http://pbs.twimg.com/media/E7QT2U3XEAgaOrW.jpg",
            "id_str" : "1419781606563319816",
            "id" : "1419781606563319816",
            "media_url_https" : "https://pbs.twimg.com/media/E7QT2U3XEAgaOrW.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "715",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "405",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1634",
                "h" : "974",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/qnNDOrvoMO"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "164",
              "176"
            ]
          },
          {
            "text" : "Antibiotics",
            "indices" : [
              "177",
              "189"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "237"
      ],
      "favorite_count" : "6",
      "id_str" : "1419781859261751299",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1419781859261751299",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jul 26 22:09:08 +0000 2021",
      "favorited" : false,
      "full_text" : "Next 12 molecules in Series 2 dropped off for evaluation vs MRSA at @School_Pharmacy, fingers crossed. These compounds from @dana_klug @LoriFerrins @GiadasabatinoC #openscience #Antibiotics https://t.co/h6Pl9cTZKt https://t.co/qnNDOrvoMO",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1419781859261751299/photo/1",
            "indices" : [
              "214",
              "237"
            ],
            "url" : "https://t.co/qnNDOrvoMO",
            "media_url" : "http://pbs.twimg.com/media/E7QT2U3XEAgaOrW.jpg",
            "id_str" : "1419781606563319816",
            "id" : "1419781606563319816",
            "media_url_https" : "https://pbs.twimg.com/media/E7QT2U3XEAgaOrW.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "715",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "405",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1634",
                "h" : "974",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/qnNDOrvoMO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1417437121032474633"
          ],
          "editableUntil" : "2021-07-20T11:21:59.019Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "GitHub",
            "screen_name" : "github",
            "indices" : [
              "97",
              "104"
            ],
            "id_str" : "13334762",
            "id" : "13334762"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "260",
              "273"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/hqFgVwfMg5",
            "expanded_url" : "https://www.youtube.com/playlist?list=PL0eLxnHhou_k1Upbn5X1mdHBwKMYkRpLH",
            "display_url" : "youtube.com/playlist?list=…",
            "indices" : [
              "66",
              "89"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1417437121032474633/photo/1",
            "indices" : [
              "274",
              "297"
            ],
            "url" : "https://t.co/ktylppoqP7",
            "media_url" : "http://pbs.twimg.com/media/E6u_S3ZX0Bk16HP.jpg",
            "id_str" : "1417436838567071769",
            "id" : "1417436838567071769",
            "media_url_https" : "https://pbs.twimg.com/media/E6u_S3ZX0Bk16HP.jpg",
            "sizes" : {
              "large" : {
                "w" : "1316",
                "h" : "694",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "633",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "359",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ktylppoqP7"
          }
        ],
        "hashtags" : [
          {
            "text" : "Antibiotics",
            "indices" : [
              "16",
              "28"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "242",
              "254"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "255",
              "259"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "297"
      ],
      "favorite_count" : "3",
      "id_str" : "1417437121032474633",
      "truncated" : false,
      "retweet_count" : "7",
      "id" : "1417437121032474633",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jul 20 10:51:59 +0000 2021",
      "favorited" : false,
      "full_text" : "All Open Source #Antibiotics meetings are freely available online https://t.co/hqFgVwfMg5 and on @github - a key part of keeping people involved and up to date. Next meeting on Series 1 is on July 23rd. Next one on mur ligases on August 3rd. #openscience #AMR @Wellcome_AMR https://t.co/ktylppoqP7",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1417437121032474633/photo/1",
            "indices" : [
              "274",
              "297"
            ],
            "url" : "https://t.co/ktylppoqP7",
            "media_url" : "http://pbs.twimg.com/media/E6u_S3ZX0Bk16HP.jpg",
            "id_str" : "1417436838567071769",
            "id" : "1417436838567071769",
            "media_url_https" : "https://pbs.twimg.com/media/E6u_S3ZX0Bk16HP.jpg",
            "sizes" : {
              "large" : {
                "w" : "1316",
                "h" : "694",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "633",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "359",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ktylppoqP7"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1413085093481095168"
          ],
          "editableUntil" : "2021-07-08T11:08:34.794Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "164",
              "176"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "177",
              "187"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "188",
              "198"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "199",
              "209"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "210",
              "222"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "223",
              "231"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "232",
              "244"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "245",
              "260"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/yCgxUKudS6",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/82",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "140",
              "163"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1413085093481095168/photo/1",
            "indices" : [
              "275",
              "298"
            ],
            "url" : "https://t.co/DlWUetj1PR",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/E5xJZlEXsAEZtdS.jpg",
            "id_str" : "1413085086883491841",
            "id" : "1413085086883491841",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/E5xJZlEXsAEZtdS.jpg",
            "sizes" : {
              "large" : {
                "w" : "450",
                "h" : "338",
                "resize" : "fit"
              },
              "small" : {
                "w" : "450",
                "h" : "338",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "450",
                "h" : "338",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/DlWUetj1PR"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "262",
              "274"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "298"
      ],
      "favorite_count" : "7",
      "id_str" : "1413085093481095168",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1413085093481095168",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jul 08 10:38:34 +0000 2021",
      "favorited" : false,
      "full_text" : "No meeting tomorrow: Lee Graves can come along and update us on MoA experiments *next* week (wait for it...) so we'll gather then. Actions: https://t.co/yCgxUKudS6 @MatToddChem @macinchem @dana_klug @edwintse_ @LoriFerrins @emeryfs @mfernflower @GiadasabatinoC  #OpenScience https://t.co/DlWUetj1PR",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1413085093481095168/photo/1",
            "indices" : [
              "275",
              "298"
            ],
            "url" : "https://t.co/DlWUetj1PR",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/E5xJZlEXsAEZtdS.jpg",
            "id_str" : "1413085086883491841",
            "video_info" : {
              "aspect_ratio" : [
                "225",
                "169"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/E5xJZlEXsAEZtdS.mp4"
                }
              ]
            },
            "id" : "1413085086883491841",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/E5xJZlEXsAEZtdS.jpg",
            "sizes" : {
              "large" : {
                "w" : "450",
                "h" : "338",
                "resize" : "fit"
              },
              "small" : {
                "w" : "450",
                "h" : "338",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "450",
                "h" : "338",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/DlWUetj1PR"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1408399424083070977"
          ],
          "editableUntil" : "2021-06-25T12:49:24.154Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "97",
              "109"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "110",
              "120"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "121",
              "136"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "137",
              "149"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "150",
              "158"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "159",
              "169"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "170",
              "180"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "181",
              "193"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/x5JXl7CGGj",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/79",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "23",
              "46"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1408399424083070977/photo/1",
            "indices" : [
              "194",
              "217"
            ],
            "url" : "https://t.co/r8WXIPlCPS",
            "media_url" : "http://pbs.twimg.com/media/E4ujeZAWQAE8sL9.png",
            "id_str" : "1408399050987159553",
            "id" : "1408399050987159553",
            "media_url_https" : "https://pbs.twimg.com/media/E4ujeZAWQAE8sL9.png",
            "sizes" : {
              "small" : {
                "w" : "396",
                "h" : "279",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "396",
                "h" : "279",
                "resize" : "fit"
              },
              "large" : {
                "w" : "396",
                "h" : "279",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/r8WXIPlCPS"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "71",
              "83"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "84",
              "96"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "217"
      ],
      "favorite_count" : "2",
      "id_str" : "1408399424083070977",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1408399424083070977",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jun 25 12:19:24 +0000 2021",
      "favorited" : false,
      "full_text" : "Today's meeting agenda https://t.co/x5JXl7CGGj Kick-off at 2pm London. #openscience #antibiotics @MatToddChem @macinchem @GiadasabatinoC @LoriFerrins @emeryfs @dana_klug @edwintse_ @mfernflower https://t.co/r8WXIPlCPS",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1408399424083070977/photo/1",
            "indices" : [
              "194",
              "217"
            ],
            "url" : "https://t.co/r8WXIPlCPS",
            "media_url" : "http://pbs.twimg.com/media/E4ujeZAWQAE8sL9.png",
            "id_str" : "1408399050987159553",
            "id" : "1408399050987159553",
            "media_url_https" : "https://pbs.twimg.com/media/E4ujeZAWQAE8sL9.png",
            "sizes" : {
              "small" : {
                "w" : "396",
                "h" : "279",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "396",
                "h" : "279",
                "resize" : "fit"
              },
              "large" : {
                "w" : "396",
                "h" : "279",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/r8WXIPlCPS"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1405153341731127299"
          ],
          "editableUntil" : "2021-06-16T13:50:37.812Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UCL School of Pharmacy",
            "screen_name" : "School_Pharmacy",
            "indices" : [
              "56",
              "72"
            ],
            "id_str" : "56353603",
            "id" : "56353603"
          },
          {
            "name" : "GitHub",
            "screen_name" : "github",
            "indices" : [
              "166",
              "173"
            ],
            "id_str" : "13334762",
            "id" : "13334762"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/CoJMjjH0Lr",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/76",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "82",
              "105"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1405153341731127299/photo/1",
            "indices" : [
              "226",
              "249"
            ],
            "url" : "https://t.co/9S6vyqAK3x",
            "media_url" : "http://pbs.twimg.com/media/E4AbVsFVEAYkI1A.png",
            "id_str" : "1405153143164309510",
            "id" : "1405153143164309510",
            "media_url_https" : "https://pbs.twimg.com/media/E4AbVsFVEAYkI1A.png",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "804",
                "h" : "388",
                "resize" : "fit"
              },
              "large" : {
                "w" : "804",
                "h" : "388",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "328",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/9S6vyqAK3x"
          }
        ],
        "hashtags" : [
          {
            "text" : "MRSA",
            "indices" : [
              "76",
              "81"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "200",
              "212"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "213",
              "225"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "249"
      ],
      "favorite_count" : "6",
      "id_str" : "1405153341731127299",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1405153341731127299",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jun 16 13:20:37 +0000 2021",
      "favorited" : false,
      "full_text" : "Current set of molecules being evaluated in Series 2 at @School_Pharmacy vs #MRSA https://t.co/CoJMjjH0Lr data incoming Thursday, to be discussed Friday 2pm London - @github issue for meeting coming. #antibiotics #openscience https://t.co/9S6vyqAK3x",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1405153341731127299/photo/1",
            "indices" : [
              "226",
              "249"
            ],
            "url" : "https://t.co/9S6vyqAK3x",
            "media_url" : "http://pbs.twimg.com/media/E4AbVsFVEAYkI1A.png",
            "id_str" : "1405153143164309510",
            "id" : "1405153143164309510",
            "media_url_https" : "https://pbs.twimg.com/media/E4AbVsFVEAYkI1A.png",
            "sizes" : {
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "804",
                "h" : "388",
                "resize" : "fit"
              },
              "large" : {
                "w" : "804",
                "h" : "388",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "328",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/9S6vyqAK3x"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1405098831679733763"
          ],
          "editableUntil" : "2021-06-16T10:14:01.603Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "44",
              "56"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/cjXzKQpx11",
            "expanded_url" : "https://wellcomeopenresearch.org/articles/6-146/v1",
            "display_url" : "wellcomeopenresearch.org/articles/6-146…",
            "indices" : [
              "116",
              "139"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1405098831679733763",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1405098831679733763",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jun 16 09:44:01 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: There is no market for new #antibiotics: this allows an open approach to research and development. https://t.co/cjXzKQpx11…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1403300212391751682"
          ],
          "editableUntil" : "2021-06-11T11:06:57.348Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "122",
              "134"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "135",
              "145"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "146",
              "158"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "159",
              "169"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "170",
              "180"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "181",
              "189"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "190",
              "202"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "203",
              "218"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/doLccMA4Oe",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/75",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "98",
              "121"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1403300212391751682/photo/1",
            "indices" : [
              "245",
              "268"
            ],
            "url" : "https://t.co/BEhV24A6rZ",
            "media_url" : "http://pbs.twimg.com/media/E3mGFeDWQAUJhHB.jpg",
            "id_str" : "1403300187427192837",
            "id" : "1403300187427192837",
            "media_url_https" : "https://pbs.twimg.com/media/E3mGFeDWQAUJhHB.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "136",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1230",
                "h" : "246",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "240",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/BEhV24A6rZ"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "219",
              "231"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "232",
              "244"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "268"
      ],
      "favorite_count" : "4",
      "id_str" : "1403300212391751682",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1403300212391751682",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jun 11 10:36:57 +0000 2021",
      "favorited" : false,
      "full_text" : "Don't need meeting today - lots of threads currently active, and MRSA assay set up for next week: https://t.co/doLccMA4Oe @mfernflower @macinchem @LoriFerrins @edwintse_ @dana_klug @emeryfs @MatToddChem @GiadasabatinoC #openscience #antibiotics https://t.co/BEhV24A6rZ",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1403300212391751682/photo/1",
            "indices" : [
              "245",
              "268"
            ],
            "url" : "https://t.co/BEhV24A6rZ",
            "media_url" : "http://pbs.twimg.com/media/E3mGFeDWQAUJhHB.jpg",
            "id_str" : "1403300187427192837",
            "id" : "1403300187427192837",
            "media_url_https" : "https://pbs.twimg.com/media/E3mGFeDWQAUJhHB.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "136",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1230",
                "h" : "246",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "240",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/BEhV24A6rZ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1400797195104817153"
          ],
          "editableUntil" : "2021-06-04T13:20:51.523Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "249",
              "261"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "165",
              "175"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "176",
              "186"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "187",
              "197"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "198",
              "210"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "211",
              "219"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "220",
              "232"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "233",
              "248"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/HCdBvt3rf4",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/74",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "141",
              "164"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "261"
      ],
      "favorite_count" : "2",
      "id_str" : "1400797195104817153",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1400797195104817153",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jun 04 12:50:51 +0000 2021",
      "favorited" : false,
      "full_text" : "OK, if people are available we can catch up this week and check in on next steps after the slightly worrying tox data last week. Issue here: https://t.co/HCdBvt3rf4 @edwintse_ @dana_klug @macinchem @LoriFerrins @emeryfs @mfernflower @GiadasabatinoC #antibiotics",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1399433886594224132"
          ],
          "editableUntil" : "2021-05-31T19:03:33.445Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/y5TnID50tN",
            "expanded_url" : "https://www.cambridgemedchemconsulting.com/news/index_files/cf236a101b2d323869062b5ba560c751-478.html",
            "display_url" : "cambridgemedchemconsulting.com/news/index_fil…",
            "indices" : [
              "68",
              "91"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "0",
      "id_str" : "1399433886594224132",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1399433886594224132",
      "possibly_sensitive" : false,
      "created_at" : "Mon May 31 18:33:33 +0000 2021",
      "favorited" : false,
      "full_text" : "6th RSC-BMCS Symposium on Mastering MedChem, still time to register https://t.co/y5TnID50tN",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1398209314490404868"
          ],
          "editableUntil" : "2021-05-28T09:57:32.704Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://mobile.twitter.com\" rel=\"nofollow\">Twitter Web App</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "172",
              "182"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "183",
              "198"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "199",
              "209"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "210",
              "220"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "221",
              "233"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "234",
              "242"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "243",
              "255"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "256",
              "268"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/riINTKQHFc",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/72",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "135",
              "158"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1398209314490404868/photo/1",
            "indices" : [
              "269",
              "292"
            ],
            "url" : "https://t.co/TAFdaZ7PPO",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/E2dv9PjXwAYbvvm.jpg",
            "id_str" : "1398209307259420678",
            "id" : "1398209307259420678",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/E2dv9PjXwAYbvvm.jpg",
            "sizes" : {
              "medium" : {
                "w" : "498",
                "h" : "262",
                "resize" : "fit"
              },
              "small" : {
                "w" : "498",
                "h" : "262",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "498",
                "h" : "262",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/TAFdaZ7PPO"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "159",
              "171"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "292"
      ],
      "favorite_count" : "7",
      "id_str" : "1398209314490404868",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1398209314490404868",
      "possibly_sensitive" : false,
      "created_at" : "Fri May 28 09:27:32 +0000 2021",
      "favorited" : false,
      "full_text" : "Today's meeting postponed to next Friday. Any written updates from all you antibiotic hunters can go on the Issue for the last meeting https://t.co/riINTKQHFc #OpenScience @macinchem @GiadasabatinoC @dana_klug @edwintse_ @LoriFerrins @emeryfs @mfernflower @MatToddChem https://t.co/TAFdaZ7PPO",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1398209314490404868/photo/1",
            "indices" : [
              "269",
              "292"
            ],
            "url" : "https://t.co/TAFdaZ7PPO",
            "media_url" : "http://pbs.twimg.com/tweet_video_thumb/E2dv9PjXwAYbvvm.jpg",
            "id_str" : "1398209307259420678",
            "video_info" : {
              "aspect_ratio" : [
                "249",
                "131"
              ],
              "variants" : [
                {
                  "bitrate" : "0",
                  "content_type" : "video/mp4",
                  "url" : "https://video.twimg.com/tweet_video/E2dv9PjXwAYbvvm.mp4"
                }
              ]
            },
            "id" : "1398209307259420678",
            "media_url_https" : "https://pbs.twimg.com/tweet_video_thumb/E2dv9PjXwAYbvvm.jpg",
            "sizes" : {
              "medium" : {
                "w" : "498",
                "h" : "262",
                "resize" : "fit"
              },
              "small" : {
                "w" : "498",
                "h" : "262",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "498",
                "h" : "262",
                "resize" : "fit"
              }
            },
            "type" : "animated_gif",
            "display_url" : "pic.twitter.com/TAFdaZ7PPO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1392094036689829890"
          ],
          "editableUntil" : "2021-05-11T12:57:36.860Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "128",
              "138"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "SSGCID",
            "screen_name" : "SSGCID",
            "indices" : [
              "139",
              "146"
            ],
            "id_str" : "1327978831",
            "id" : "1327978831"
          },
          {
            "name" : "Yuhang Wang",
            "screen_name" : "EricWan59398945",
            "indices" : [
              "147",
              "163"
            ],
            "id_str" : "1317060137606066177",
            "id" : "1317060137606066177"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "164",
              "176"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "177",
              "189"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Frank von Delft",
            "screen_name" : "FrankvonDelft",
            "indices" : [
              "202",
              "216"
            ],
            "id_str" : "1325018261633765377",
            "id" : "1325018261633765377"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/WlmaAvfTHi",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/43",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "78",
              "101"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1392094036689829890/photo/1",
            "indices" : [
              "218",
              "241"
            ],
            "url" : "https://t.co/MCCEfJ4EWB",
            "media_url" : "http://pbs.twimg.com/media/E1G1bm2XoAEpYbR.png",
            "id_str" : "1392093245723877377",
            "id" : "1392093245723877377",
            "media_url_https" : "https://pbs.twimg.com/media/E1G1bm2XoAEpYbR.png",
            "sizes" : {
              "medium" : {
                "w" : "512",
                "h" : "255",
                "resize" : "fit"
              },
              "large" : {
                "w" : "512",
                "h" : "255",
                "resize" : "fit"
              },
              "small" : {
                "w" : "512",
                "h" : "255",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/MCCEfJ4EWB"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "102",
              "114"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "115",
              "127"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "241"
      ],
      "favorite_count" : "4",
      "id_str" : "1392094036689829890",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1392094036689829890",
      "possibly_sensitive" : false,
      "created_at" : "Tue May 11 12:27:36 +0000 2021",
      "favorited" : false,
      "full_text" : "Online research meeting in 30 mins (2pm London) on Series 1, the mur ligases. https://t.co/WlmaAvfTHi #openscience #antibiotics @macinchem @SSGCID @EricWan59398945 @LoriFerrins @MatToddChem (apols from @FrankvonDelft) https://t.co/MCCEfJ4EWB",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1392094036689829890/photo/1",
            "indices" : [
              "218",
              "241"
            ],
            "url" : "https://t.co/MCCEfJ4EWB",
            "media_url" : "http://pbs.twimg.com/media/E1G1bm2XoAEpYbR.png",
            "id_str" : "1392093245723877377",
            "id" : "1392093245723877377",
            "media_url_https" : "https://pbs.twimg.com/media/E1G1bm2XoAEpYbR.png",
            "sizes" : {
              "medium" : {
                "w" : "512",
                "h" : "255",
                "resize" : "fit"
              },
              "large" : {
                "w" : "512",
                "h" : "255",
                "resize" : "fit"
              },
              "small" : {
                "w" : "512",
                "h" : "255",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/MCCEfJ4EWB"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1391695202880983041"
          ],
          "editableUntil" : "2021-05-10T10:32:47.470Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1391695202880983041",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1391695202880983041",
      "created_at" : "Mon May 10 10:02:47 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @macinchem: May 10th 1929 is a very important day in drug discovery research, it was on this day that Alexander Fleming submitted his pa…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1390624114591903744"
          ],
          "editableUntil" : "2021-05-07T11:36:40.122Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "68",
              "80"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "81",
              "96"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "97",
              "107"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "108",
              "118"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "119",
              "129"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "130",
              "142"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "143",
              "151"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "152",
              "164"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "164"
      ],
      "favorite_count" : "5",
      "id_str" : "1390624114591903744",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1390624114591903744",
      "created_at" : "Fri May 07 11:06:40 +0000 2021",
      "favorited" : false,
      "full_text" : "No meeting today. Will update Github ASAP. Happy extra Friday time! @mfernflower @GiadasabatinoC @macinchem @edwintse_ @dana_klug @LoriFerrins @emeryfs @MatToddChem",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1390283935058382848"
          ],
          "editableUntil" : "2021-05-06T13:04:55.001Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "RSC BMCS",
            "screen_name" : "RSC_BMCS",
            "indices" : [
              "57",
              "66"
            ],
            "id_str" : "760549489895698432",
            "id" : "760549489895698432"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/sEpvKzplus",
            "expanded_url" : "https://www.cambridgemedchemconsulting.com/news/index_files/4f51b8eda8f083c563eb16a4e5dea0f2-474.html",
            "display_url" : "cambridgemedchemconsulting.com/news/index_fil…",
            "indices" : [
              "68",
              "91"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "91"
      ],
      "favorite_count" : "0",
      "id_str" : "1390283935058382848",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1390283935058382848",
      "possibly_sensitive" : false,
      "created_at" : "Thu May 06 12:34:55 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @macinchem: Funding for novel antibiotic development. @RSC_BMCS  https://t.co/sEpvKzplus",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1387801975601958916"
          ],
          "editableUntil" : "2021-04-29T16:42:29.754Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "247",
              "259"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "72",
              "84"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "85",
              "95"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "96",
              "106"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "107",
              "119"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "120",
              "128"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "129",
              "144"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "145",
              "157"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "158",
              "168"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/p9J2LBwNoY",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/70",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "48",
              "71"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "259"
      ],
      "favorite_count" : "9",
      "id_str" : "1387801975601958916",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1387801975601958916",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 29 16:12:29 +0000 2021",
      "favorited" : false,
      "full_text" : "Recommend we skip OSA Series 2 meeting tomorrow https://t.co/p9J2LBwNoY @MatToddChem @macinchem @dana_klug @LoriFerrins @emeryfs @GiadasabatinoC @mfernflower @edwintse_ Hopefully OK with everyone. Want to meet when have the new tox data, ideally. #openscience",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1385510011288367104"
          ],
          "editableUntil" : "2021-04-23T08:55:02.879Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "136",
              "148"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "149",
              "161"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "162",
              "172"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "173",
              "183"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "184",
              "194"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "195",
              "207"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "208",
              "223"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          },
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "224",
              "232"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "233",
              "245"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "246",
              "258"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/OquekXbksb",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/69",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "52",
              "75"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "258"
      ],
      "favorite_count" : "6",
      "id_str" : "1385510011288367104",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1385510011288367104",
      "possibly_sensitive" : false,
      "created_at" : "Fri Apr 23 08:25:02 +0000 2021",
      "favorited" : false,
      "full_text" : "Skip meeting today? Lots of stuff already going on: https://t.co/OquekXbksb Reclaim 30 minutes of quality science time, talk next week? #openscience #antibiotics @macinchem @dana_klug @edwintse_ @mfernflower @GiadasabatinoC @emeryfs @MatToddChem @LoriFerrins",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1383055993484029952"
          ],
          "editableUntil" : "2021-04-16T14:23:39.441Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Tedros Adhanom Ghebreyesus",
            "screen_name" : "DrTedros",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "189868631",
            "id" : "189868631"
          },
          {
            "name" : "European Investment Bank",
            "screen_name" : "EIB",
            "indices" : [
              "109",
              "113"
            ],
            "id_str" : "74720323",
            "id" : "74720323"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1383055993484029952",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1383055993484029952",
      "created_at" : "Fri Apr 16 13:53:39 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @DrTedros: The AMR Action Fund was set up by a coalition of pharmaceutical companies, philanthropies, the @EIB, with the support of the…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1376486362107555840"
          ],
          "editableUntil" : "2021-03-29T11:18:17.263Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "71",
              "85"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/hNs4E04xY6",
            "expanded_url" : "https://www.macinchem.org/reviews/OSA/importIntoDataWarrior.php",
            "display_url" : "macinchem.org/reviews/OSA/im…",
            "indices" : [
              "108",
              "131"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1376486362107555840",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1376486362107555840",
      "possibly_sensitive" : false,
      "created_at" : "Mon Mar 29 10:48:17 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @macinchem: A macro to automatically import Open Source Antibiotics @OSantibiotics Data into DataWarrior https://t.co/hNs4E04xY6 #chemin…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1375405183505727493"
          ],
          "editableUntil" : "2021-03-26T11:42:04.197Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "226",
              "236"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "237",
              "249"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "250",
              "258"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "259",
              "269"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/FC4xZOC3s7",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/65",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "49",
              "72"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1375405183505727493/photo/1",
            "indices" : [
              "270",
              "293"
            ],
            "url" : "https://t.co/RJjdH4YRd5",
            "media_url" : "http://pbs.twimg.com/media/ExZrsw8W8AA-CKq.jpg",
            "id_str" : "1375405153004744704",
            "id" : "1375405153004744704",
            "media_url_https" : "https://pbs.twimg.com/media/ExZrsw8W8AA-CKq.jpg",
            "sizes" : {
              "large" : {
                "w" : "924",
                "h" : "604",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "445",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "924",
                "h" : "604",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RJjdH4YRd5"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "200",
              "212"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "213",
              "225"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "293"
      ],
      "favorite_count" : "7",
      "id_str" : "1375405183505727493",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1375405183505727493",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 26 11:12:04 +0000 2021",
      "favorited" : false,
      "full_text" : "Agenda for today's open online research catch-up https://t.co/FC4xZOC3s7 featuring guest star appearance by Isabelle Giraud showing how Google sheet of molecules can be auto-imported into Datawarrior #openscience #antibiotics @macinchem @LoriFerrins @MrBenGP @dana_klug https://t.co/RJjdH4YRd5",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1375405183505727493/photo/1",
            "indices" : [
              "270",
              "293"
            ],
            "url" : "https://t.co/RJjdH4YRd5",
            "media_url" : "http://pbs.twimg.com/media/ExZrsw8W8AA-CKq.jpg",
            "id_str" : "1375405153004744704",
            "id" : "1375405153004744704",
            "media_url_https" : "https://pbs.twimg.com/media/ExZrsw8W8AA-CKq.jpg",
            "sizes" : {
              "large" : {
                "w" : "924",
                "h" : "604",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "445",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "924",
                "h" : "604",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RJjdH4YRd5"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1374367973540986885"
          ],
          "editableUntil" : "2021-03-23T15:00:34.071Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "12",
              "24"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "25",
              "35"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Frank von Delft",
            "screen_name" : "FrankvonDelft",
            "indices" : [
              "112",
              "126"
            ],
            "id_str" : "1325018261633765377",
            "id" : "1325018261633765377"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/Nh32F2gZcw",
            "expanded_url" : "https://twitter.com/PracticalFrag/status/1374203597831860225",
            "display_url" : "twitter.com/PracticalFrag/…",
            "indices" : [
              "127",
              "150"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "150"
      ],
      "favorite_count" : "3",
      "id_str" : "1374367973540986885",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1374367973540986885",
      "possibly_sensitive" : false,
      "created_at" : "Tue Mar 23 14:30:34 +0000 2021",
      "favorited" : false,
      "full_text" : "Great! Ping @MatToddChem @dana_klug needed for MurE/MurD sets, given no binders from first round of elaboration @FrankvonDelft https://t.co/Nh32F2gZcw",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1372683562374328327"
          ],
          "editableUntil" : "2021-03-18T23:27:19.154Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "118",
              "130"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "131",
              "139"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "179",
              "189"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/EDS0yonLSE",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/61",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "48",
              "71"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1372683562374328327/photo/1",
            "indices" : [
              "281",
              "304"
            ],
            "url" : "https://t.co/Ndnde969Hc",
            "media_url" : "http://pbs.twimg.com/media/EwzAGB0XEAALK4F.png",
            "id_str" : "1372683196240957440",
            "id" : "1372683196240957440",
            "media_url_https" : "https://pbs.twimg.com/media/EwzAGB0XEAALK4F.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "483",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "710",
                "h" : "504",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "710",
                "h" : "504",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Ndnde969Hc"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "190",
              "202"
            ]
          },
          {
            "text" : "Antibiotics",
            "indices" : [
              "203",
              "215"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "304"
      ],
      "favorite_count" : "6",
      "id_str" : "1372683562374328327",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1372683562374328327",
      "possibly_sensitive" : false,
      "created_at" : "Thu Mar 18 22:57:19 +0000 2021",
      "favorited" : false,
      "full_text" : "Meeting at usual time Fri 2pm GMT. Link/agenda: https://t.co/EDS0yonLSE New compound shipments incoming/outgoing with @LoriFerrins @MrBenGP SAR tables have been updated thank you @dana_klug #OpenScience #Antibiotics Tox measurements in search of selectivity window still priority. https://t.co/Ndnde969Hc",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1372683562374328327/photo/1",
            "indices" : [
              "281",
              "304"
            ],
            "url" : "https://t.co/Ndnde969Hc",
            "media_url" : "http://pbs.twimg.com/media/EwzAGB0XEAALK4F.png",
            "id_str" : "1372683196240957440",
            "id" : "1372683196240957440",
            "media_url_https" : "https://pbs.twimg.com/media/EwzAGB0XEAALK4F.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "483",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "710",
                "h" : "504",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "710",
                "h" : "504",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Ndnde969Hc"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1369409198690361353"
          ],
          "editableUntil" : "2021-03-09T22:36:10.017Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Diamond Light Source",
            "screen_name" : "DiamondLightSou",
            "indices" : [
              "180",
              "196"
            ],
            "id_str" : "16927254",
            "id" : "16927254"
          },
          {
            "name" : "UCL",
            "screen_name" : "ucl",
            "indices" : [
              "197",
              "201"
            ],
            "id_str" : "322601789",
            "id" : "322601789"
          },
          {
            "name" : "Northeastern U.",
            "screen_name" : "Northeastern",
            "indices" : [
              "202",
              "215"
            ],
            "id_str" : "46477409",
            "id" : "46477409"
          },
          {
            "name" : "University of Warwick",
            "screen_name" : "warwickuni",
            "indices" : [
              "216",
              "227"
            ],
            "id_str" : "15916215",
            "id" : "15916215"
          },
          {
            "name" : "SSGCID",
            "screen_name" : "SSGCID",
            "indices" : [
              "228",
              "235"
            ],
            "id_str" : "1327978831",
            "id" : "1327978831"
          },
          {
            "name" : "UCB News",
            "screen_name" : "ucb_news",
            "indices" : [
              "252",
              "261"
            ],
            "id_str" : "165691815",
            "id" : "165691815"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/0MwctyE17P",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/40",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "144",
              "167"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1369409198690361353/photo/1",
            "indices" : [
              "262",
              "285"
            ],
            "url" : "https://t.co/4xRDScpECO",
            "media_url" : "http://pbs.twimg.com/media/EwEc8J0XIAoW1ZN.jpg",
            "id_str" : "1369407581450608650",
            "id" : "1369407581450608650",
            "media_url_https" : "https://pbs.twimg.com/media/EwEc8J0XIAoW1ZN.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "408",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1230",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/4xRDScpECO"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "21",
              "33"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "130",
              "142"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "285"
      ],
      "favorite_count" : "7",
      "id_str" : "1369409198690361353",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1369409198690361353",
      "possibly_sensitive" : false,
      "created_at" : "Tue Mar 09 22:06:10 +0000 2021",
      "favorited" : false,
      "full_text" : "Minutes from today's #OpenScience research catchup on Series 1, the mur ligases, seeking novel dual-targeting inhibitors as novel #antibiotics. https://t.co/0MwctyE17P Inputs from @DiamondLightSou @ucl @Northeastern @warwickuni @SSGCID @uni_copenhagen @ucb_news https://t.co/4xRDScpECO",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1369409198690361353/photo/1",
            "indices" : [
              "262",
              "285"
            ],
            "url" : "https://t.co/4xRDScpECO",
            "media_url" : "http://pbs.twimg.com/media/EwEc8J0XIAoW1ZN.jpg",
            "id_str" : "1369407581450608650",
            "id" : "1369407581450608650",
            "media_url_https" : "https://pbs.twimg.com/media/EwEc8J0XIAoW1ZN.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "408",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1230",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "720",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/4xRDScpECO"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1367874531231154176"
          ],
          "editableUntil" : "2021-03-05T16:57:56.782Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Flavio Emery",
            "screen_name" : "emeryfs",
            "indices" : [
              "37",
              "45"
            ],
            "id_str" : "805025179",
            "id" : "805025179"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "180",
              "192"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "193",
              "203"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "204",
              "216"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "217",
              "227"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "228",
              "243"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "244",
              "256"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "257",
              "265"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/alHiKtLgZp",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/57",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "156",
              "179"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1367874531231154176/photo/1",
            "indices" : [
              "279",
              "302"
            ],
            "url" : "https://t.co/n5Tz4v9TMA",
            "media_url" : "http://pbs.twimg.com/media/EvuqMrTXcAME97Z.jpg",
            "id_str" : "1367874046596182019",
            "id" : "1367874046596182019",
            "media_url_https" : "https://pbs.twimg.com/media/EvuqMrTXcAME97Z.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "899",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "299",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "527",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/n5Tz4v9TMA"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "266",
              "278"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "302"
      ],
      "favorite_count" : "7",
      "id_str" : "1367874531231154176",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1367874531231154176",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 05 16:27:56 +0000 2021",
      "favorited" : false,
      "full_text" : "Thanks for coming to today's meeting @emeryfs - it'll be great to work together. Good discussion today on how best to share samples between the three sites https://t.co/alHiKtLgZp @LoriFerrins @macinchem @MatToddChem @dana_klug @GiadasabatinoC @mfernflower @MrBenGP #OpenScience https://t.co/n5Tz4v9TMA",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1367874531231154176/photo/1",
            "indices" : [
              "279",
              "302"
            ],
            "url" : "https://t.co/n5Tz4v9TMA",
            "media_url" : "http://pbs.twimg.com/media/EvuqMrTXcAME97Z.jpg",
            "id_str" : "1367874046596182019",
            "id" : "1367874046596182019",
            "media_url_https" : "https://pbs.twimg.com/media/EvuqMrTXcAME97Z.jpg",
            "sizes" : {
              "large" : {
                "w" : "2048",
                "h" : "899",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "299",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "527",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/n5Tz4v9TMA"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1367399191631257604"
          ],
          "editableUntil" : "2021-03-04T09:29:06.990Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "RSC_CICAG",
            "screen_name" : "RSC_CICAG",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "447019817",
            "id" : "447019817"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/W2VTKAqqoP",
            "expanded_url" : "https://www.eventbrite.com/e/open-source-tools-for-chemistry-workshops-tickets-143296615033",
            "display_url" : "eventbrite.com/e/open-source-…",
            "indices" : [
              "91",
              "114"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1367399191631257604",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1367399191631257604",
      "possibly_sensitive" : false,
      "created_at" : "Thu Mar 04 08:59:06 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @RSC_CICAG: Registration for the Open-Source Tools for Chemistry Workshops is now open: https://t.co/W2VTKAqqoP\n\n4 workshops between Mar…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1365966735589933061"
          ],
          "editableUntil" : "2021-02-28T10:37:02.856Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "0",
              "12"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "13",
              "25"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "26",
              "41"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          },
          {
            "name" : "GiadaSabatino_chem",
            "screen_name" : "GiadasabatinoC",
            "indices" : [
              "70",
              "85"
            ],
            "id_str" : "1365962609212739585",
            "id" : "1365962609212739585"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1365965551332450304",
      "id_str" : "1365966735589933061",
      "in_reply_to_user_id" : "21448858",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1365966735589933061",
      "in_reply_to_status_id" : "1365965551332450304",
      "created_at" : "Sun Feb 28 10:07:02 +0000 2021",
      "favorited" : false,
      "full_text" : "@MatToddChem @mfernflower @GiadasabatinoC Welcome to the Twitterverse @GiadasabatinoC!",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "in_reply_to_screen_name" : "MatToddChem",
      "in_reply_to_user_id_str" : "21448858"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1365233804798025730"
          ],
          "editableUntil" : "2021-02-26T10:04:38.538Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "218",
              "230"
            ]
          },
          {
            "text" : "ThatFridayFeeling",
            "indices" : [
              "231",
              "249"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "185",
              "199"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "249"
      ],
      "favorite_count" : "1",
      "id_str" : "1365233804798025730",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1365233804798025730",
      "created_at" : "Fri Feb 26 09:34:38 +0000 2021",
      "favorited" : false,
      "full_text" : "No meeting today: the next actions are clear and we'll summarise them in a new github issue later today, then meet up as usual next week. Extra half hour free in the diary on a Friday: @OSantibiotics gift to us all... #OpenScience #ThatFridayFeeling",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1364688840326324227"
          ],
          "editableUntil" : "2021-02-24T21:59:08.883Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "DNDi_Português",
            "screen_name" : "DNDi_Portugues",
            "indices" : [
              "17",
              "32"
            ],
            "id_str" : "1035518830137815041",
            "id" : "1035518830137815041"
          },
          {
            "name" : "Jadel Kratz",
            "screen_name" : "JardaKratz",
            "indices" : [
              "33",
              "44"
            ],
            "id_str" : "788589188774068225",
            "id" : "788589188774068225"
          },
          {
            "name" : "RSC Medicinal Chemistry",
            "screen_name" : "rsc_medchem",
            "indices" : [
              "45",
              "57"
            ],
            "id_str" : "66688814",
            "id" : "66688814"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "66",
              "80"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "113",
              "125"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "126",
              "136"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1364688840326324227",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1364688840326324227",
      "created_at" : "Wed Feb 24 21:29:08 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: @DNDi_Portugues @JardaKratz @rsc_medchem Pinging @OSantibiotics relevant structures to Series 2 @LoriFerrins @macinchem @M…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1361445522695938050"
          ],
          "editableUntil" : "2021-02-15T23:11:21.702Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"http://twitter.com/download/android\" rel=\"nofollow\">Twitter for Android</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "amr",
            "indices" : [
              "0",
              "4"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "John H. Rex, MD",
            "screen_name" : "JohnRex_NewAbx",
            "indices" : [
              "15",
              "30"
            ],
            "id_str" : "825110000972464128",
            "id" : "825110000972464128"
          },
          {
            "name" : "Kevin Outterson",
            "screen_name" : "koutterson",
            "indices" : [
              "31",
              "42"
            ],
            "id_str" : "55264345",
            "id" : "55264345"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "67",
              "79"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/i628o1QF9l",
            "expanded_url" : "https://www.theguardian.com/commentisfree/2021/feb/15/creating-conditions-next-pandemic-antibiotics",
            "display_url" : "theguardian.com/commentisfree/…",
            "indices" : [
              "43",
              "66"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "2",
      "id_str" : "1361445522695938050",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1361445522695938050",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 15 22:41:21 +0000 2021",
      "favorited" : false,
      "full_text" : "#amr featuring @JohnRex_NewAbx @koutterson https://t.co/i628o1QF9l @MatToddChem",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1359986798211051520"
          ],
          "editableUntil" : "2021-02-11T22:34:54.683Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "170",
              "182"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "183",
              "193"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "194",
              "206"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "207",
              "219"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "220",
              "230"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "231",
              "241"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "241"
      ],
      "favorite_count" : "4",
      "id_str" : "1359986798211051520",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1359986798211051520",
      "created_at" : "Thu Feb 11 22:04:54 +0000 2021",
      "favorited" : false,
      "full_text" : "We'll postpone tomorrow's research meeting since we won't have all the tox data in time, but will have it for next week (Fri 2pm) alongside (hopefully) new potency data. @mfernflower @macinchem @LoriFerrins @MatToddChem @dana_klug @edwintse_",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1359178813905768449"
          ],
          "editableUntil" : "2021-02-09T17:04:16.213Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "178",
              "190"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "191",
              "201"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "202",
              "210"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          },
          {
            "name" : "Atomwise",
            "screen_name" : "AtomwiseInc",
            "indices" : [
              "211",
              "223"
            ],
            "id_str" : "783284048",
            "id" : "783284048"
          },
          {
            "name" : "Diamond Light Source",
            "screen_name" : "DiamondLightSou",
            "indices" : [
              "224",
              "240"
            ],
            "id_str" : "16927254",
            "id" : "16927254"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/FFTijxlqsg",
            "expanded_url" : "https://youtu.be/qZ7w1v_3Eys",
            "display_url" : "youtu.be/qZ7w1v_3Eys",
            "indices" : [
              "39",
              "62"
            ]
          },
          {
            "url" : "https://t.co/KAnmx4Adn2",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/39",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "87",
              "110"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1359178813905768449/photo/1",
            "indices" : [
              "241",
              "264"
            ],
            "url" : "https://t.co/39UZfwzvM3",
            "media_url" : "http://pbs.twimg.com/media/EtzF2DpXIAcoZ7S.jpg",
            "id_str" : "1359178720041443335",
            "id" : "1359178720041443335",
            "media_url_https" : "https://pbs.twimg.com/media/EtzF2DpXIAcoZ7S.jpg",
            "sizes" : {
              "large" : {
                "w" : "2036",
                "h" : "1542",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "515",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "909",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/39UZfwzvM3"
          }
        ],
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "152",
              "164"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "165",
              "177"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "264"
      ],
      "favorite_count" : "7",
      "id_str" : "1359178813905768449",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1359178813905768449",
      "possibly_sensitive" : false,
      "created_at" : "Tue Feb 09 16:34:16 +0000 2021",
      "favorited" : false,
      "full_text" : "Recording of today's meeting is now at https://t.co/FFTijxlqsg. Minutes and actions at https://t.co/KAnmx4Adn2. Lots going on, next meeting in a month. #antibiotics #openscience @MatToddChem @dana_klug @1Antruk @AtomwiseInc @DiamondLightSou https://t.co/39UZfwzvM3",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1359178813905768449/photo/1",
            "indices" : [
              "241",
              "264"
            ],
            "url" : "https://t.co/39UZfwzvM3",
            "media_url" : "http://pbs.twimg.com/media/EtzF2DpXIAcoZ7S.jpg",
            "id_str" : "1359178720041443335",
            "id" : "1359178720041443335",
            "media_url_https" : "https://pbs.twimg.com/media/EtzF2DpXIAcoZ7S.jpg",
            "sizes" : {
              "large" : {
                "w" : "2036",
                "h" : "1542",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "515",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "909",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/39UZfwzvM3"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1359134379948322820"
          ],
          "editableUntil" : "2021-02-09T14:07:42.332Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "104",
              "116"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "117",
              "129"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "130",
              "144"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/KAnmx4Adn2",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/39",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "80",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "1",
      "id_str" : "1359134379948322820",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1359134379948322820",
      "possibly_sensitive" : false,
      "created_at" : "Tue Feb 09 13:37:42 +0000 2021",
      "favorited" : false,
      "full_text" : "Research meeting today at 2pm GMT, focussing on mur ligases. Agenda and link at https://t.co/KAnmx4Adn2 #openscience #antibiotics #drugdiscovery",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1358792271370612736"
          ],
          "editableUntil" : "2021-02-08T15:28:17.291Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "208",
              "218"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "219",
              "232"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          },
          {
            "name" : "AMR Action Fund",
            "screen_name" : "AMRActionFund",
            "indices" : [
              "233",
              "247"
            ],
            "id_str" : "1270709401192718337",
            "id" : "1270709401192718337"
          },
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "248",
              "256"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          },
          {
            "name" : "Laura Piddock 💙",
            "screen_name" : "LauraPiddock",
            "indices" : [
              "257",
              "270"
            ],
            "id_str" : "398581149",
            "id" : "398581149"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/0ibGHL4vzx",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/37",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "137",
              "160"
            ]
          },
          {
            "url" : "https://t.co/HVSchc4Sds",
            "expanded_url" : "https://docs.google.com/forms/d/e/1FAIpQLSf4UieL5pRQqN5rOL4q-t57qcpJhHG_jqMXV774FPUJBmnBbQ/viewform",
            "display_url" : "docs.google.com/forms/d/e/1FAI…",
            "indices" : [
              "184",
              "207"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1358792271370612736/photo/1",
            "indices" : [
              "271",
              "294"
            ],
            "url" : "https://t.co/EEibNhrqsk",
            "media_url" : "http://pbs.twimg.com/media/EttlIngWQAAxBiH.png",
            "id_str" : "1358790911300354048",
            "id" : "1358790911300354048",
            "media_url_https" : "https://pbs.twimg.com/media/EttlIngWQAAxBiH.png",
            "sizes" : {
              "large" : {
                "w" : "898",
                "h" : "410",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "898",
                "h" : "410",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "310",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/EEibNhrqsk"
          }
        ],
        "hashtags" : [
          {
            "text" : "murligases",
            "indices" : [
              "47",
              "58"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "83",
              "95"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "101",
              "113"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "294"
      ],
      "favorite_count" : "5",
      "id_str" : "1358792271370612736",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1358792271370612736",
      "possibly_sensitive" : false,
      "created_at" : "Mon Feb 08 14:58:17 +0000 2021",
      "favorited" : false,
      "full_text" : "Newsletter 2 is out! Progress on Series 1, the #murligases towards new, affordable #antibiotics with #openscience methods. Read it here: https://t.co/0ibGHL4vzx Sign up for them here: https://t.co/HVSchc4Sds @gardp_amr @Wellcome_AMR @AMRActionFund @1Antruk @LauraPiddock https://t.co/EEibNhrqsk",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1358792271370612736/photo/1",
            "indices" : [
              "271",
              "294"
            ],
            "url" : "https://t.co/EEibNhrqsk",
            "media_url" : "http://pbs.twimg.com/media/EttlIngWQAAxBiH.png",
            "id_str" : "1358790911300354048",
            "id" : "1358790911300354048",
            "media_url_https" : "https://pbs.twimg.com/media/EttlIngWQAAxBiH.png",
            "sizes" : {
              "large" : {
                "w" : "898",
                "h" : "410",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "898",
                "h" : "410",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "310",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/EEibNhrqsk"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1353655372763066368"
          ],
          "editableUntil" : "2021-01-25T11:16:05.224Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/GGTF1BpLzA",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/3#issuecomment-766726268",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "160",
              "183"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "183"
      ],
      "favorite_count" : "1",
      "id_str" : "1353655372763066368",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1353655372763066368",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 25 10:46:05 +0000 2021",
      "favorited" : false,
      "full_text" : "The silent pandemic of antibiotic resistance\nA South African doctor’s prescription to stop poorer countries losing access to many of modern medicine’s advances https://t.co/GGTF1BpLzA",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1352926091078492161"
          ],
          "editableUntil" : "2021-01-23T10:58:10.921Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Yuhang Wang",
            "screen_name" : "EricWan59398945",
            "indices" : [
              "25",
              "41"
            ],
            "id_str" : "1317060137606066177",
            "id" : "1317060137606066177"
          },
          {
            "name" : "AstraZeneca",
            "screen_name" : "AstraZeneca",
            "indices" : [
              "122",
              "134"
            ],
            "id_str" : "62465691",
            "id" : "62465691"
          },
          {
            "name" : "Paul Hergenrother",
            "screen_name" : "PaulHergie",
            "indices" : [
              "218",
              "229"
            ],
            "id_str" : "1492415988",
            "id" : "1492415988"
          },
          {
            "name" : "Matthew Boudreau",
            "screen_name" : "The_Boudreau",
            "indices" : [
              "239",
              "252"
            ],
            "id_str" : "4473654262",
            "id" : "4473654262"
          },
          {
            "name" : "Dayang ☀️",
            "screen_name" : "DayangUsop",
            "indices" : [
              "253",
              "264"
            ],
            "id_str" : "1051819040379953153",
            "id" : "1051819040379953153"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/x4v74b49Rk",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/38",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "144",
              "167"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1352926091078492161/photo/1",
            "indices" : [
              "278",
              "301"
            ],
            "url" : "https://t.co/hnwFtx0L4Y",
            "media_url" : "http://pbs.twimg.com/media/EsaM7byXEAE1bx1.png",
            "id_str" : "1352923690770567169",
            "id" : "1352923690770567169",
            "media_url_https" : "https://pbs.twimg.com/media/EsaM7byXEAE1bx1.png",
            "sizes" : {
              "large" : {
                "w" : "410",
                "h" : "304",
                "resize" : "fit"
              },
              "small" : {
                "w" : "410",
                "h" : "304",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "410",
                "h" : "304",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/hnwFtx0L4Y"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "168",
              "180"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "265",
              "277"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "301"
      ],
      "favorite_count" : "5",
      "id_str" : "1352926091078492161",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1352926091078492161",
      "possibly_sensitive" : false,
      "created_at" : "Sat Jan 23 10:28:10 +0000 2021",
      "favorited" : false,
      "full_text" : "Grad student Yuhang Wang @Ericwan59398945 posts his plan for our new key synthetic target vs the mur ligases, based on an @AstraZeneca compound https://t.co/x4v74b49Rk #openscience Should inhibit and should align with @PaulHergie criteria @The_Boudreau @DayangUsop #antibiotics https://t.co/hnwFtx0L4Y",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1352926091078492161/photo/1",
            "indices" : [
              "278",
              "301"
            ],
            "url" : "https://t.co/hnwFtx0L4Y",
            "media_url" : "http://pbs.twimg.com/media/EsaM7byXEAE1bx1.png",
            "id_str" : "1352923690770567169",
            "id" : "1352923690770567169",
            "media_url_https" : "https://pbs.twimg.com/media/EsaM7byXEAE1bx1.png",
            "sizes" : {
              "large" : {
                "w" : "410",
                "h" : "304",
                "resize" : "fit"
              },
              "small" : {
                "w" : "410",
                "h" : "304",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "410",
                "h" : "304",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/hnwFtx0L4Y"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1352613038201954304"
          ],
          "editableUntil" : "2021-01-22T14:14:13.299Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "107",
              "117"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/dmnSodFRjy",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/52",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "55",
              "78"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1352613038201954304",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1352613038201954304",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 22 13:44:13 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @OSantibiotics: Next open online meeting in 30 min. https://t.co/dmnSodFRjy Synthetic targets posted by @dana_klug Main item today: gues…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1352610344947036168"
          ],
          "editableUntil" : "2021-01-22T14:03:31.177Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "88",
              "98"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "UNC Pharmacy",
            "screen_name" : "UNCPharmacy",
            "indices" : [
              "138",
              "150"
            ],
            "id_str" : "15750564",
            "id" : "15750564"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/dmnSodFRjy",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/52",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "36",
              "59"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1352610344947036168/photo/1",
            "indices" : [
              "259",
              "282"
            ],
            "url" : "https://t.co/ixTjZyc8Ni",
            "media_url" : "http://pbs.twimg.com/media/EsVvvNGXAA0x8ec.png",
            "id_str" : "1352610119855570957",
            "id" : "1352610119855570957",
            "media_url_https" : "https://pbs.twimg.com/media/EsVvvNGXAA0x8ec.png",
            "sizes" : {
              "large" : {
                "w" : "616",
                "h" : "289",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "616",
                "h" : "289",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "616",
                "h" : "289",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ixTjZyc8Ni"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "227",
              "239"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "240",
              "252"
            ]
          },
          {
            "text" : "MRSA",
            "indices" : [
              "253",
              "258"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "282"
      ],
      "favorite_count" : "0",
      "id_str" : "1352610344947036168",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1352610344947036168",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 22 13:33:31 +0000 2021",
      "favorited" : false,
      "full_text" : "Next open online meeting in 30 min. https://t.co/dmnSodFRjy Synthetic targets posted by @dana_klug Main item today: guest appearance from @UNCPharmacy Prof Lee Graves to discuss latest data on mechanism of action. All welcome. #OpenScience #antibiotics #MRSA https://t.co/ixTjZyc8Ni",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1352610344947036168/photo/1",
            "indices" : [
              "259",
              "282"
            ],
            "url" : "https://t.co/ixTjZyc8Ni",
            "media_url" : "http://pbs.twimg.com/media/EsVvvNGXAA0x8ec.png",
            "id_str" : "1352610119855570957",
            "id" : "1352610119855570957",
            "media_url_https" : "https://pbs.twimg.com/media/EsVvvNGXAA0x8ec.png",
            "sizes" : {
              "large" : {
                "w" : "616",
                "h" : "289",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "616",
                "h" : "289",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "616",
                "h" : "289",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/ixTjZyc8Ni"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1352007380406566914"
          ],
          "editableUntil" : "2021-01-20T22:07:33.228Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Peter Schmidtke (@pschmidtke@masto.ai)",
            "screen_name" : "pschmidtke",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "83564689",
            "id" : "83564689"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "12",
              "22"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Diamond Light Source",
            "screen_name" : "DiamondLightSou",
            "indices" : [
              "23",
              "39"
            ],
            "id_str" : "16927254",
            "id" : "16927254"
          },
          {
            "name" : "Atomwise",
            "screen_name" : "AtomwiseInc",
            "indices" : [
              "40",
              "52"
            ],
            "id_str" : "783284048",
            "id" : "783284048"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "293"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1352005226023301121",
      "id_str" : "1352007380406566914",
      "in_reply_to_user_id" : "83564689",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1352007380406566914",
      "in_reply_to_status_id" : "1352005226023301121",
      "created_at" : "Wed Jan 20 21:37:33 +0000 2021",
      "favorited" : false,
      "full_text" : "@pschmidtke @dana_klug @DiamondLightSou @AtomwiseInc Don't hesitate to ask here or on Github - we sometimes don't update the wiki quickly enough, so please highlight anything missing or confusing and we'll fix it. There's an open mur ligase Zoom research catch-up coming on Feb 9th at 2pm GMT.",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "in_reply_to_screen_name" : "pschmidtke",
      "in_reply_to_user_id_str" : "83564689"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1352002098607624192"
          ],
          "editableUntil" : "2021-01-20T21:46:33.949Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Peter Schmidtke (@pschmidtke@masto.ai)",
            "screen_name" : "pschmidtke",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "83564689",
            "id" : "83564689"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "12",
              "22"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Diamond Light Source",
            "screen_name" : "DiamondLightSou",
            "indices" : [
              "23",
              "39"
            ],
            "id_str" : "16927254",
            "id" : "16927254"
          },
          {
            "name" : "Atomwise",
            "screen_name" : "AtomwiseInc",
            "indices" : [
              "284",
              "296"
            ],
            "id_str" : "783284048",
            "id" : "783284048"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/TVb52Uk1AZ",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/wiki/Round-1",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "140",
              "163"
            ]
          },
          {
            "url" : "https://t.co/zFjWTNDwKq",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/31",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "232",
              "255"
            ]
          },
          {
            "url" : "https://t.co/7Mt6EhTemU",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/33",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "297",
              "320"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "320"
      ],
      "favorite_count" : "1",
      "in_reply_to_status_id_str" : "1351995507426664449",
      "id_str" : "1352002098607624192",
      "in_reply_to_user_id" : "83564689",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1352002098607624192",
      "in_reply_to_status_id" : "1351995507426664449",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jan 20 21:16:33 +0000 2021",
      "favorited" : false,
      "full_text" : "@pschmidtke @dana_klug @DiamondLightSou The targets are the mur ligases, in Series 1. The small molecules evaluated include fragments (e.g. https://t.co/TVb52Uk1AZ) and we'll shortly evaluate derivatives of an AstraZeneca compound (https://t.co/zFjWTNDwKq) and donated compounds from @AtomwiseInc https://t.co/7Mt6EhTemU",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "in_reply_to_screen_name" : "pschmidtke",
      "in_reply_to_user_id_str" : "83564689"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1350000201021476864"
          ],
          "editableUntil" : "2021-01-15T09:11:44.371Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "PDB",
            "indices" : [
              "111",
              "115"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "55",
              "69"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1350000201021476864",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1350000201021476864",
      "created_at" : "Fri Jan 15 08:41:44 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @dana_klug: The structural biology wiki page of our @OSantibiotics Mur ligase project has been updated with #PDB links to our fragment-b…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1349360929444667393"
          ],
          "editableUntil" : "2021-01-13T14:51:30.150Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "SSGCID",
            "screen_name" : "SSGCID",
            "indices" : [
              "104",
              "111"
            ],
            "id_str" : "1327978831",
            "id" : "1327978831"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1349360929444667393",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1349360929444667393",
      "created_at" : "Wed Jan 13 14:21:30 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @OSantibiotics: PhD student Yuhang Wang trying to understand nature of protein-ligand interaction in @SSGCID crystal structure of @Astra…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1349357553562619911"
          ],
          "editableUntil" : "2021-01-13T14:38:05.277Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "SSGCID",
            "screen_name" : "SSGCID",
            "indices" : [
              "85",
              "92"
            ],
            "id_str" : "1327978831",
            "id" : "1327978831"
          },
          {
            "name" : "AstraZeneca",
            "screen_name" : "AstraZeneca",
            "indices" : [
              "114",
              "126"
            ],
            "id_str" : "62465691",
            "id" : "62465691"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "167",
              "181"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/PqOGYXBtNx",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/36",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "190",
              "213"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1349357553562619911/photo/1",
            "indices" : [
              "255",
              "278"
            ],
            "url" : "https://t.co/JxzyddArTL",
            "media_url" : "http://pbs.twimg.com/media/ErnhEg_XcAAdZ45.jpg",
            "id_str" : "1349357031065612288",
            "id" : "1349357031065612288",
            "media_url_https" : "https://pbs.twimg.com/media/ErnhEg_XcAAdZ45.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "372",
                "resize" : "fit"
              },
              "large" : {
                "w" : "962",
                "h" : "526",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "962",
                "h" : "526",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/JxzyddArTL"
          }
        ],
        "hashtags" : [
          {
            "text" : "murligase",
            "indices" : [
              "145",
              "155"
            ]
          },
          {
            "text" : "OpenScience",
            "indices" : [
              "214",
              "226"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "227",
              "239"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "240",
              "254"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "278"
      ],
      "favorite_count" : "6",
      "id_str" : "1349357553562619911",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1349357553562619911",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jan 13 14:08:05 +0000 2021",
      "favorited" : false,
      "full_text" : "PhD student Yuhang Wang trying to understand nature of protein-ligand interaction in @SSGCID crystal structure of @AstraZeneca compound bound to #murligase as part of @OSantibiotics project https://t.co/PqOGYXBtNx #OpenScience #antibiotics #drugdiscovery https://t.co/JxzyddArTL",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1349357553562619911/photo/1",
            "indices" : [
              "255",
              "278"
            ],
            "url" : "https://t.co/JxzyddArTL",
            "media_url" : "http://pbs.twimg.com/media/ErnhEg_XcAAdZ45.jpg",
            "id_str" : "1349357031065612288",
            "id" : "1349357031065612288",
            "media_url_https" : "https://pbs.twimg.com/media/ErnhEg_XcAAdZ45.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "372",
                "resize" : "fit"
              },
              "large" : {
                "w" : "962",
                "h" : "526",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "962",
                "h" : "526",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/JxzyddArTL"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1349130726378237952"
          ],
          "editableUntil" : "2021-01-12T23:36:45.462Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "35",
              "49"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Hypha Discovery",
            "screen_name" : "HyphaD",
            "indices" : [
              "81",
              "88"
            ],
            "id_str" : "1029353745472266240",
            "id" : "1029353745472266240"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "239",
              "249"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/92Qg9Ojc44",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/50",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "186",
              "209"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1349130726378237952/photo/1",
            "indices" : [
              "263",
              "286"
            ],
            "url" : "https://t.co/THmSOuqq2c",
            "media_url" : "http://pbs.twimg.com/media/ErkTAzeXMAML8v3.jpg",
            "id_str" : "1349130467912658947",
            "id" : "1349130467912658947",
            "media_url_https" : "https://pbs.twimg.com/media/ErkTAzeXMAML8v3.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "306",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1116",
                "h" : "502",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1116",
                "h" : "502",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/THmSOuqq2c"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "59",
              "71"
            ]
          },
          {
            "text" : "metabolism",
            "indices" : [
              "210",
              "221"
            ]
          },
          {
            "text" : "oxidation",
            "indices" : [
              "222",
              "232"
            ]
          },
          {
            "text" : "ADME",
            "indices" : [
              "233",
              "238"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "250",
              "262"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "286"
      ],
      "favorite_count" : "2",
      "id_str" : "1349130726378237952",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1349130726378237952",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jan 12 23:06:45 +0000 2021",
      "favorited" : false,
      "full_text" : "Important industry contribution to @OSantibiotics Series 2 #OpenScience project: @HyphaD have generated new data on metabolic transformation of the lead compound and are now scaling up. https://t.co/92Qg9Ojc44 #metabolism #oxidation #ADME @macinchem #antibiotics https://t.co/THmSOuqq2c",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1349130726378237952/photo/1",
            "indices" : [
              "263",
              "286"
            ],
            "url" : "https://t.co/THmSOuqq2c",
            "media_url" : "http://pbs.twimg.com/media/ErkTAzeXMAML8v3.jpg",
            "id_str" : "1349130467912658947",
            "id" : "1349130467912658947",
            "media_url_https" : "https://pbs.twimg.com/media/ErkTAzeXMAML8v3.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "306",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1116",
                "h" : "502",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1116",
                "h" : "502",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/THmSOuqq2c"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1346108803025149953"
          ],
          "editableUntil" : "2021-01-04T15:28:42.790Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "117",
              "129"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "GitHub",
            "screen_name" : "github",
            "indices" : [
              "24",
              "31"
            ],
            "id_str" : "13334762",
            "id" : "13334762"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1346108803025149953",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1346108803025149953",
      "created_at" : "Mon Jan 04 14:58:42 +0000 2021",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Trying @github as blog. First up a question: what are the best guidelines for donating molecules to #openscience projects?…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1339930326773198853"
          ],
          "editableUntil" : "2020-12-18T14:17:39.261Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "24",
              "36"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "3",
              "17"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1339930326773198853",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1339930326773198853",
      "created_at" : "Fri Dec 18 13:47:39 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @OSantibiotics: Last #openscience update meeting before the holidays starting in 10 mins on Zoom. All welcome. Agenda: https://t.co/JzSb…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1339930237077995522"
          ],
          "editableUntil" : "2020-12-18T14:17:17.876Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "AMRC",
            "screen_name" : "AMRC",
            "indices" : [
              "159",
              "164"
            ],
            "id_str" : "16432203",
            "id" : "16432203"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/JzSbqMgQzy",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/49",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "103",
              "126"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1339930237077995522/photo/1",
            "indices" : [
              "189",
              "212"
            ],
            "url" : "https://t.co/TpmdvkoXTf",
            "media_url" : "http://pbs.twimg.com/media/EphjU1-W4AAxSw4.png",
            "id_str" : "1339930098879881216",
            "id" : "1339930098879881216",
            "media_url_https" : "https://pbs.twimg.com/media/EphjU1-W4AAxSw4.png",
            "sizes" : {
              "medium" : {
                "w" : "477",
                "h" : "299",
                "resize" : "fit"
              },
              "small" : {
                "w" : "477",
                "h" : "299",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "477",
                "h" : "299",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/TpmdvkoXTf"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "5",
              "17"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "165",
              "177"
            ]
          },
          {
            "text" : "superbugs",
            "indices" : [
              "178",
              "188"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "212"
      ],
      "favorite_count" : "2",
      "id_str" : "1339930237077995522",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1339930237077995522",
      "possibly_sensitive" : false,
      "created_at" : "Fri Dec 18 13:47:17 +0000 2020",
      "favorited" : false,
      "full_text" : "Last #openscience update meeting before the holidays starting in 10 mins on Zoom. All welcome. Agenda: https://t.co/JzSbqMgQzy New data vs MRSA needs thought. @AMRC #antibiotics #superbugs https://t.co/TpmdvkoXTf",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1339930237077995522/photo/1",
            "indices" : [
              "189",
              "212"
            ],
            "url" : "https://t.co/TpmdvkoXTf",
            "media_url" : "http://pbs.twimg.com/media/EphjU1-W4AAxSw4.png",
            "id_str" : "1339930098879881216",
            "id" : "1339930098879881216",
            "media_url_https" : "https://pbs.twimg.com/media/EphjU1-W4AAxSw4.png",
            "sizes" : {
              "medium" : {
                "w" : "477",
                "h" : "299",
                "resize" : "fit"
              },
              "small" : {
                "w" : "477",
                "h" : "299",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "477",
                "h" : "299",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/TpmdvkoXTf"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1333813005700788224"
          ],
          "editableUntil" : "2020-12-01T17:09:36.263Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Diamond Light Source",
            "screen_name" : "DiamondLightSou",
            "indices" : [
              "21",
              "37"
            ],
            "id_str" : "16927254",
            "id" : "16927254"
          },
          {
            "name" : "Protein Data Bank",
            "screen_name" : "PDBeurope",
            "indices" : [
              "77",
              "87"
            ],
            "id_str" : "201239379",
            "id" : "201239379"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "175",
              "187"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/rAQhtrFXeI",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/34",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "88",
              "111"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1333813005700788224/photo/1",
            "indices" : [
              "188",
              "211"
            ],
            "url" : "https://t.co/bP4GLf0ZjS",
            "media_url" : "http://pbs.twimg.com/media/EoKnzvjXcAEFm6c.jpg",
            "id_str" : "1333812947035058177",
            "id" : "1333812947035058177",
            "media_url_https" : "https://pbs.twimg.com/media/EoKnzvjXcAEFm6c.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1186",
                "h" : "686",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "393",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1186",
                "h" : "686",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bP4GLf0ZjS"
          }
        ],
        "hashtags" : [
          {
            "text" : "murligase",
            "indices" : [
              "53",
              "63"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "160",
              "174"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "211"
      ],
      "favorite_count" : "6",
      "id_str" : "1333813005700788224",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1333813005700788224",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 01 16:39:36 +0000 2020",
      "favorited" : false,
      "full_text" : "Lizbé Koekemoer from @DiamondLightSou highlights new #murligase structure on @PDBeurope https://t.co/rAQhtrFXeI Potentially useful for design of new inhibitors #drugdiscovery @LoriFerrins https://t.co/bP4GLf0ZjS",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1333813005700788224/photo/1",
            "indices" : [
              "188",
              "211"
            ],
            "url" : "https://t.co/bP4GLf0ZjS",
            "media_url" : "http://pbs.twimg.com/media/EoKnzvjXcAEFm6c.jpg",
            "id_str" : "1333812947035058177",
            "id" : "1333812947035058177",
            "media_url_https" : "https://pbs.twimg.com/media/EoKnzvjXcAEFm6c.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1186",
                "h" : "686",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "393",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "1186",
                "h" : "686",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/bP4GLf0ZjS"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1333811755991117824"
          ],
          "editableUntil" : "2020-12-01T17:04:38.309Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "AstraZeneca",
            "screen_name" : "AstraZeneca",
            "indices" : [
              "73",
              "85"
            ],
            "id_str" : "62465691",
            "id" : "62465691"
          },
          {
            "name" : "Enamine Ltd 🇺🇦",
            "screen_name" : "EnamineLtd",
            "indices" : [
              "165",
              "176"
            ],
            "id_str" : "1655695452",
            "id" : "1655695452"
          },
          {
            "name" : "Alfa Aesar",
            "screen_name" : "AlfaAesar",
            "indices" : [
              "177",
              "187"
            ],
            "id_str" : "320476197",
            "id" : "320476197"
          },
          {
            "name" : "Aurora Fine Chemical",
            "screen_name" : "AuroraChemicals",
            "indices" : [
              "188",
              "204"
            ],
            "id_str" : "4204799952",
            "id" : "4204799952"
          },
          {
            "name" : "Dayang ☀️",
            "screen_name" : "DayangUsop",
            "indices" : [
              "205",
              "216"
            ],
            "id_str" : "1051819040379953153",
            "id" : "1051819040379953153"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/zkaDW6UfzW",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/35",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "128",
              "151"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1333811755991117824/photo/1",
            "indices" : [
              "217",
              "240"
            ],
            "url" : "https://t.co/kMYCfsz2rZ",
            "media_url" : "http://pbs.twimg.com/media/EoKmVW1XUAA5t-u.jpg",
            "id_str" : "1333811325491957760",
            "id" : "1333811325491957760",
            "media_url_https" : "https://pbs.twimg.com/media/EoKmVW1XUAA5t-u.jpg",
            "sizes" : {
              "large" : {
                "w" : "1170",
                "h" : "622",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1170",
                "h" : "622",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "362",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/kMYCfsz2rZ"
          }
        ],
        "hashtags" : [
          {
            "text" : "murligase",
            "indices" : [
              "86",
              "96"
            ]
          },
          {
            "text" : "orgchem",
            "indices" : [
              "107",
              "115"
            ]
          },
          {
            "text" : "antibiotic",
            "indices" : [
              "116",
              "127"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "152",
              "164"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "240"
      ],
      "favorite_count" : "2",
      "id_str" : "1333811755991117824",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1333811755991117824",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 01 16:34:38 +0000 2020",
      "favorited" : false,
      "full_text" : "Dayang Usop looking at starting material availability for resynthesis of @AstraZeneca #murligase inhibitor #orgchem #antibiotic https://t.co/zkaDW6UfzW #openscience @EnamineLtd @AlfaAesar @AuroraChemicals @DayangUsop https://t.co/kMYCfsz2rZ",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1333811755991117824/photo/1",
            "indices" : [
              "217",
              "240"
            ],
            "url" : "https://t.co/kMYCfsz2rZ",
            "media_url" : "http://pbs.twimg.com/media/EoKmVW1XUAA5t-u.jpg",
            "id_str" : "1333811325491957760",
            "id" : "1333811325491957760",
            "media_url_https" : "https://pbs.twimg.com/media/EoKmVW1XUAA5t-u.jpg",
            "sizes" : {
              "large" : {
                "w" : "1170",
                "h" : "622",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1170",
                "h" : "622",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "362",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/kMYCfsz2rZ"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1332346898875899908"
          ],
          "editableUntil" : "2020-11-27T16:03:49.157Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/TJ61hlwavo",
            "expanded_url" : "https://www.cambridgemedchemconsulting.com/news/index_files/36ed1f59f4df03c0202a2a5ee3148217-450.html",
            "display_url" : "cambridgemedchemconsulting.com/news/index_fil…",
            "indices" : [
              "63",
              "86"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1332346898875899908",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1332346898875899908",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 27 15:33:49 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @macinchem: Read about the OpenSource Antibiotics projects. https://t.co/TJ61hlwavo All the structures of the molecules on the project a…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1331567377864126464"
          ],
          "editableUntil" : "2020-11-25T12:26:16.865Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "RSC_CICAG",
            "screen_name" : "RSC_CICAG",
            "indices" : [
              "0",
              "10"
            ],
            "id_str" : "447019817",
            "id" : "447019817"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/1QoLmXfIdT",
            "expanded_url" : "https://youtu.be/Is2hLqqSFvM",
            "display_url" : "youtu.be/Is2hLqqSFvM",
            "indices" : [
              "87",
              "110"
            ]
          },
          {
            "url" : "https://t.co/XIH8hvRFOK",
            "expanded_url" : "https://youtu.be/qOxS2wqajdg",
            "display_url" : "youtu.be/qOxS2wqajdg",
            "indices" : [
              "117",
              "140"
            ]
          },
          {
            "url" : "https://t.co/hDUEgpieN6",
            "expanded_url" : "https://youtu.be/KEIpJ50Jc0w",
            "display_url" : "youtu.be/KEIpJ50Jc0w",
            "indices" : [
              "153",
              "176"
            ]
          },
          {
            "url" : "https://t.co/2jdYgHvsZe",
            "expanded_url" : "https://youtu.be/zpzJutFTtL4",
            "display_url" : "youtu.be/zpzJutFTtL4",
            "indices" : [
              "184",
              "207"
            ]
          },
          {
            "url" : "https://t.co/OLintUo3ny",
            "expanded_url" : "https://youtu.be/LVWd50CgU4g",
            "display_url" : "youtu.be/LVWd50CgU4g",
            "indices" : [
              "219",
              "242"
            ]
          },
          {
            "url" : "https://t.co/BBhZA2398p",
            "expanded_url" : "https://youtu.be/lP0Yh6kKNsA",
            "display_url" : "youtu.be/lP0Yh6kKNsA",
            "indices" : [
              "249",
              "272"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "272"
      ],
      "favorite_count" : "4",
      "id_str" : "1331567377864126464",
      "in_reply_to_user_id" : "447019817",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1331567377864126464",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 25 11:56:16 +0000 2020",
      "favorited" : false,
      "full_text" : "@RSC_CICAG workshops for key Open-Source Chem software, videos now online\n\nDataWarrior https://t.co/1QoLmXfIdT\nPyMOL https://t.co/XIH8hvRFOK\nGoogleCoLab https://t.co/hDUEgpieN6\nChEMBL https://t.co/2jdYgHvsZe\nFragalysis https://t.co/OLintUo3ny\nKnime https://t.co/BBhZA2398p",
      "lang" : "en",
      "in_reply_to_screen_name" : "RSC_CICAG",
      "in_reply_to_user_id_str" : "447019817"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1329427525286637572"
          ],
          "editableUntil" : "2020-11-19T14:43:16.254Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "urmi bajpai",
            "screen_name" : "urmibajpai",
            "indices" : [
              "0",
              "11"
            ],
            "id_str" : "122948818",
            "id" : "122948818"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "237",
              "249"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "250",
              "260"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "261",
              "271"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "271"
      ],
      "favorite_count" : "2",
      "in_reply_to_status_id_str" : "1328978316670377984",
      "id_str" : "1329427525286637572",
      "in_reply_to_user_id" : "122948818",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1329427525286637572",
      "in_reply_to_status_id" : "1328978316670377984",
      "created_at" : "Thu Nov 19 14:13:16 +0000 2020",
      "favorited" : false,
      "full_text" : "@urmibajpai Not yet. Going to get them evaluated in MurE and MurD both biochemically and crystallographically if possible. We've about 3mg of each, so will need to see how much we need. Would love to exchange samples with you if we can! @MatToddChem @dana_klug @edwintse_",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "in_reply_to_screen_name" : "urmibajpai",
      "in_reply_to_user_id_str" : "122948818"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1327261583723155456"
          ],
          "editableUntil" : "2020-11-13T15:16:35.544Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/VYgSXntevZ",
            "expanded_url" : "https://twitter.com/dana_klug/status/1327260229956997121",
            "display_url" : "twitter.com/dana_klug/stat…",
            "indices" : [
              "2",
              "25"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "25"
      ],
      "favorite_count" : "2",
      "id_str" : "1327261583723155456",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1327261583723155456",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 13 14:46:35 +0000 2020",
      "favorited" : false,
      "full_text" : "😍 https://t.co/VYgSXntevZ",
      "lang" : "art",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1327215012583239680"
          ],
          "editableUntil" : "2020-11-13T12:11:32.119Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "150",
              "160"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "161",
              "171"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "172",
              "184"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "185",
              "197"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "198",
              "208"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "209",
              "221"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "UCL School of Pharmacy",
            "screen_name" : "School_Pharmacy",
            "indices" : [
              "222",
              "238"
            ],
            "id_str" : "56353603",
            "id" : "56353603"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "239",
              "252"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/6qgBD5KZCi",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/40",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "96",
              "119"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1327215012583239680/photo/1",
            "indices" : [
              "253",
              "276"
            ],
            "url" : "https://t.co/52w78NmmxV",
            "media_url" : "http://pbs.twimg.com/media/Ems2j0mXcAEiHsM.png",
            "id_str" : "1327214504233627649",
            "id" : "1327214504233627649",
            "media_url_https" : "https://pbs.twimg.com/media/Ems2j0mXcAEiHsM.png",
            "sizes" : {
              "medium" : {
                "w" : "443",
                "h" : "180",
                "resize" : "fit"
              },
              "large" : {
                "w" : "443",
                "h" : "180",
                "resize" : "fit"
              },
              "small" : {
                "w" : "443",
                "h" : "180",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/52w78NmmxV"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "83",
              "95"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "120",
              "132"
            ]
          },
          {
            "text" : "MRSA",
            "indices" : [
              "133",
              "138"
            ]
          },
          {
            "text" : "superbugs",
            "indices" : [
              "139",
              "149"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "276"
      ],
      "favorite_count" : "1",
      "id_str" : "1327215012583239680",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1327215012583239680",
      "possibly_sensitive" : false,
      "created_at" : "Fri Nov 13 11:41:32 +0000 2020",
      "favorited" : false,
      "full_text" : "Next science update Zoom in 2 hours (2pm UK time). Focus on Series 2. All welcome. #openscience https://t.co/6qgBD5KZCi #antibiotics #MRSA #superbugs @edwintse_ @macinchem @mfernflower @MatToddChem @dana_klug @LoriFerrins @School_Pharmacy @Wellcome_AMR https://t.co/52w78NmmxV",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1327215012583239680/photo/1",
            "indices" : [
              "253",
              "276"
            ],
            "url" : "https://t.co/52w78NmmxV",
            "media_url" : "http://pbs.twimg.com/media/Ems2j0mXcAEiHsM.png",
            "id_str" : "1327214504233627649",
            "id" : "1327214504233627649",
            "media_url_https" : "https://pbs.twimg.com/media/Ems2j0mXcAEiHsM.png",
            "sizes" : {
              "medium" : {
                "w" : "443",
                "h" : "180",
                "resize" : "fit"
              },
              "large" : {
                "w" : "443",
                "h" : "180",
                "resize" : "fit"
              },
              "small" : {
                "w" : "443",
                "h" : "180",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/52w78NmmxV"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1324118346539933696"
          ],
          "editableUntil" : "2020-11-04T23:06:29.401Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/t4tpqV1MrE",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/38",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "111",
              "134"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1324118346539933696/photo/1",
            "indices" : [
              "243",
              "266"
            ],
            "url" : "https://t.co/z5pQZNaUYY",
            "media_url" : "http://pbs.twimg.com/media/EmA2bl6XEAE7DkZ.png",
            "id_str" : "1324118138108186625",
            "id" : "1324118138108186625",
            "media_url_https" : "https://pbs.twimg.com/media/EmA2bl6XEAE7DkZ.png",
            "sizes" : {
              "medium" : {
                "w" : "802",
                "h" : "584",
                "resize" : "fit"
              },
              "large" : {
                "w" : "802",
                "h" : "584",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "495",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/z5pQZNaUYY"
          }
        ],
        "hashtags" : [
          {
            "text" : "drugdiscovery",
            "indices" : [
              "202",
              "216"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "217",
              "229"
            ]
          },
          {
            "text" : "Openscience",
            "indices" : [
              "230",
              "242"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "266"
      ],
      "favorite_count" : "5",
      "id_str" : "1324118346539933696",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1324118346539933696",
      "possibly_sensitive" : false,
      "created_at" : "Wed Nov 04 22:36:29 +0000 2020",
      "favorited" : false,
      "full_text" : "This week's open, online research meeting is an hour earlier than usual, *Friday 1pm*. All welcome. Zoom link: https://t.co/t4tpqV1MrE Most important item: compound design following recent potency data #drugdiscovery #antibiotics #Openscience https://t.co/z5pQZNaUYY",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1324118346539933696/photo/1",
            "indices" : [
              "243",
              "266"
            ],
            "url" : "https://t.co/z5pQZNaUYY",
            "media_url" : "http://pbs.twimg.com/media/EmA2bl6XEAE7DkZ.png",
            "id_str" : "1324118138108186625",
            "id" : "1324118138108186625",
            "media_url_https" : "https://pbs.twimg.com/media/EmA2bl6XEAE7DkZ.png",
            "sizes" : {
              "medium" : {
                "w" : "802",
                "h" : "584",
                "resize" : "fit"
              },
              "large" : {
                "w" : "802",
                "h" : "584",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "495",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/z5pQZNaUYY"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1321776827707330563"
          ],
          "editableUntil" : "2020-10-29T12:02:07.808Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "60",
              "74"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "187",
              "199"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "200",
              "210"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "211",
              "221"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "222",
              "234"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "235",
              "243"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "244",
              "254"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/FghBulXpMK",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/35",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "104",
              "127"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1321776827707330563/photo/1",
            "indices" : [
              "270",
              "293"
            ],
            "url" : "https://t.co/7GjQqcuN1i",
            "media_url" : "http://pbs.twimg.com/media/Elfk9q-XgAA2bE_.png",
            "id_str" : "1321776763815559168",
            "id" : "1321776763815559168",
            "media_url_https" : "https://pbs.twimg.com/media/Elfk9q-XgAA2bE_.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "361",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "856",
                "h" : "454",
                "resize" : "fit"
              },
              "large" : {
                "w" : "856",
                "h" : "454",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/7GjQqcuN1i"
          }
        ],
        "hashtags" : [
          {
            "text" : "drugdiscovery",
            "indices" : [
              "255",
              "269"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "293"
      ],
      "favorite_count" : "4",
      "id_str" : "1321776827707330563",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1321776827707330563",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 29 11:32:07 +0000 2020",
      "favorited" : false,
      "full_text" : "Crucial meeting on Friday to discuss latest data vs MRSA in @OSantibiotics series 1. What to make next? https://t.co/FghBulXpMK We seem to require a 2-pyridyl motif, bringing a tox risk? @MatToddChem @dana_klug @edwintse_ @mfernflower @MrBenGP @macinchem #drugdiscovery https://t.co/7GjQqcuN1i",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1321776827707330563/photo/1",
            "indices" : [
              "270",
              "293"
            ],
            "url" : "https://t.co/7GjQqcuN1i",
            "media_url" : "http://pbs.twimg.com/media/Elfk9q-XgAA2bE_.png",
            "id_str" : "1321776763815559168",
            "id" : "1321776763815559168",
            "media_url_https" : "https://pbs.twimg.com/media/Elfk9q-XgAA2bE_.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "361",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "856",
                "h" : "454",
                "resize" : "fit"
              },
              "large" : {
                "w" : "856",
                "h" : "454",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/7GjQqcuN1i"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1321227519954046977"
          ],
          "editableUntil" : "2020-10-27T23:39:22.634Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AutoDockVina",
            "indices" : [
              "38",
              "51"
            ]
          },
          {
            "text" : "CompChem",
            "indices" : [
              "216",
              "225"
            ]
          },
          {
            "text" : "drugdesign",
            "indices" : [
              "226",
              "237"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Project Jupyter",
            "screen_name" : "ProjectJupyter",
            "indices" : [
              "19",
              "34"
            ],
            "id_str" : "2460368252",
            "id" : "2460368252"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/IXtoqOnu9u",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/32",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "192",
              "215"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "237"
      ],
      "favorite_count" : "4",
      "id_str" : "1321227519954046977",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1321227519954046977",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 27 23:09:22 +0000 2020",
      "favorited" : false,
      "full_text" : "Any Datawarrior or @ProjectJupyter or #AutoDockVina mavens out there able to help project student Dayang troubleshoot the preparation of conformers for an open antibiotics docking experiment? https://t.co/IXtoqOnu9u #CompChem #drugdesign",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1321223281253429257"
          ],
          "editableUntil" : "2020-10-27T23:22:32.049Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Matthew Boudreau",
            "screen_name" : "The_Boudreau",
            "indices" : [
              "205",
              "218"
            ],
            "id_str" : "4473654262",
            "id" : "4473654262"
          },
          {
            "name" : "Paul Hergenrother",
            "screen_name" : "PaulHergie",
            "indices" : [
              "219",
              "230"
            ],
            "id_str" : "1492415988",
            "id" : "1492415988"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/zFjWTNDwKq",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/31",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "156",
              "179"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1321223281253429257/photo/1",
            "indices" : [
              "231",
              "254"
            ],
            "url" : "https://t.co/2gp6Xdms6W",
            "media_url" : "http://pbs.twimg.com/media/ElXtUWvWMAQv73-.png",
            "id_str" : "1321222999660441604",
            "id" : "1321222999660441604",
            "media_url_https" : "https://pbs.twimg.com/media/ElXtUWvWMAQv73-.png",
            "sizes" : {
              "medium" : {
                "w" : "854",
                "h" : "568",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "452",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "854",
                "h" : "568",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/2gp6Xdms6W"
          }
        ],
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "180",
              "192"
            ]
          },
          {
            "text" : "drugdesign",
            "indices" : [
              "193",
              "204"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "254"
      ],
      "favorite_count" : "1",
      "id_str" : "1321223281253429257",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1321223281253429257",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 27 22:52:32 +0000 2020",
      "favorited" : false,
      "full_text" : "Project student Dayang Usop looking for help with checking whether her molecule suggestion aligns with eNTRy criteria, and how to calculate Glob and VSurfA https://t.co/zFjWTNDwKq #antibiotics #drugdesign @The_Boudreau @PaulHergie https://t.co/2gp6Xdms6W",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1321223281253429257/photo/1",
            "indices" : [
              "231",
              "254"
            ],
            "url" : "https://t.co/2gp6Xdms6W",
            "media_url" : "http://pbs.twimg.com/media/ElXtUWvWMAQv73-.png",
            "id_str" : "1321222999660441604",
            "id" : "1321222999660441604",
            "media_url_https" : "https://pbs.twimg.com/media/ElXtUWvWMAQv73-.png",
            "sizes" : {
              "medium" : {
                "w" : "854",
                "h" : "568",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "452",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "854",
                "h" : "568",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/2gp6Xdms6W"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1319623695850229760"
          ],
          "editableUntil" : "2020-10-23T13:26:21.170Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "133",
              "145"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/5pNduxTx8s",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/36",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "109",
              "132"
            ]
          },
          {
            "url" : "https://t.co/Gw7BwzkCwK",
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1317124466812571649",
            "display_url" : "twitter.com/OSantibiotics/…",
            "indices" : [
              "146",
              "169"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "169"
      ],
      "favorite_count" : "1",
      "id_str" : "1319623695850229760",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1319623695850229760",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 23 12:56:21 +0000 2020",
      "favorited" : false,
      "full_text" : "Today's meeting gets going in 5 mins. Probably short - MRSA and VRE screen happening right now. Agenda items https://t.co/5pNduxTx8s #OpenScience https://t.co/Gw7BwzkCwK",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1319578409597603840"
          ],
          "editableUntil" : "2020-10-23T10:26:24.086Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/XJq5EkDhm1",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/34",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "45",
              "68"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1319578409597603840/photo/1",
            "indices" : [
              "201",
              "224"
            ],
            "url" : "https://t.co/PnQ84QSTyd",
            "media_url" : "http://pbs.twimg.com/media/ElAVUUVXUAIdoHd.jpg",
            "id_str" : "1319578129619439618",
            "id" : "1319578129619439618",
            "media_url_https" : "https://pbs.twimg.com/media/ElAVUUVXUAIdoHd.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "795",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "451",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1222",
                "h" : "810",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/PnQ84QSTyd"
          }
        ],
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "155",
              "167"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "168",
              "180"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "181",
              "195"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "196",
              "200"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "224"
      ],
      "favorite_count" : "5",
      "id_str" : "1319578409597603840",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1319578409597603840",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 23 09:56:24 +0000 2020",
      "favorited" : false,
      "full_text" : "First email newsletter sent! Can be found at https://t.co/XJq5EkDhm1 If you'd like to receive future newsletters, get in touch (e.g. reply to this tweet). #antibiotics #openscience #drugdiscovery #AMR https://t.co/PnQ84QSTyd",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1319578409597603840/photo/1",
            "indices" : [
              "201",
              "224"
            ],
            "url" : "https://t.co/PnQ84QSTyd",
            "media_url" : "http://pbs.twimg.com/media/ElAVUUVXUAIdoHd.jpg",
            "id_str" : "1319578129619439618",
            "id" : "1319578129619439618",
            "media_url_https" : "https://pbs.twimg.com/media/ElAVUUVXUAIdoHd.jpg",
            "sizes" : {
              "medium" : {
                "w" : "1200",
                "h" : "795",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "451",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1222",
                "h" : "810",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/PnQ84QSTyd"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1317124466812571649"
          ],
          "editableUntil" : "2020-10-16T15:55:18.534Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "172",
              "184"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "185",
              "195"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "196",
              "204"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          },
          {
            "name" : "UCL School of Pharmacy",
            "screen_name" : "School_Pharmacy",
            "indices" : [
              "268",
              "284"
            ],
            "id_str" : "56353603",
            "id" : "56353603"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/1lcspZUfnJ",
            "expanded_url" : "https://youtu.be/gl4ippR1x1k",
            "display_url" : "youtu.be/gl4ippR1x1k",
            "indices" : [
              "31",
              "54"
            ]
          },
          {
            "url" : "https://t.co/auEZ5zftP0",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/33",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "63",
              "86"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1317124466812571649/photo/1",
            "indices" : [
              "285",
              "308"
            ],
            "url" : "https://t.co/IQvTwen61N",
            "media_url" : "http://pbs.twimg.com/media/EkddYUGXUAA0DNB.jpg",
            "id_str" : "1317124088322805760",
            "id" : "1317124088322805760",
            "media_url_https" : "https://pbs.twimg.com/media/EkddYUGXUAA0DNB.jpg",
            "sizes" : {
              "large" : {
                "w" : "1701",
                "h" : "789",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "557",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/IQvTwen61N"
          }
        ],
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "205",
              "217"
            ]
          },
          {
            "text" : "DrugDiscovery",
            "indices" : [
              "218",
              "232"
            ]
          },
          {
            "text" : "metabolism",
            "indices" : [
              "233",
              "244"
            ]
          },
          {
            "text" : "superbug",
            "indices" : [
              "245",
              "254"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "255",
              "267"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "308"
      ],
      "favorite_count" : "6",
      "id_str" : "1317124466812571649",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1317124466812571649",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 16 15:25:18 +0000 2020",
      "favorited" : false,
      "full_text" : "Good meeting today. Recording: https://t.co/1lcspZUfnJ Summary https://t.co/auEZ5zftP0 Lots of data coming for next week, same time 2pm London. Thanks for time &amp; ideas @mfernflower @macinchem @MrBenGP #antibiotics #DrugDiscovery #metabolism #superbug #openscience @School_Pharmacy https://t.co/IQvTwen61N",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1317124466812571649/photo/1",
            "indices" : [
              "285",
              "308"
            ],
            "url" : "https://t.co/IQvTwen61N",
            "media_url" : "http://pbs.twimg.com/media/EkddYUGXUAA0DNB.jpg",
            "id_str" : "1317124088322805760",
            "id" : "1317124088322805760",
            "media_url_https" : "https://pbs.twimg.com/media/EkddYUGXUAA0DNB.jpg",
            "sizes" : {
              "large" : {
                "w" : "1701",
                "h" : "789",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "557",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/IQvTwen61N"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1316832704881664000"
          ],
          "editableUntil" : "2020-10-15T20:35:57.069Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UCL School of Pharmacy",
            "screen_name" : "School_Pharmacy",
            "indices" : [
              "47",
              "63"
            ],
            "id_str" : "56353603",
            "id" : "56353603"
          },
          {
            "name" : "Protein Data Bank",
            "screen_name" : "PDBeurope",
            "indices" : [
              "112",
              "122"
            ],
            "id_str" : "201239379",
            "id" : "201239379"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/WfgEy4CjXI",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/30",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "129",
              "152"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1316832704881664000/photo/1",
            "indices" : [
              "163",
              "186"
            ],
            "url" : "https://t.co/RDd8iXPQBh",
            "media_url" : "http://pbs.twimg.com/media/EkZTfbGWAAA90n1.jpg",
            "id_str" : "1316831740367863808",
            "id" : "1316831740367863808",
            "media_url_https" : "https://pbs.twimg.com/media/EkZTfbGWAAA90n1.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "418",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1360",
                "h" : "836",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "738",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RDd8iXPQBh"
          }
        ],
        "hashtags" : [
          {
            "text" : "compchem",
            "indices" : [
              "153",
              "162"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "186"
      ],
      "favorite_count" : "5",
      "id_str" : "1316832704881664000",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1316832704881664000",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 15 20:05:57 +0000 2020",
      "favorited" : false,
      "full_text" : "New project undergrad student Dayang Usop from @School_Pharmacy seeking help in making 2D interaction maps from @PDBeurope files https://t.co/WfgEy4CjXI #compchem https://t.co/RDd8iXPQBh",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1316832704881664000/photo/1",
            "indices" : [
              "163",
              "186"
            ],
            "url" : "https://t.co/RDd8iXPQBh",
            "media_url" : "http://pbs.twimg.com/media/EkZTfbGWAAA90n1.jpg",
            "id_str" : "1316831740367863808",
            "id" : "1316831740367863808",
            "media_url_https" : "https://pbs.twimg.com/media/EkZTfbGWAAA90n1.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "418",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1360",
                "h" : "836",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "738",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RDd8iXPQBh"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1315972020279148544"
          ],
          "editableUntil" : "2020-10-13T11:35:53.869Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "166",
              "178"
            ]
          },
          {
            "text" : "compchem",
            "indices" : [
              "179",
              "188"
            ]
          },
          {
            "text" : "enzyme",
            "indices" : [
              "189",
              "196"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "197",
              "209"
            ]
          },
          {
            "text" : "drugdesign",
            "indices" : [
              "210",
              "221"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/4BOBkvlIkY",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/27",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "142",
              "165"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "221"
      ],
      "favorite_count" : "1",
      "id_str" : "1315972020279148544",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1315972020279148544",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 13 11:05:53 +0000 2020",
      "favorited" : false,
      "full_text" : "Open Source Antibiotics Series 1 Mur Ligases. Journal Club. Analysis of 2016 paper on MurD Domain Movement and relevance to substrate binding https://t.co/4BOBkvlIkY #openscience #compchem #enzyme #antibiotics #drugdesign",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1315971551574085632"
          ],
          "editableUntil" : "2020-10-13T11:34:02.121Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "compchem",
            "indices" : [
              "160",
              "169"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "170",
              "184"
            ]
          },
          {
            "text" : "OpenScience",
            "indices" : [
              "185",
              "197"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/k26h0HXvUy",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/28",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "136",
              "159"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "197"
      ],
      "favorite_count" : "2",
      "id_str" : "1315971551574085632",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1315971551574085632",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 13 11:04:02 +0000 2020",
      "favorited" : false,
      "full_text" : "Open Source Antibiotics Series 1 Mur Ligases. Request for help comparing ATP binding sites of two mur ligases and comparison with human https://t.co/k26h0HXvUy #compchem #drugdiscovery #OpenScience",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1315754210890256392"
          ],
          "editableUntil" : "2020-10-12T21:10:24.064Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "149",
              "159"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "160",
              "172"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "173",
              "183"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/h47ZNRPQAW",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/26",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "92",
              "115"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1315754210890256392/photo/1",
            "indices" : [
              "225",
              "248"
            ],
            "url" : "https://t.co/RFKBhugVJW",
            "media_url" : "http://pbs.twimg.com/media/EkJ_XNFX0AMk6kf.png",
            "id_str" : "1315754077771517955",
            "id" : "1315754077771517955",
            "media_url_https" : "https://pbs.twimg.com/media/EkJ_XNFX0AMk6kf.png",
            "sizes" : {
              "medium" : {
                "w" : "704",
                "h" : "642",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "620",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "704",
                "h" : "642",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RFKBhugVJW"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "184",
              "196"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "197",
              "209"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "210",
              "224"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "248"
      ],
      "favorite_count" : "6",
      "id_str" : "1315754210890256392",
      "truncated" : false,
      "retweet_count" : "8",
      "id" : "1315754210890256392",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 12 20:40:24 +0000 2020",
      "favorited" : false,
      "full_text" : "Next online research meeting to discuss Series 1 (the mur ligases) will be on November 4th: https://t.co/h47ZNRPQAW Ping any attendee for Zoom code. @dana_klug @LoriFerrins @macinchem #OpenScience #antibiotics #drugdiscovery https://t.co/RFKBhugVJW",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1315754210890256392/photo/1",
            "indices" : [
              "225",
              "248"
            ],
            "url" : "https://t.co/RFKBhugVJW",
            "media_url" : "http://pbs.twimg.com/media/EkJ_XNFX0AMk6kf.png",
            "id_str" : "1315754077771517955",
            "id" : "1315754077771517955",
            "media_url_https" : "https://pbs.twimg.com/media/EkJ_XNFX0AMk6kf.png",
            "sizes" : {
              "medium" : {
                "w" : "704",
                "h" : "642",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "620",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "704",
                "h" : "642",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/RFKBhugVJW"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1315670676284551175"
          ],
          "editableUntil" : "2020-10-12T15:38:27.862Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "4",
              "18"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "36",
              "46"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/uxONYrO3fI",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/tree/master/Website%20Materials/Website%20Pix",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "57",
              "80"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "90"
      ],
      "favorite_count" : "4",
      "id_str" : "1315670676284551175",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1315670676284551175",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 12 15:08:27 +0000 2020",
      "favorited" : false,
      "full_text" : "New @OSantibiotics logo! Created by @edwintse_  files at https://t.co/uxONYrO3fI CC-BY-4.0",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1315657593176588293"
          ],
          "editableUntil" : "2020-10-12T14:46:28.606Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "cytotoxicity",
            "indices" : [
              "33",
              "46"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ZooJNsdPY7",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/3#issuecomment-707140786",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "95",
              "118"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "118"
      ],
      "favorite_count" : "0",
      "id_str" : "1315657593176588293",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1315657593176588293",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 12 14:16:28 +0000 2020",
      "favorited" : false,
      "full_text" : "Lab identified that will provide #cytotoxicity assay on HEK293. Important re selectivity index https://t.co/ZooJNsdPY7",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1314563192056623104"
          ],
          "editableUntil" : "2020-10-09T14:17:43.046Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "60",
              "70"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "71",
              "83"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "104",
              "114"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "115",
              "125"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "239",
              "252"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          },
          {
            "name" : "CARB-X",
            "screen_name" : "CARB_X",
            "indices" : [
              "253",
              "260"
            ],
            "id_str" : "752900258011774976",
            "id" : "752900258011774976"
          },
          {
            "name" : "CO-ADD Antibiotics",
            "screen_name" : "COADD_news",
            "indices" : [
              "261",
              "272"
            ],
            "id_str" : "3045189728",
            "id" : "3045189728"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/IMQVVsWROR",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/32",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "185",
              "208"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1314563192056623104/photo/1",
            "indices" : [
              "273",
              "296"
            ],
            "url" : "https://t.co/GLM12fvc4j",
            "media_url" : "http://pbs.twimg.com/media/Ej5D1nRXcAEt4VG.jpg",
            "id_str" : "1314562729592713217",
            "id" : "1314562729592713217",
            "media_url_https" : "https://pbs.twimg.com/media/Ej5D1nRXcAEt4VG.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "396",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1590",
                "h" : "926",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "699",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/GLM12fvc4j"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "296"
      ],
      "favorite_count" : "6",
      "id_str" : "1314563192056623104",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1314563192056623104",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 09 13:47:43 +0000 2020",
      "favorited" : false,
      "full_text" : "Really good to see everyone just now. Good suggestions from @macinchem @mfernflower cool synthesis from @edwintse_ @dana_klug New Q: is cytotox arising from chelating 2-pyridyl moiety? https://t.co/IMQVVsWROR Next meeting: Friday 16th 2pm @Wellcome_AMR @carb_x @COADD_news https://t.co/GLM12fvc4j",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1314563192056623104/photo/1",
            "indices" : [
              "273",
              "296"
            ],
            "url" : "https://t.co/GLM12fvc4j",
            "media_url" : "http://pbs.twimg.com/media/Ej5D1nRXcAEt4VG.jpg",
            "id_str" : "1314562729592713217",
            "id" : "1314562729592713217",
            "media_url_https" : "https://pbs.twimg.com/media/Ej5D1nRXcAEt4VG.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "396",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1590",
                "h" : "926",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "699",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/GLM12fvc4j"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1314198582669393920"
          ],
          "editableUntil" : "2020-10-08T14:08:53.394Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "50",
              "64"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "144",
              "156"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "180",
              "192"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "194",
              "204"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "SSGCID",
            "screen_name" : "SSGCID",
            "indices" : [
              "209",
              "216"
            ],
            "id_str" : "1327978831",
            "id" : "1327978831"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/2j8Kgjk39X",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/25",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "92",
              "115"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1314198582669393920/photo/1",
            "indices" : [
              "242",
              "265"
            ],
            "url" : "https://t.co/xB1jg5A3in",
            "media_url" : "http://pbs.twimg.com/media/Ejz4QdbVcAA6hGb.jpg",
            "id_str" : "1314198152946216960",
            "id" : "1314198152946216960",
            "media_url_https" : "https://pbs.twimg.com/media/Ejz4QdbVcAA6hGb.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1264",
                "h" : "585",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "555",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/xB1jg5A3in"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "11",
              "23"
            ]
          },
          {
            "text" : "Antibiotics",
            "indices" : [
              "229",
              "241"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "265"
      ],
      "favorite_count" : "1",
      "id_str" : "1314198582669393920",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1314198582669393920",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 08 13:38:53 +0000 2020",
      "favorited" : false,
      "full_text" : "Summary of #openscience research Zoom from Tue on @OSantibiotics Series 1 - the mur ligases https://t.co/2j8Kgjk39X Lots to do. Featuring teams @mattoddchem, von Delft and Dowson, @LoriFerrins, @macinchem and @SSGCID Great team! #Antibiotics https://t.co/xB1jg5A3in",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1314198582669393920/photo/1",
            "indices" : [
              "242",
              "265"
            ],
            "url" : "https://t.co/xB1jg5A3in",
            "media_url" : "http://pbs.twimg.com/media/Ejz4QdbVcAA6hGb.jpg",
            "id_str" : "1314198152946216960",
            "id" : "1314198152946216960",
            "media_url_https" : "https://pbs.twimg.com/media/Ejz4QdbVcAA6hGb.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "315",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1264",
                "h" : "585",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "555",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/xB1jg5A3in"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1311992919071633410"
          ],
          "editableUntil" : "2020-10-02T12:04:22.213Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/JkhdqpYBq8",
            "expanded_url" : "https://twitter.com/macinchem/status/1311991033404760067",
            "display_url" : "twitter.com/macinchem/stat…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "id_str" : "1311992919071633410",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1311992919071633410",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 02 11:34:22 +0000 2020",
      "favorited" : false,
      "full_text" : "https://t.co/JkhdqpYBq8",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1311927084525256709"
          ],
          "editableUntil" : "2020-10-02T07:42:46.034Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/yp31FAqhV1",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/6#issue-713405191",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "29",
              "52"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "52"
      ],
      "favorite_count" : "3",
      "id_str" : "1311927084525256709",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1311927084525256709",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 02 07:12:46 +0000 2020",
      "favorited" : false,
      "full_text" : "Antibiotic Research webinars https://t.co/yp31FAqhV1",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1311717755641626625"
          ],
          "editableUntil" : "2020-10-01T17:50:58.139Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "37",
              "49"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "68",
              "82"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1311717755641626625",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1311717755641626625",
      "created_at" : "Thu Oct 01 17:20:58 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Loving these weekly #openscience meetings over at \n@OSantibiotics progressing a public, patent-free series that is active…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1311716312742326279"
          ],
          "editableUntil" : "2020-10-01T17:45:14.125Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "GitHub",
            "screen_name" : "github",
            "indices" : [
              "107",
              "114"
            ],
            "id_str" : "13334762",
            "id" : "13334762"
          },
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "188",
              "198"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          },
          {
            "name" : "Save Antibiotics",
            "screen_name" : "saveantibiotics",
            "indices" : [
              "199",
              "215"
            ],
            "id_str" : "198919608",
            "id" : "198919608"
          },
          {
            "name" : "Dr. Lori Ferrins",
            "screen_name" : "LoriFerrins",
            "indices" : [
              "216",
              "228"
            ],
            "id_str" : "3151901774",
            "id" : "3151901774"
          },
          {
            "name" : "CO-ADD Antibiotics",
            "screen_name" : "COADD_news",
            "indices" : [
              "229",
              "240"
            ],
            "id_str" : "3045189728",
            "id" : "3045189728"
          },
          {
            "name" : "AMR at Wellcome",
            "screen_name" : "Wellcome_AMR",
            "indices" : [
              "241",
              "254"
            ],
            "id_str" : "3292777305",
            "id" : "3292777305"
          },
          {
            "name" : "CARB-X",
            "screen_name" : "CARB_X",
            "indices" : [
              "255",
              "262"
            ],
            "id_str" : "752900258011774976",
            "id" : "752900258011774976"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/PY1VVQiCAj",
            "expanded_url" : "https://ucl.zoom.us/j/92800004715",
            "display_url" : "ucl.zoom.us/j/92800004715",
            "indices" : [
              "73",
              "96"
            ]
          },
          {
            "url" : "https://t.co/goPmUXFD9C",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/30",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "118",
              "141"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1311716312742326279/photo/1",
            "indices" : [
              "263",
              "286"
            ],
            "url" : "https://t.co/Z5OGw2kM44",
            "media_url" : "http://pbs.twimg.com/media/EjQmAdxXcAAMqAB.jpg",
            "id_str" : "1311715180905197568",
            "id" : "1311715180905197568",
            "media_url_https" : "https://pbs.twimg.com/media/EjQmAdxXcAAMqAB.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "425",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1468",
                "h" : "918",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "750",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Z5OGw2kM44"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "164",
              "176"
            ]
          },
          {
            "text" : "MRSA",
            "indices" : [
              "177",
              "182"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "183",
              "187"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "286"
      ],
      "favorite_count" : "2",
      "id_str" : "1311716312742326279",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1311716312742326279",
      "possibly_sensitive" : false,
      "created_at" : "Thu Oct 01 17:15:14 +0000 2020",
      "favorited" : false,
      "full_text" : "Weekly public research Zoom is tomorrow (Fri) as always at 2pm London at https://t.co/PY1VVQiCAj Agenda on @github at https://t.co/goPmUXFD9C Drug hunters welcome. #openscience #MRSA #AMR @gardp_amr @saveantibiotics @LoriFerrins @COADD_news @Wellcome_AMR @CARB_X https://t.co/Z5OGw2kM44",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1311716312742326279/photo/1",
            "indices" : [
              "263",
              "286"
            ],
            "url" : "https://t.co/Z5OGw2kM44",
            "media_url" : "http://pbs.twimg.com/media/EjQmAdxXcAAMqAB.jpg",
            "id_str" : "1311715180905197568",
            "id" : "1311715180905197568",
            "media_url_https" : "https://pbs.twimg.com/media/EjQmAdxXcAAMqAB.jpg",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "425",
                "resize" : "fit"
              },
              "large" : {
                "w" : "1468",
                "h" : "918",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "750",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/Z5OGw2kM44"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1309476341260136449"
          ],
          "editableUntil" : "2020-09-25T13:24:23.307Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "79",
              "93"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/HuVEnxA8zL",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/29",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "112",
              "135"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1309476341260136449",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1309476341260136449",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 25 12:54:23 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @dana_klug: Yes! Chemistry update and new clearance data to discuss for our @OSantibiotics meeting. Details: https://t.co/HuVEnxA8zL\n@Lo…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1306964282878300160"
          ],
          "editableUntil" : "2020-09-18T15:02:21.917Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "orgchem",
            "indices" : [
              "130",
              "138"
            ]
          },
          {
            "text" : "OpenScience",
            "indices" : [
              "202",
              "214"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "215",
              "227"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "144",
              "154"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "159",
              "169"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "191",
              "201"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "262",
              "270"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/ZAOvQyQTyF",
            "expanded_url" : "https://www.youtube.com/watch?v=WcfalfBJxQ4",
            "display_url" : "youtube.com/watch?v=Wcfalf…",
            "indices" : [
              "46",
              "69"
            ]
          },
          {
            "url" : "https://t.co/joLAYgXOXk",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/28",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "91",
              "114"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "270"
      ],
      "favorite_count" : "2",
      "id_str" : "1306964282878300160",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1306964282878300160",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 18 14:32:21 +0000 2020",
      "favorited" : false,
      "full_text" : "Good science update meeting today. Recording: https://t.co/ZAOvQyQTyF Relevant discussion: https://t.co/joLAYgXOXk Lots of lovely #orgchem from @dana_klug and @edwintse_ with mentorship from @macinchem #OpenScience #antibiotics Excited to receive compounds from @MrBenGP",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1306937940044582912"
          ],
          "editableUntil" : "2020-09-18T13:17:41.296Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "244",
              "256"
            ]
          },
          {
            "text" : "MRSA",
            "indices" : [
              "257",
              "262"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "263",
              "275"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "235",
              "243"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/PY1VVQiCAj",
            "expanded_url" : "https://ucl.zoom.us/j/92800004715",
            "display_url" : "ucl.zoom.us/j/92800004715",
            "indices" : [
              "68",
              "91"
            ]
          },
          {
            "url" : "https://t.co/joLAYhfqlU",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/28",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "107",
              "130"
            ]
          },
          {
            "url" : "https://t.co/73Te8oJTBr",
            "expanded_url" : "https://www.youtube.com/watch?v=DutqAq2c4Mo",
            "display_url" : "youtube.com/watch?v=DutqAq…",
            "indices" : [
              "151",
              "174"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "275"
      ],
      "favorite_count" : "2",
      "id_str" : "1306937940044582912",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1306937940044582912",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 18 12:47:41 +0000 2020",
      "favorited" : false,
      "full_text" : "Weekly science meeting ready to go in 15 mins at 2pm London time at https://t.co/PY1VVQiCAj. Agenda etc at https://t.co/joLAYhfqlU Previous meeting at https://t.co/73Te8oJTBr Developments this week: big injection of new molecules from @MrBenGP #openscience #MRSA #antibiotics",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1304368941146529792"
          ],
          "editableUntil" : "2020-09-11T11:09:24.229Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "GitHub",
            "screen_name" : "github",
            "indices" : [
              "7",
              "14"
            ],
            "id_str" : "13334762",
            "id" : "13334762"
          },
          {
            "name" : "Ben Perry",
            "screen_name" : "MrBenGP",
            "indices" : [
              "152",
              "160"
            ],
            "id_str" : "21594424",
            "id" : "21594424"
          },
          {
            "name" : "Drugs for Neglected Diseases initiative",
            "screen_name" : "DNDi",
            "indices" : [
              "188",
              "193"
            ],
            "id_str" : "256440168",
            "id" : "256440168"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/lXzC7az5me",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/26",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "57",
              "80"
            ]
          },
          {
            "url" : "https://t.co/GwC87tvGH4",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/25#issuecomment-690909006",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "164",
              "187"
            ]
          },
          {
            "url" : "https://t.co/PY1VVQiCAj",
            "expanded_url" : "https://ucl.zoom.us/j/92800004715",
            "display_url" : "ucl.zoom.us/j/92800004715",
            "indices" : [
              "205",
              "228"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1304368941146529792/photo/1",
            "indices" : [
              "242",
              "265"
            ],
            "url" : "https://t.co/zSq2hG2nVN",
            "media_url" : "http://pbs.twimg.com/media/EhoMYicXYAMwi-c.png",
            "id_str" : "1304368657779351555",
            "id" : "1304368657779351555",
            "media_url_https" : "https://pbs.twimg.com/media/EhoMYicXYAMwi-c.png",
            "sizes" : {
              "medium" : {
                "w" : "314",
                "h" : "386",
                "resize" : "fit"
              },
              "large" : {
                "w" : "314",
                "h" : "386",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "314",
                "h" : "386",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/zSq2hG2nVN"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "229",
              "241"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "265"
      ],
      "favorite_count" : "0",
      "id_str" : "1304368941146529792",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1304368941146529792",
      "possibly_sensitive" : false,
      "created_at" : "Fri Sep 11 10:39:24 +0000 2020",
      "favorited" : false,
      "full_text" : "Agenda @github issue for meeting later today 2pm London: https://t.co/lXzC7az5me Main item to discuss is new potency data and excellent new inputs from @MrBenGP at https://t.co/GwC87tvGH4 @DNDi Meeting at https://t.co/PY1VVQiCAj #openscience https://t.co/zSq2hG2nVN",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1304368941146529792/photo/1",
            "indices" : [
              "242",
              "265"
            ],
            "url" : "https://t.co/zSq2hG2nVN",
            "media_url" : "http://pbs.twimg.com/media/EhoMYicXYAMwi-c.png",
            "id_str" : "1304368657779351555",
            "id" : "1304368657779351555",
            "media_url_https" : "https://pbs.twimg.com/media/EhoMYicXYAMwi-c.png",
            "sizes" : {
              "medium" : {
                "w" : "314",
                "h" : "386",
                "resize" : "fit"
              },
              "large" : {
                "w" : "314",
                "h" : "386",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "314",
                "h" : "386",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/zSq2hG2nVN"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1304184613326159873"
          ],
          "editableUntil" : "2020-09-10T22:56:57.052Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UCL School of Pharmacy",
            "screen_name" : "School_Pharmacy",
            "indices" : [
              "88",
              "104"
            ],
            "id_str" : "56353603",
            "id" : "56353603"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/DKrg3BT3E1",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/25",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "106",
              "129"
            ]
          },
          {
            "url" : "https://t.co/PY1VVQiCAj",
            "expanded_url" : "https://ucl.zoom.us/j/92800004715",
            "display_url" : "ucl.zoom.us/j/92800004715",
            "indices" : [
              "229",
              "252"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1304184613326159873/photo/1",
            "indices" : [
              "266",
              "289"
            ],
            "url" : "https://t.co/hbMG3clOAv",
            "media_url" : "http://pbs.twimg.com/media/Ehlk9AiWsAA_FCn.png",
            "id_str" : "1304184566379360256",
            "id" : "1304184566379360256",
            "media_url_https" : "https://pbs.twimg.com/media/Ehlk9AiWsAA_FCn.png",
            "sizes" : {
              "medium" : {
                "w" : "704",
                "h" : "420",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "704",
                "h" : "420",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "406",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/hbMG3clOAv"
          }
        ],
        "hashtags" : [
          {
            "text" : "MRSA",
            "indices" : [
              "59",
              "64"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "253",
              "265"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "289"
      ],
      "favorite_count" : "7",
      "id_str" : "1304184613326159873",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1304184613326159873",
      "possibly_sensitive" : false,
      "created_at" : "Thu Sep 10 22:26:57 +0000 2020",
      "favorited" : false,
      "full_text" : "New potency data! 9 new compounds evaluated in Series 2 vs #MRSA by Paul Stapleton from @School_Pharmacy. https://t.co/DKrg3BT3E1 Need now to plan next round of synthesis, which we'll do in tomorrow's meeting: 2pm London time at https://t.co/PY1VVQiCAj #openscience https://t.co/hbMG3clOAv",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1304184613326159873/photo/1",
            "indices" : [
              "266",
              "289"
            ],
            "url" : "https://t.co/hbMG3clOAv",
            "media_url" : "http://pbs.twimg.com/media/Ehlk9AiWsAA_FCn.png",
            "id_str" : "1304184566379360256",
            "id" : "1304184566379360256",
            "media_url_https" : "https://pbs.twimg.com/media/Ehlk9AiWsAA_FCn.png",
            "sizes" : {
              "medium" : {
                "w" : "704",
                "h" : "420",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "large" : {
                "w" : "704",
                "h" : "420",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "406",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/hbMG3clOAv"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1301485517993844736"
          ],
          "editableUntil" : "2020-09-03T12:11:42.578Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1301485517993844736",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1301485517993844736",
      "created_at" : "Thu Sep 03 11:41:42 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @dana_klug: Next OSA Series 2 meeting is TOMORROW (2/9) at 2pm UK time! All are welcome; Zoom link and draft agenda here: https://t.co/K…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1298621272834875395"
          ],
          "editableUntil" : "2020-08-26T14:30:13.317Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/wxeMgzocfV",
            "expanded_url" : "http://www.ai3sd.org/events/ai3sd-event-list/16092020-ai3sdonlineseminarseriestbc-drjenniferhiscock",
            "display_url" : "ai3sd.org/events/ai3sd-e…",
            "indices" : [
              "160",
              "183"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "183"
      ],
      "favorite_count" : "3",
      "id_str" : "1298621272834875395",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1298621272834875395",
      "possibly_sensitive" : false,
      "created_at" : "Wed Aug 26 14:00:13 +0000 2020",
      "favorited" : false,
      "full_text" : "From molecular self-association to novel weapons in the fight against antimicrobial resistance – the next target for AI/Machine Learning? - Dr Jennifer Hiscock https://t.co/wxeMgzocfV",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1296822380522803206"
          ],
          "editableUntil" : "2020-08-21T15:22:03.968Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AntibioticResistance",
            "indices" : [
              "159",
              "180"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "181",
              "185"
            ]
          },
          {
            "text" : "MRSA",
            "indices" : [
              "186",
              "191"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "192",
              "204"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "205",
              "219"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "GitHub",
            "screen_name" : "github",
            "indices" : [
              "81",
              "88"
            ],
            "id_str" : "13334762",
            "id" : "13334762"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/AsvpH5YZve",
            "expanded_url" : "https://youtu.be/LPcbZEa6njs",
            "display_url" : "youtu.be/LPcbZEa6njs",
            "indices" : [
              "33",
              "56"
            ]
          },
          {
            "url" : "https://t.co/7DI1nA7cYv",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/23",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "90",
              "113"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "219"
      ],
      "favorite_count" : "2",
      "id_str" : "1296822380522803206",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1296822380522803206",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 21 14:52:03 +0000 2020",
      "favorited" : false,
      "full_text" : "Latest meeting was today. Video: https://t.co/AsvpH5YZve. Minutes and actions on @github: https://t.co/7DI1nA7cYv. Next meeting will be next Friday same time. #AntibioticResistance #AMR #MRSA #openscience #drugdiscovery",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1288231496285933569"
          ],
          "editableUntil" : "2020-07-28T22:24:57.555Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "61",
              "73"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "221",
              "231"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "232",
              "242"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          },
          {
            "name" : "mfernflower",
            "screen_name" : "mfernflower",
            "indices" : [
              "243",
              "255"
            ],
            "id_str" : "1203457392320696322",
            "id" : "1203457392320696322"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/ssj1E1CpvH",
            "expanded_url" : "https://youtu.be/lr4ic21ak90",
            "display_url" : "youtu.be/lr4ic21ak90",
            "indices" : [
              "74",
              "97"
            ]
          },
          {
            "url" : "https://t.co/j20zr7tM4T",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/19",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "121",
              "144"
            ]
          },
          {
            "url" : "https://t.co/PY1VVQiCAj",
            "expanded_url" : "https://ucl.zoom.us/j/92800004715",
            "display_url" : "ucl.zoom.us/j/92800004715",
            "indices" : [
              "179",
              "202"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1288231496285933569/photo/1",
            "indices" : [
              "279",
              "302"
            ],
            "url" : "https://t.co/yFK8v3N9jC",
            "media_url" : "http://pbs.twimg.com/media/EeC3W0IWsAIgYGs.png",
            "id_str" : "1288231096006651906",
            "id" : "1288231096006651906",
            "media_url_https" : "https://pbs.twimg.com/media/EeC3W0IWsAIgYGs.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "386",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1162",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "681",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/yFK8v3N9jC"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "203",
              "215"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "216",
              "220"
            ]
          },
          {
            "text" : "opensourceantibiotics",
            "indices" : [
              "256",
              "278"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "302"
      ],
      "favorite_count" : "3",
      "id_str" : "1288231496285933569",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1288231496285933569",
      "possibly_sensitive" : false,
      "created_at" : "Tue Jul 28 21:54:57 +0000 2020",
      "favorited" : false,
      "full_text" : "Recording of science update meeting July 24th 2020 posted by @mattoddchem https://t.co/ssj1E1CpvH Relevant Github issue: https://t.co/j20zr7tM4T Next meeting Friday 2pm London at https://t.co/PY1VVQiCAj #openscience #AMR @dana_klug @edwintse_ @mfernflower #opensourceantibiotics https://t.co/yFK8v3N9jC",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1288231496285933569/photo/1",
            "indices" : [
              "279",
              "302"
            ],
            "url" : "https://t.co/yFK8v3N9jC",
            "media_url" : "http://pbs.twimg.com/media/EeC3W0IWsAIgYGs.png",
            "id_str" : "1288231096006651906",
            "id" : "1288231096006651906",
            "media_url_https" : "https://pbs.twimg.com/media/EeC3W0IWsAIgYGs.png",
            "sizes" : {
              "small" : {
                "w" : "680",
                "h" : "386",
                "resize" : "fit"
              },
              "large" : {
                "w" : "2048",
                "h" : "1162",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "681",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/yFK8v3N9jC"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1286593444249509888"
          ],
          "editableUntil" : "2020-07-24T09:55:55.516Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "34",
              "48"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1286593444249509888",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1286593444249509888",
      "created_at" : "Fri Jul 24 09:25:55 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Notes on today's @OSantibiotics meeting at 2pm UK time are here and will evolve until after the meeting: https://t.co/PYSB…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1286430284854984709"
          ],
          "editableUntil" : "2020-07-23T23:07:35.285Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "77",
              "91"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/boBluhAE37",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/17",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "178",
              "201"
            ]
          },
          {
            "url" : "https://t.co/PY1VVQiCAj",
            "expanded_url" : "https://ucl.zoom.us/j/92800004715",
            "display_url" : "ucl.zoom.us/j/92800004715",
            "indices" : [
              "219",
              "242"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "272"
      ],
      "favorite_count" : "1",
      "id_str" : "1286430284854984709",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1286430284854984709",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jul 23 22:37:35 +0000 2020",
      "favorited" : false,
      "full_text" : "Short research meeting tomorrow, Fri Jul 24, at 2pm UK time (9 EDT, 3 EU) on @OSantibiotics Series 2. *Chemistry has started*. Other items relate to MoA and metabolic clearance (https://t.co/boBluhAE37). All welcome at https://t.co/PY1VVQiCAj. Will be recorded and posted.",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1284405109863129088"
          ],
          "editableUntil" : "2020-07-18T09:00:15.941Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "CID",
            "indices" : [
              "32",
              "36"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Antibiotic Steward Bassam Ghanem🆔🌟",
            "screen_name" : "ABsteward",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "204748499",
            "id" : "204748499"
          },
          {
            "name" : "Todd Lee",
            "screen_name" : "DrToddLee",
            "indices" : [
              "37",
              "47"
            ],
            "id_str" : "4260929247",
            "id" : "4260929247"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1284405109863129088",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1284405109863129088",
      "created_at" : "Sat Jul 18 08:30:15 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @ABsteward: DASH PUBLISHED💥💥 #CID @DrToddLee\nAmong patients with MSSA bloodstream infections, the administration of adjunctive daptomyci…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1284404982792491010"
          ],
          "editableUntil" : "2020-07-18T08:59:45.645Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1284404982792491010",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1284404982792491010",
      "created_at" : "Sat Jul 18 08:29:45 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @macinchem: It's time to fix the antibiotic market. Governments must act now to safeguard the world's supply of new antibiotics #StopSup…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1284120889446084611"
          ],
          "editableUntil" : "2020-07-17T14:10:52.513Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "19",
              "33"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "156",
              "166"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/boBluhAE37",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/17",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "76",
              "99"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1284120889446084611/photo/1",
            "indices" : [
              "239",
              "262"
            ],
            "url" : "https://t.co/q8Hide3MXo",
            "media_url" : "http://pbs.twimg.com/media/EdIcvpMXYAI6YwH.png",
            "id_str" : "1284120448591159298",
            "id" : "1284120448591159298",
            "media_url_https" : "https://pbs.twimg.com/media/EdIcvpMXYAI6YwH.png",
            "sizes" : {
              "small" : {
                "w" : "580",
                "h" : "251",
                "resize" : "fit"
              },
              "large" : {
                "w" : "580",
                "h" : "251",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "580",
                "h" : "251",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/q8Hide3MXo"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "6",
              "18"
            ]
          },
          {
            "text" : "metabolicclearance",
            "indices" : [
              "125",
              "144"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "145",
              "149"
            ]
          },
          {
            "text" : "MRSA",
            "indices" : [
              "150",
              "155"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "262"
      ],
      "favorite_count" : "1",
      "id_str" : "1284120889446084611",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1284120889446084611",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jul 17 13:40:52 +0000 2020",
      "favorited" : false,
      "full_text" : "Quick #openscience @OSantibiotics Zoom today to fix To Do List, shown here: https://t.co/boBluhAE37 Lots of things needed re #metabolicclearance #AMR #MRSA @macinchem As an open science project, all welcome to contribute to existing team. https://t.co/q8Hide3MXo",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1284120889446084611/photo/1",
            "indices" : [
              "239",
              "262"
            ],
            "url" : "https://t.co/q8Hide3MXo",
            "media_url" : "http://pbs.twimg.com/media/EdIcvpMXYAI6YwH.png",
            "id_str" : "1284120448591159298",
            "id" : "1284120448591159298",
            "media_url_https" : "https://pbs.twimg.com/media/EdIcvpMXYAI6YwH.png",
            "sizes" : {
              "small" : {
                "w" : "580",
                "h" : "251",
                "resize" : "fit"
              },
              "large" : {
                "w" : "580",
                "h" : "251",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "580",
                "h" : "251",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/q8Hide3MXo"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1284120211185074179"
          ],
          "editableUntil" : "2020-07-17T14:08:10.803Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "50",
              "64"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          },
          {
            "name" : "Dana Klug",
            "screen_name" : "dana_klug",
            "indices" : [
              "184",
              "194"
            ],
            "id_str" : "118924001",
            "id" : "118924001"
          },
          {
            "name" : "Edwin Tse",
            "screen_name" : "edwintse_",
            "indices" : [
              "195",
              "205"
            ],
            "id_str" : "2997727057",
            "id" : "2997727057"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/A07Q2nYJYl",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/16",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "160",
              "183"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1284120211185074179/photo/1",
            "indices" : [
              "224",
              "247"
            ],
            "url" : "https://t.co/8udjLqI844",
            "media_url" : "http://pbs.twimg.com/media/EdIcbrsWsAECztL.png",
            "id_str" : "1284120105664819201",
            "id" : "1284120105664819201",
            "media_url_https" : "https://pbs.twimg.com/media/EdIcbrsWsAECztL.png",
            "sizes" : {
              "large" : {
                "w" : "354",
                "h" : "245",
                "resize" : "fit"
              },
              "small" : {
                "w" : "354",
                "h" : "245",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "354",
                "h" : "245",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/8udjLqI844"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "206",
              "218"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "219",
              "223"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "247"
      ],
      "favorite_count" : "4",
      "id_str" : "1284120211185074179",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1284120211185074179",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jul 17 13:38:10 +0000 2020",
      "favorited" : false,
      "full_text" : "Chem lab at UCL has reopened! So new molecules in @OSantibiotics Series 2 are being made. Improve potency vs MRSA, slow down metabolic clearance. Targets here: https://t.co/A07Q2nYJYl @dana_klug @edwintse_ #openscience #AMR https://t.co/8udjLqI844",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1284120211185074179/photo/1",
            "indices" : [
              "224",
              "247"
            ],
            "url" : "https://t.co/8udjLqI844",
            "media_url" : "http://pbs.twimg.com/media/EdIcbrsWsAECztL.png",
            "id_str" : "1284120105664819201",
            "id" : "1284120105664819201",
            "media_url_https" : "https://pbs.twimg.com/media/EdIcbrsWsAECztL.png",
            "sizes" : {
              "large" : {
                "w" : "354",
                "h" : "245",
                "resize" : "fit"
              },
              "small" : {
                "w" : "354",
                "h" : "245",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "354",
                "h" : "245",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/8udjLqI844"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1278267546999848960"
          ],
          "editableUntil" : "2020-07-01T10:31:46.924Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "UNC Pharmacy",
            "screen_name" : "UNCPharmacy",
            "indices" : [
              "149",
              "161"
            ],
            "id_str" : "15750564",
            "id" : "15750564"
          },
          {
            "name" : "Monash Pharmacy & Pharmaceutical Sciences",
            "screen_name" : "MonashPharm",
            "indices" : [
              "165",
              "177"
            ],
            "id_str" : "2573833471",
            "id" : "2573833471"
          },
          {
            "name" : "Working to Fight AMR",
            "screen_name" : "WeFightAMR",
            "indices" : [
              "253",
              "264"
            ],
            "id_str" : "1149691029576192000",
            "id" : "1149691029576192000"
          },
          {
            "name" : "Global Antibiotic R&D Partnership (GARDP)",
            "screen_name" : "gardp_amr",
            "indices" : [
              "265",
              "275"
            ],
            "id_str" : "1088022968628924421",
            "id" : "1088022968628924421"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/eJiQub488l",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/13",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "90",
              "113"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1278267546999848960/photo/1",
            "indices" : [
              "276",
              "299"
            ],
            "url" : "https://t.co/VWNnY7Bdrm",
            "media_url" : "http://pbs.twimg.com/media/Eb1RdT-XgAEbjpn.png",
            "id_str" : "1278267433263005697",
            "id" : "1278267433263005697",
            "media_url_https" : "https://pbs.twimg.com/media/Eb1RdT-XgAEbjpn.png",
            "sizes" : {
              "large" : {
                "w" : "682",
                "h" : "360",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "359",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "682",
                "h" : "360",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/VWNnY7Bdrm"
          }
        ],
        "hashtags" : [
          {
            "text" : "openscience",
            "indices" : [
              "234",
              "246"
            ]
          },
          {
            "text" : "MRSA",
            "indices" : [
              "247",
              "252"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "299"
      ],
      "favorite_count" : "1",
      "id_str" : "1278267546999848960",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1278267546999848960",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jul 01 10:01:46 +0000 2020",
      "favorited" : false,
      "full_text" : "Metabolic clearance for Open Source Antibiotics Series 2 needs to be fixed! Discussion at https://t.co/eJiQub488l about which molecules to send from @UNCPharmacy to @MonashPharm. Any experts on solubility, in vitro PK please chip in. #openscience #MRSA @WeFightAMR @gardp_amr https://t.co/VWNnY7Bdrm",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1278267546999848960/photo/1",
            "indices" : [
              "276",
              "299"
            ],
            "url" : "https://t.co/VWNnY7Bdrm",
            "media_url" : "http://pbs.twimg.com/media/Eb1RdT-XgAEbjpn.png",
            "id_str" : "1278267433263005697",
            "id" : "1278267433263005697",
            "media_url_https" : "https://pbs.twimg.com/media/Eb1RdT-XgAEbjpn.png",
            "sizes" : {
              "large" : {
                "w" : "682",
                "h" : "360",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "359",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "682",
                "h" : "360",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/VWNnY7Bdrm"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1274989359515738112"
          ],
          "editableUntil" : "2020-06-22T09:25:26.122Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "YouTube",
            "screen_name" : "YouTube",
            "indices" : [
              "109",
              "117"
            ],
            "id_str" : "10228272",
            "id" : "10228272"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/erXdcnTekq",
            "expanded_url" : "https://youtu.be/kHig7P-ohO8",
            "display_url" : "youtu.be/kHig7P-ohO8",
            "indices" : [
              "81",
              "104"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "117"
      ],
      "favorite_count" : "1",
      "id_str" : "1274989359515738112",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1274989359515738112",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jun 22 08:55:26 +0000 2020",
      "favorited" : false,
      "full_text" : "GARDP:Bringing new treatments for drug resistant infections to all who need them https://t.co/erXdcnTekq via @YouTube",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1274989002400182272"
          ],
          "editableUntil" : "2020-06-22T09:24:00.979Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/ICBz92xayd",
            "expanded_url" : "https://goo.gl/fb/2vJwBM",
            "display_url" : "goo.gl/fb/2vJwBM",
            "indices" : [
              "64",
              "87"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "87"
      ],
      "favorite_count" : "0",
      "id_str" : "1274989002400182272",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1274989002400182272",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jun 22 08:54:00 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @macinchem: Computational Tools for Drug Discovery Workshops https://t.co/ICBz92xayd",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1273159826428829696"
          ],
          "editableUntil" : "2020-06-17T08:15:31.443Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Royal Society of Chemistry",
            "screen_name" : "RoySocChem",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "309087942",
            "id" : "309087942"
          },
          {
            "name" : "Royal Society of Chemistry Books",
            "screen_name" : "RoySocChemBooks",
            "indices" : [
              "73",
              "89"
            ],
            "id_str" : "1234437591812001792",
            "id" : "1234437591812001792"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1273159826428829696",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1273159826428829696",
      "created_at" : "Wed Jun 17 07:45:31 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @RoySocChem: Last chance to vote... ⏰  \n\nFor the first time ever, the @RoySocChemBooks has five presidential candidates. \n\nVoting is als…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1273159510773977090"
          ],
          "editableUntil" : "2020-06-17T08:14:16.185Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "98",
              "110"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Battle Superbugs ☮️",
            "screen_name" : "battlesuperbugs",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "3288561903",
            "id" : "3288561903"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1273159510773977090",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1273159510773977090",
      "created_at" : "Wed Jun 17 07:44:16 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @battlesuperbugs: A good reminder that in many parts of the world, the worry is not overuse of #antibiotics. Instead, it's counterfeit d…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1273159260780867590"
          ],
          "editableUntil" : "2020-06-17T08:13:16.582Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/t0PRmfH4fP",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/wiki/CompChem-Tools",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "80",
              "103"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "103"
      ],
      "favorite_count" : "4",
      "id_str" : "1273159260780867590",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1273159260780867590",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jun 17 07:43:16 +0000 2020",
      "favorited" : false,
      "full_text" : "The CompChem Tools section of the Open Source Antibiotics wiki has been updated https://t.co/t0PRmfH4fP",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1250038599657160704"
          ],
          "editableUntil" : "2020-04-14T13:00:01.409Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/y8pUPDQChq",
            "expanded_url" : "https://github.com/opensourceantibiotics/Series-2-Diarylimidazoles/issues/12",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "46",
              "69"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "136"
      ],
      "favorite_count" : "2",
      "id_str" : "1250038599657160704",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1250038599657160704",
      "possibly_sensitive" : false,
      "created_at" : "Tue Apr 14 12:30:01 +0000 2020",
      "favorited" : false,
      "full_text" : "Thinking about the TPP for a novel antibiotic https://t.co/y8pUPDQChq . Input very much appreciated, especially input on clinical needs.",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1248157211257458688"
          ],
          "editableUntil" : "2020-04-09T08:24:03.460Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/wy3OXWNytd",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/3#issuecomment-611382836",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "161",
              "184"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "184"
      ],
      "favorite_count" : "1",
      "id_str" : "1248157211257458688",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1248157211257458688",
      "possibly_sensitive" : false,
      "created_at" : "Thu Apr 09 07:54:03 +0000 2020",
      "favorited" : false,
      "full_text" : "An analysis of postmortem samples from the “Spanish flu” pandemic of 1918 to 1919 highlighted that secondary bacterial infections caused the majority of deaths. https://t.co/wy3OXWNytd",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1243579361766322177"
          ],
          "editableUntil" : "2020-03-27T17:13:19.089Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/bkdXD1H4Wv",
            "expanded_url" : "https://twitter.com/MNBhebhe/status/1243568537597284356",
            "display_url" : "twitter.com/MNBhebhe/statu…",
            "indices" : [
              "31",
              "54"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "54"
      ],
      "favorite_count" : "0",
      "id_str" : "1243579361766322177",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1243579361766322177",
      "possibly_sensitive" : false,
      "created_at" : "Fri Mar 27 16:43:19 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @macinchem: Fabulous result https://t.co/bkdXD1H4Wv",
      "lang" : "fr"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1240323088090308610"
          ],
          "editableUntil" : "2020-03-18T17:34:02.946Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/rgRnZA0iPD",
            "expanded_url" : "https://twitter.com/london_lab/status/1240318572968259584",
            "display_url" : "twitter.com/london_lab/sta…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "id_str" : "1240323088090308610",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1240323088090308610",
      "possibly_sensitive" : false,
      "created_at" : "Wed Mar 18 17:04:02 +0000 2020",
      "favorited" : false,
      "full_text" : "https://t.co/rgRnZA0iPD",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1238761910625017856"
          ],
          "editableUntil" : "2020-03-14T10:10:29.233Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          },
          {
            "name" : "YouTube",
            "screen_name" : "YouTube",
            "indices" : [
              "114",
              "122"
            ],
            "id_str" : "10228272",
            "id" : "10228272"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/aDbyBu8TK8",
            "expanded_url" : "https://youtu.be/blkDulsgh3Q",
            "display_url" : "youtu.be/blkDulsgh3Q",
            "indices" : [
              "86",
              "109"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1238761910625017856",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1238761910625017856",
      "possibly_sensitive" : false,
      "created_at" : "Sat Mar 14 09:40:29 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @macinchem: Coronavirus: Can herd immunity protect the population? - BBC Newsnight https://t.co/aDbyBu8TK8 via @YouTube Everyone should…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1237527508372713472"
          ],
          "editableUntil" : "2020-03-11T00:25:24.802Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/HkyuiMVSZO",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/18",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "25",
              "48"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1237527508372713472/photo/1",
            "indices" : [
              "183",
              "206"
            ],
            "url" : "https://t.co/NGs9gsKdCz",
            "media_url" : "http://pbs.twimg.com/media/ESyUbdCU0AEWbXc.jpg",
            "id_str" : "1237527196991803393",
            "id" : "1237527196991803393",
            "media_url_https" : "https://pbs.twimg.com/media/ESyUbdCU0AEWbXc.jpg",
            "sizes" : {
              "large" : {
                "w" : "1214",
                "h" : "1112",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "623",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "1099",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/NGs9gsKdCz"
          }
        ],
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "157",
              "169"
            ]
          },
          {
            "text" : "OpenScience",
            "indices" : [
              "170",
              "182"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "206"
      ],
      "favorite_count" : "0",
      "id_str" : "1237527508372713472",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1237527508372713472",
      "possibly_sensitive" : false,
      "created_at" : "Tue Mar 10 23:55:24 +0000 2020",
      "favorited" : false,
      "full_text" : "Meeting 1 recording: see https://t.co/HkyuiMVSZO plus a question on how we should deal with recordings of meetings (which we're now going to have regularly) #antibiotics #OpenScience https://t.co/NGs9gsKdCz",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1237527508372713472/photo/1",
            "indices" : [
              "183",
              "206"
            ],
            "url" : "https://t.co/NGs9gsKdCz",
            "media_url" : "http://pbs.twimg.com/media/ESyUbdCU0AEWbXc.jpg",
            "id_str" : "1237527196991803393",
            "id" : "1237527196991803393",
            "media_url_https" : "https://pbs.twimg.com/media/ESyUbdCU0AEWbXc.jpg",
            "sizes" : {
              "large" : {
                "w" : "1214",
                "h" : "1112",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "small" : {
                "w" : "680",
                "h" : "623",
                "resize" : "fit"
              },
              "medium" : {
                "w" : "1200",
                "h" : "1099",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/NGs9gsKdCz"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1237120593595686918"
          ],
          "editableUntil" : "2020-03-09T21:28:28.759Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/7wvPr9gR5r",
            "expanded_url" : "https://twitter.com/FryRsquared/status/1234491912775782400",
            "display_url" : "twitter.com/FryRsquared/st…",
            "indices" : [
              "131",
              "154"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "154"
      ],
      "favorite_count" : "2",
      "id_str" : "1237120593595686918",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1237120593595686918",
      "possibly_sensitive" : false,
      "created_at" : "Mon Mar 09 20:58:28 +0000 2020",
      "favorited" : false,
      "full_text" : "2018 simulation of the difference that everyone washing their hands 5-10 times a day might make to the spread of a flu-like virus. https://t.co/7wvPr9gR5r",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1237120074957443073"
          ],
          "editableUntil" : "2020-03-09T21:26:25.106Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/W1kvsnpe2M",
            "expanded_url" : "https://twitter.com/PracticalFrag/status/1237002645396586496",
            "display_url" : "twitter.com/PracticalFrag/…",
            "indices" : [
              "73",
              "96"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "96"
      ],
      "favorite_count" : "1",
      "id_str" : "1237120074957443073",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1237120074957443073",
      "possibly_sensitive" : false,
      "created_at" : "Mon Mar 09 20:56:25 +0000 2020",
      "favorited" : false,
      "full_text" : "Our friends at Diamond have been working on the SARS-CoV-2 main protease https://t.co/W1kvsnpe2M",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1234864995722285056"
          ],
          "editableUntil" : "2020-03-03T16:05:32.319Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Hannah Fry",
            "screen_name" : "FryRsquared",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "273375532",
            "id" : "273375532"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1234864995722285056",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1234864995722285056",
      "created_at" : "Tue Mar 03 15:35:32 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @FryRsquared: It's an extraordinary coincidence. But for me, the most powerful bit of the original tv prog was this: \n\nThis is our 2018…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1234864852381962241"
          ],
          "editableUntil" : "2020-03-03T16:04:58.144Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/jGEDRTm6WY",
            "expanded_url" : "https://www.macinchem.org/reviews/chemRPS/chemRPS.php",
            "display_url" : "macinchem.org/reviews/chemRP…",
            "indices" : [
              "54",
              "77"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "77"
      ],
      "favorite_count" : "0",
      "id_str" : "1234864852381962241",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1234864852381962241",
      "possibly_sensitive" : false,
      "created_at" : "Tue Mar 03 15:34:58 +0000 2020",
      "favorited" : false,
      "full_text" : "ChemRPS a Chemical Registration and Publishing System https://t.co/jGEDRTm6WY",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1232801881170288641"
          ],
          "editableUntil" : "2020-02-26T23:27:27.479Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "user_mentions" : [
          {
            "name" : "Practical_Fragments",
            "screen_name" : "PracticalFrag",
            "indices" : [
              "239",
              "253"
            ],
            "id_str" : "1094656135074697217",
            "id" : "1094656135074697217"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/7HGKICWAr5",
            "expanded_url" : "https://zoom.us/j/133802616",
            "display_url" : "zoom.us/j/133802616",
            "indices" : [
              "177",
              "200"
            ]
          },
          {
            "url" : "https://t.co/TVb52Uk1AZ",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/wiki/Round-1",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "215",
              "238"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1232801881170288641/photo/1",
            "indices" : [
              "254",
              "277"
            ],
            "url" : "https://t.co/7oSqxoxSfs",
            "media_url" : "http://pbs.twimg.com/media/ERvJ7nPXUAA3iBM.png",
            "id_str" : "1232800948998852608",
            "id" : "1232800948998852608",
            "media_url_https" : "https://pbs.twimg.com/media/ERvJ7nPXUAA3iBM.png",
            "sizes" : {
              "large" : {
                "w" : "584",
                "h" : "502",
                "resize" : "fit"
              },
              "small" : {
                "w" : "584",
                "h" : "502",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "584",
                "h" : "502",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/7oSqxoxSfs"
          }
        ],
        "hashtags" : [
          {
            "text" : "OpenScience",
            "indices" : [
              "49",
              "61"
            ]
          },
          {
            "text" : "drugdiscovery",
            "indices" : [
              "103",
              "117"
            ]
          },
          {
            "text" : "antibiotics",
            "indices" : [
              "140",
              "152"
            ]
          },
          {
            "text" : "FBDD",
            "indices" : [
              "201",
              "206"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "277"
      ],
      "favorite_count" : "7",
      "id_str" : "1232801881170288641",
      "truncated" : false,
      "retweet_count" : "6",
      "id" : "1232801881170288641",
      "possibly_sensitive" : false,
      "created_at" : "Wed Feb 26 22:57:27 +0000 2020",
      "favorited" : false,
      "full_text" : "Strategy meeting tomorrow (Feb 27th) at 1pm GMT. #OpenScience meeting to discuss recent fragment based #drugdiscovery results in Mur ligase #antibiotics project. Open to all at https://t.co/7HGKICWAr5 #FBDD Data at https://t.co/TVb52Uk1AZ @PracticalFrag https://t.co/7oSqxoxSfs",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ],
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1232801881170288641/photo/1",
            "indices" : [
              "254",
              "277"
            ],
            "url" : "https://t.co/7oSqxoxSfs",
            "media_url" : "http://pbs.twimg.com/media/ERvJ7nPXUAA3iBM.png",
            "id_str" : "1232800948998852608",
            "id" : "1232800948998852608",
            "media_url_https" : "https://pbs.twimg.com/media/ERvJ7nPXUAA3iBM.png",
            "sizes" : {
              "large" : {
                "w" : "584",
                "h" : "502",
                "resize" : "fit"
              },
              "small" : {
                "w" : "584",
                "h" : "502",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "584",
                "h" : "502",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/7oSqxoxSfs"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1222522933685424128"
          ],
          "editableUntil" : "2020-01-29T14:42:35.425Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/MSS0UJdq67",
            "expanded_url" : "https://twitter.com/wellcometrust/status/1222520269635387397",
            "display_url" : "twitter.com/wellcometrust/…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "0",
      "id_str" : "1222522933685424128",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1222522933685424128",
      "possibly_sensitive" : false,
      "created_at" : "Wed Jan 29 14:12:35 +0000 2020",
      "favorited" : false,
      "full_text" : "https://t.co/MSS0UJdq67",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1218180633480122368"
          ],
          "editableUntil" : "2020-01-17T15:07:50.380Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/R3xcslE48X",
            "expanded_url" : "https://www.theguardian.com/business/2020/jan/17/big-pharma-failing-to-invest-in-new-antibiotics-says-who",
            "display_url" : "theguardian.com/business/2020/…",
            "indices" : [
              "76",
              "99"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "99"
      ],
      "favorite_count" : "0",
      "id_str" : "1218180633480122368",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1218180633480122368",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jan 17 14:37:50 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: If the current system isn't delivering, try something new. https://t.co/R3xcslE48X",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1217895373387304963"
          ],
          "editableUntil" : "2020-01-16T20:14:19.074Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/VgW7xy1dhQ",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/3",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "201",
              "224"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "224"
      ],
      "favorite_count" : "3",
      "id_str" : "1217895373387304963",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1217895373387304963",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jan 16 19:44:19 +0000 2020",
      "favorited" : false,
      "full_text" : "Another addition to the news items. One in five deaths around the world is caused by sepsis ..... the report estimates 11 million people a year are dying from sepsis - more than are killed by cancer.\n\nhttps://t.co/VgW7xy1dhQ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1217839048494063617"
          ],
          "editableUntil" : "2020-01-16T16:30:30.173Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1217839048494063617",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1217839048494063617",
      "created_at" : "Thu Jan 16 16:00:30 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @macinchem: Interactive jupyter notebooks with structures on tooltips, it is clear that this is of considerable interest. Several people…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1217837241898237958"
          ],
          "editableUntil" : "2020-01-16T16:23:19.447Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "drugdiscovery",
            "indices" : [
              "75",
              "89"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "SCI – Where Science Meets Business💡",
            "screen_name" : "SCIupdate",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "85802831",
            "id" : "85802831"
          },
          {
            "name" : "Royal Society of Chemistry",
            "screen_name" : "RoySocChem",
            "indices" : [
              "27",
              "38"
            ],
            "id_str" : "309087942",
            "id" : "309087942"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "144"
      ],
      "favorite_count" : "0",
      "id_str" : "1217837241898237958",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1217837241898237958",
      "created_at" : "Thu Jan 16 15:53:19 +0000 2020",
      "favorited" : false,
      "full_text" : "RT @SCIupdate: 📢 SCI &amp; @RoySocChem Workshop on Computational Tools for #drugdiscovery \n\nRegister now to try out software packages with expe…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1216724357650767873"
          ],
          "editableUntil" : "2020-01-13T14:41:07.166Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/VgW7xy1dhQ",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/3",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "54",
              "77"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "77"
      ],
      "favorite_count" : "1",
      "id_str" : "1216724357650767873",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1216724357650767873",
      "possibly_sensitive" : false,
      "created_at" : "Mon Jan 13 14:11:07 +0000 2020",
      "favorited" : false,
      "full_text" : "Added items to the Recent Publications and News items https://t.co/VgW7xy1dhQ",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1210101371527204872"
          ],
          "editableUntil" : "2019-12-26T08:03:44.225Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/nKCjdlHlZr",
            "expanded_url" : "https://twitter.com/macinchem/status/1210100635825299456",
            "display_url" : "twitter.com/macinchem/stat…",
            "indices" : [
              "0",
              "23"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "23"
      ],
      "favorite_count" : "1",
      "id_str" : "1210101371527204872",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1210101371527204872",
      "possibly_sensitive" : false,
      "created_at" : "Thu Dec 26 07:33:44 +0000 2019",
      "favorited" : false,
      "full_text" : "https://t.co/nKCjdlHlZr",
      "lang" : "zxx"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1206840752279609344"
          ],
          "editableUntil" : "2019-12-17T08:07:12.017Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/3KuIfyJWwq",
            "expanded_url" : "https://www.nature.com/articles/s41557-019-0378-7",
            "display_url" : "nature.com/articles/s4155…",
            "indices" : [
              "137",
              "160"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "160"
      ],
      "favorite_count" : "4",
      "id_str" : "1206840752279609344",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1206840752279609344",
      "possibly_sensitive" : false,
      "created_at" : "Tue Dec 17 07:37:12 +0000 2019",
      "favorited" : false,
      "full_text" : "Repurposing human kinase inhibitors to create an antibiotic active against drug-resistant Staphylococcus aureus, persisters and biofilms https://t.co/3KuIfyJWwq",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1205111843313856512"
          ],
          "editableUntil" : "2019-12-12T13:37:07.998Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "111",
              "125"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1205111843313856512",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1205111843313856512",
      "created_at" : "Thu Dec 12 13:07:07 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Happy waters. Sad waters. Surprisingly relevant to how we might make a new antibiotic over at @OSantibiotics https://t.co/…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1204662572269604865"
          ],
          "editableUntil" : "2019-12-11T07:51:53.434Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibioticresistance",
            "indices" : [
              "68",
              "89"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1204662572269604865",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1204662572269604865",
      "created_at" : "Wed Dec 11 07:21:53 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @1Antruk: Britain is in the grip of a scarlet fever epidemic Has #antibioticresistance played a part in the rise of historic illnesses?…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1204662179384963072"
          ],
          "editableUntil" : "2019-12-11T07:50:19.763Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/1owuM7lno9",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/3#issuecomment-564412907",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "42",
              "65"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "65"
      ],
      "favorite_count" : "1",
      "id_str" : "1204662179384963072",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1204662179384963072",
      "possibly_sensitive" : false,
      "created_at" : "Wed Dec 11 07:20:19 +0000 2019",
      "favorited" : false,
      "full_text" : "Setting Our Sights on Infectious Diseases https://t.co/1owuM7lno9",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1204376888896081920"
          ],
          "editableUntil" : "2019-12-10T12:56:41.210Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1204376888896081920",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1204376888896081920",
      "created_at" : "Tue Dec 10 12:26:41 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Anyone with knowledge about water in enzyme-small molecule crystal structures, please chip in if time https://t.co/7lypiN2…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1204056390282686466"
          ],
          "editableUntil" : "2019-12-09T15:43:08.386Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/6ECPI941Db",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/15",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "62",
              "85"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "85"
      ],
      "favorite_count" : "9",
      "id_str" : "1204056390282686466",
      "truncated" : false,
      "retweet_count" : "3",
      "id" : "1204056390282686466",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 09 15:13:08 +0000 2019",
      "favorited" : false,
      "full_text" : "Interesting discussion on water molecules in X-ray structures https://t.co/6ECPI941Db",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1204056062984364032"
          ],
          "editableUntil" : "2019-12-09T15:41:50.352Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/R0GQxNJ25a",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "43",
              "66"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "1",
      "id_str" : "1204056062984364032",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1204056062984364032",
      "possibly_sensitive" : false,
      "created_at" : "Mon Dec 09 15:11:50 +0000 2019",
      "favorited" : false,
      "full_text" : "Recent publications and news items updated https://t.co/R0GQxNJ25a",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1202372223929065474"
          ],
          "editableUntil" : "2019-12-05T00:10:51.837Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1202372223929065474",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1202372223929065474",
      "created_at" : "Wed Dec 04 23:40:51 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: Look at the beautiful new fragments @Fahima_Chem and @dana_klug have made for the Open Source Antibiotics Mur Ligase proje…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1196368605149044736"
          ],
          "editableUntil" : "2019-11-18T10:34:37.578Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "OpenSourceAntibiotics",
            "indices" : [
              "79",
              "101"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/VgW7xy1dhQ",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/3",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "55",
              "78"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "101"
      ],
      "favorite_count" : "1",
      "id_str" : "1196368605149044736",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1196368605149044736",
      "possibly_sensitive" : false,
      "created_at" : "Mon Nov 18 10:04:37 +0000 2019",
      "favorited" : false,
      "full_text" : "The Recent Publications or news items has been updated https://t.co/VgW7xy1dhQ #OpenSourceAntibiotics",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1194320124863496192"
          ],
          "editableUntil" : "2019-11-12T18:54:41.819Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/bJ99gGeQzo",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/13",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "224",
              "247"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "247"
      ],
      "favorite_count" : "8",
      "id_str" : "1194320124863496192",
      "truncated" : false,
      "retweet_count" : "11",
      "id" : "1194320124863496192",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 12 18:24:41 +0000 2019",
      "favorited" : false,
      "full_text" : "Call for Open Source Antibiotics Fragment Contributions. What we need: Additional chemical matter for screening. The Diamond screening platform is high-throughput and we would ideally be able to take full advantage of this. https://t.co/bJ99gGeQzo",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1191769206003556352"
          ],
          "editableUntil" : "2019-11-05T17:58:15.369Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/uIhJTQA8td",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/12",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "224",
              "247"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "247"
      ],
      "favorite_count" : "2",
      "id_str" : "1191769206003556352",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1191769206003556352",
      "possibly_sensitive" : false,
      "created_at" : "Tue Nov 05 17:28:15 +0000 2019",
      "favorited" : false,
      "full_text" : "As discussed we are planning a shipment to Diamond at the end of November 2019. We at UCL already have plates in hand … are willing to coordinate a shipment to Diamond with our compounds and any made by other contributors.  https://t.co/uIhJTQA8td",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1191466507664068616"
          ],
          "editableUntil" : "2019-11-04T21:55:26.461Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "NGLY1",
            "indices" : [
              "20",
              "26"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Perlara",
            "screen_name" : "PerlaraPBC",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "2172622974",
            "id" : "2172622974"
          },
          {
            "name" : "DMM Journal",
            "screen_name" : "DMM_Journal",
            "indices" : [
              "66",
              "78"
            ],
            "id_str" : "76955139",
            "id" : "76955139"
          },
          {
            "name" : "Grace Science",
            "screen_name" : "gracescience",
            "indices" : [
              "118",
              "131"
            ],
            "id_str" : "2564054928",
            "id" : "2564054928"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1191466507664068616",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1191466507664068616",
      "created_at" : "Mon Nov 04 21:25:26 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @PerlaraPBC: Our #NGLY1 drug repurposing study is published in @DMM_Journal! \n\nWe acknowledge funding ($250K) from @gracescience that al…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1191295420309364736"
          ],
          "editableUntil" : "2019-11-04T10:35:36.057Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "AMR",
            "indices" : [
              "33",
              "37"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "UoBBio",
            "screen_name" : "UoBBio",
            "indices" : [
              "3",
              "10"
            ],
            "id_str" : "831530689203933184",
            "id" : "831530689203933184"
          },
          {
            "name" : "BSAC President",
            "screen_name" : "BSACPresident",
            "indices" : [
              "92",
              "106"
            ],
            "id_str" : "1008086733525790720",
            "id" : "1008086733525790720"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1191295420309364736",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1191295420309364736",
      "created_at" : "Mon Nov 04 10:05:36 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @UoBBio: Raising Awareness of #AMR in World Antibiotic Awareness Week. Public lecture by @BSACPresident Prof Philip Howard on 20th Nov @…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1191295318165512192"
          ],
          "editableUntil" : "2019-11-04T10:35:11.704Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "ruleoffive",
            "indices" : [
              "117",
              "128"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "RSC BMCS",
            "screen_name" : "RSC_BMCS",
            "indices" : [
              "3",
              "12"
            ],
            "id_str" : "760549489895698432",
            "id" : "760549489895698432"
          },
          {
            "name" : "RSC_CICAG",
            "screen_name" : "RSC_CICAG",
            "indices" : [
              "83",
              "93"
            ],
            "id_str" : "447019817",
            "id" : "447019817"
          },
          {
            "name" : "Sygnature Discovery",
            "screen_name" : "SygnatureDiscov",
            "indices" : [
              "97",
              "113"
            ],
            "id_str" : "2420800531",
            "id" : "2420800531"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1191295318165512192",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1191295318165512192",
      "created_at" : "Mon Nov 04 10:05:11 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @RSC_BMCS: We're excited that there is just over 2 weeks until our meeting with @RSC_CICAG at @SygnatureDiscov on #ruleoffive to get us…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1191295181116575744"
          ],
          "editableUntil" : "2019-11-04T10:34:39.029Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Wellcome",
            "screen_name" : "wellcometrust",
            "indices" : [
              "21",
              "35"
            ],
            "id_str" : "19837528",
            "id" : "19837528"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/mWm04kzFjg",
            "expanded_url" : "https://www.wellcome.ac.uk/reports/reframing-antimicrobial-resistance-antibiotic-resistance?utm_source=twitterShare",
            "display_url" : "wellcome.ac.uk/reports/refram…",
            "indices" : [
              "37",
              "60"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "60"
      ],
      "favorite_count" : "0",
      "id_str" : "1191295181116575744",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1191295181116575744",
      "possibly_sensitive" : false,
      "created_at" : "Mon Nov 04 10:04:39 +0000 2019",
      "favorited" : false,
      "full_text" : "Reframing Resistance @wellcometrust  https://t.co/mWm04kzFjg",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1189235486944038913"
          ],
          "editableUntil" : "2019-10-29T18:10:09.671Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/IIYXOmIWgn",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/wiki/Biological-Assays",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "72",
              "95"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "95"
      ],
      "favorite_count" : "0",
      "id_str" : "1189235486944038913",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1189235486944038913",
      "possibly_sensitive" : false,
      "created_at" : "Tue Oct 29 17:40:09 +0000 2019",
      "favorited" : false,
      "full_text" : "Details of the requirements for the fragment screen are now on the wiki https://t.co/IIYXOmIWgn",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1189235295285403651"
          ],
          "editableUntil" : "2019-10-29T18:09:23.976Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotic",
            "indices" : [
              "98",
              "109"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CDDEP",
            "screen_name" : "CDDEP",
            "indices" : [
              "3",
              "9"
            ],
            "id_str" : "146298160",
            "id" : "146298160"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1189235295285403651",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1189235295285403651",
      "created_at" : "Tue Oct 29 17:39:23 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @CDDEP: GARDP has announced its new strategy to develop five new treatments by 2025 to address #antibiotic resistant infections. Find ou…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1188069742520799233"
          ],
          "editableUntil" : "2019-10-26T12:57:54.542Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Mark Blaskovich",
            "screen_name" : "mark_blaskovich",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "747009875733942272",
            "id" : "747009875733942272"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1188069742520799233",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1188069742520799233",
      "created_at" : "Sat Oct 26 12:27:54 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @mark_blaskovich: Hi all, we're running an antibiotic discovery workshop on Thurs Nov 7 as part of the upcoming National AMR forum in Br…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1187619896307400704"
          ],
          "editableUntil" : "2019-10-25T07:10:22.847Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "The Times Of India",
            "screen_name" : "timesofindia",
            "indices" : [
              "94",
              "107"
            ],
            "id_str" : "134758540",
            "id" : "134758540"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/YbH0JDJdlO",
            "expanded_url" : "http://toi.in/TTs4va/a24gk",
            "display_url" : "toi.in/TTs4va/a24gk",
            "indices" : [
              "66",
              "89"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "107"
      ],
      "favorite_count" : "1",
      "id_str" : "1187619896307400704",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1187619896307400704",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 25 06:40:22 +0000 2019",
      "favorited" : false,
      "full_text" : "Delhi: Last-resort antibiotics fail; 10 die in 22 months in AIIMS https://t.co/YbH0JDJdlO via @timesofindia",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1185799932042776577"
          ],
          "editableUntil" : "2019-10-20T06:38:29.553Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "opensource",
            "indices" : [
              "51",
              "62"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/BmUk19lDjL",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/4",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "63",
              "86"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "86"
      ],
      "favorite_count" : "3",
      "id_str" : "1185799932042776577",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1185799932042776577",
      "possibly_sensitive" : false,
      "created_at" : "Sun Oct 20 06:08:29 +0000 2019",
      "favorited" : false,
      "full_text" : "A handy guide to financial support for open source #opensource https://t.co/BmUk19lDjL",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1185127097351786496"
          ],
          "editableUntil" : "2019-10-18T10:04:53.262Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/NAr1fr0a5f",
            "expanded_url" : "https://imgs.xkcd.com/comics/standards.png",
            "display_url" : "imgs.xkcd.com/comics/standar…",
            "indices" : [
              "8",
              "31"
            ]
          },
          {
            "url" : "https://t.co/FEbY5fhzd6",
            "expanded_url" : "https://xkcd.com/927/",
            "display_url" : "xkcd.com/927/",
            "indices" : [
              "32",
              "55"
            ]
          },
          {
            "url" : "https://t.co/GgiwVx3vCp",
            "expanded_url" : "https://twitter.com/MatToddChem/status/1184757073311096832",
            "display_url" : "twitter.com/MatToddChem/st…",
            "indices" : [
              "56",
              "79"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "79"
      ],
      "favorite_count" : "0",
      "id_str" : "1185127097351786496",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1185127097351786496",
      "possibly_sensitive" : false,
      "created_at" : "Fri Oct 18 09:34:53 +0000 2019",
      "favorited" : false,
      "full_text" : "Perhaps https://t.co/NAr1fr0a5f https://t.co/FEbY5fhzd6 https://t.co/GgiwVx3vCp",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1185124034788429824"
          ],
          "editableUntil" : "2019-10-18T09:52:43.090Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "BeilsteinOS2019",
            "indices" : [
              "56",
              "72"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1185124034788429824",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1185124034788429824",
      "created_at" : "Fri Oct 18 09:22:43 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @MatToddChem: I liked the quote someone mentioned at #BeilsteinOS2019 \"The nice thing about standards is that there are so many to choos…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1184755269915545600"
          ],
          "editableUntil" : "2019-10-17T09:27:22.693Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Peter Kenny 🇹🇹🇬🇧🇧🇷🇺🇦🌻🇪🇺",
            "screen_name" : "pwk2013",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "1063818618",
            "id" : "1063818618"
          },
          {
            "name" : "ChemMedChem",
            "screen_name" : "ChemMedChem",
            "indices" : [
              "13",
              "25"
            ],
            "id_str" : "1725410090",
            "id" : "1725410090"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "26",
              "38"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "UCL",
            "screen_name" : "ucl",
            "indices" : [
              "39",
              "43"
            ],
            "id_str" : "322601789",
            "id" : "322601789"
          },
          {
            "name" : "Open Source Malaria",
            "screen_name" : "O_S_M",
            "indices" : [
              "44",
              "50"
            ],
            "id_str" : "342023138",
            "id" : "342023138"
          },
          {
            "name" : "OSPF",
            "screen_name" : "OSPinfo",
            "indices" : [
              "51",
              "59"
            ],
            "id_str" : "1250111220029558785",
            "id" : "1250111220029558785"
          },
          {
            "name" : "Open Source Mycetoma",
            "screen_name" : "MycetOS",
            "indices" : [
              "60",
              "68"
            ],
            "id_str" : "890399794878849024",
            "id" : "890399794878849024"
          },
          {
            "name" : "OSantibiotics",
            "screen_name" : "OSantibiotics",
            "indices" : [
              "69",
              "83"
            ],
            "id_str" : "1111629854716428290",
            "id" : "1111629854716428290"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1184755269915545600",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1184755269915545600",
      "created_at" : "Thu Oct 17 08:57:22 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @pwk2013: @ChemMedChem @MatToddChem @ucl @O_S_M @OSPInfo @MycetOS @OSantibiotics Makes a lot of sense for charity/taxpayer funded#DrugDi…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1184445449475891200"
          ],
          "editableUntil" : "2019-10-16T12:56:15.744Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://about.twitter.com/products/tweetdeck\" rel=\"nofollow\">TweetDeck</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "drugdiscovery",
            "indices" : [
              "81",
              "95"
            ]
          },
          {
            "text" : "openscience",
            "indices" : [
              "130",
              "142"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "ChemMedChem",
            "screen_name" : "ChemMedChem",
            "indices" : [
              "3",
              "15"
            ],
            "id_str" : "1725410090",
            "id" : "1725410090"
          },
          {
            "name" : "Matthew Todd",
            "screen_name" : "MatToddChem",
            "indices" : [
              "27",
              "39"
            ],
            "id_str" : "21448858",
            "id" : "21448858"
          },
          {
            "name" : "UCL",
            "screen_name" : "ucl",
            "indices" : [
              "40",
              "44"
            ],
            "id_str" : "322601789",
            "id" : "322601789"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "143"
      ],
      "favorite_count" : "0",
      "id_str" : "1184445449475891200",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1184445449475891200",
      "created_at" : "Wed Oct 16 12:26:15 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @ChemMedChem: Mat Todd (@mattoddchem @ucl) shares his thoughts on open source #drugdiscovery &amp; \"Six Laws\" that could guide #openscience…",
      "lang" : "en",
      "contributors" : [
        "21448858"
      ]
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1183732849955999745"
          ],
          "editableUntil" : "2019-10-14T13:44:38.779Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/VgW7xy1dhQ",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/3",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "67",
              "90"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "114"
      ],
      "favorite_count" : "1",
      "id_str" : "1183732849955999745",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1183732849955999745",
      "possibly_sensitive" : false,
      "created_at" : "Mon Oct 14 13:14:38 +0000 2019",
      "favorited" : false,
      "full_text" : "Recent Publications or news items on Antibiotics has been updated. https://t.co/VgW7xy1dhQ feel free to contribute",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1183732472124706816"
          ],
          "editableUntil" : "2019-10-14T13:43:08.697Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "AntibioticResearchUK",
            "screen_name" : "1Antruk",
            "indices" : [
              "3",
              "11"
            ],
            "id_str" : "2758766167",
            "id" : "2758766167"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "139"
      ],
      "favorite_count" : "0",
      "id_str" : "1183732472124706816",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1183732472124706816",
      "created_at" : "Mon Oct 14 13:13:08 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @1Antruk: “There has been a worrying lack of progress on some of the critical recommendations from the original document, including the…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1170632841996251136"
          ],
          "editableUntil" : "2019-09-08T10:09:53.495Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/gNOzUGhlls",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/wiki",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "62",
              "85"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1170632841996251136",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1170632841996251136",
      "possibly_sensitive" : false,
      "created_at" : "Sun Sep 08 09:39:53 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @macinchem: Starting something similar in Antibiotics area https://t.co/gNOzUGhlls early days but since it is a fragment based project c…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1169139505208709129"
          ],
          "editableUntil" : "2019-09-04T07:15:54.260Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/XUvvXsQtqF",
            "expanded_url" : "https://doi.org/10.1021/acsinfecdis.9b00262",
            "display_url" : "doi.org/10.1021/acsinf…",
            "indices" : [
              "43",
              "66"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "66"
      ],
      "favorite_count" : "1",
      "id_str" : "1169139505208709129",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1169139505208709129",
      "possibly_sensitive" : false,
      "created_at" : "Wed Sep 04 06:45:54 +0000 2019",
      "favorited" : false,
      "full_text" : "Call for Papers: Antibiotics Special Issue https://t.co/XUvvXsQtqF",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1167704017356632065"
          ],
          "editableUntil" : "2019-08-31T08:11:47.286Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Claire Brandish",
            "screen_name" : "ClaireBrandish1",
            "indices" : [
              "3",
              "19"
            ],
            "id_str" : "3872653996",
            "id" : "3872653996"
          },
          {
            "name" : "Tom Spencer",
            "screen_name" : "TomBSpencer",
            "indices" : [
              "110",
              "122"
            ],
            "id_str" : "523173592",
            "id" : "523173592"
          },
          {
            "name" : "Diane Ashiru, PhD",
            "screen_name" : "DrDianeAshiru",
            "indices" : [
              "123",
              "137"
            ],
            "id_str" : "1951791067",
            "id" : "1951791067"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1167704017356632065",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1167704017356632065",
      "created_at" : "Sat Aug 31 07:41:47 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @ClaireBrandish1: Yay! We reached our target! Enormously grateful to everyone who donated, shared, tweeted @TomBSpencer @DrDianeAshiru @…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1167703911203069952"
          ],
          "editableUntil" : "2019-08-31T08:11:21.977Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/wlaCH4pu6F",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/wiki/MurD-and-MurE-fragment-screen",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "71",
              "94"
            ]
          },
          {
            "url" : "https://t.co/1XGnFMox7T",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/6",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "109",
              "132"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "132"
      ],
      "favorite_count" : "1",
      "id_str" : "1167703911203069952",
      "truncated" : false,
      "retweet_count" : "2",
      "id" : "1167703911203069952",
      "possibly_sensitive" : false,
      "created_at" : "Sat Aug 31 07:41:21 +0000 2019",
      "favorited" : false,
      "full_text" : "Fragment screen directed at ATP pocket for MurD and MurE first results https://t.co/wlaCH4pu6F discussion on https://t.co/1XGnFMox7T",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1158444107007692800"
          ],
          "editableUntil" : "2019-08-05T18:56:12.618Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "Chris Swain",
            "screen_name" : "macinchem",
            "indices" : [
              "3",
              "13"
            ],
            "id_str" : "418583301",
            "id" : "418583301"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1158444107007692800",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1158444107007692800",
      "created_at" : "Mon Aug 05 18:26:12 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @macinchem: Still a few places left for the AI in Chemistry Meeting in Cambridge 2nd to 3rd September 2019.  Shaping up to be a fantasti…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1157177123246944256"
          ],
          "editableUntil" : "2019-08-02T07:01:40.150Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CO-ADD Antibiotics",
            "screen_name" : "COADD_news",
            "indices" : [
              "148",
              "159"
            ],
            "id_str" : "3045189728",
            "id" : "3045189728"
          }
        ],
        "urls" : [
          {
            "url" : "https://t.co/vMv1iL3g8K",
            "expanded_url" : "https://db.co-add.org",
            "display_url" : "db.co-add.org",
            "indices" : [
              "124",
              "147"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "159"
      ],
      "favorite_count" : "7",
      "id_str" : "1157177123246944256",
      "truncated" : false,
      "retweet_count" : "4",
      "id" : "1157177123246944256",
      "possibly_sensitive" : false,
      "created_at" : "Fri Aug 02 06:31:40 +0000 2019",
      "favorited" : false,
      "full_text" : "CO-ADD is proud to announce the public release of the first set of its antimicrobial screening data, on its public website. https://t.co/vMv1iL3g8K @COADD_news",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1157176649974243328"
          ],
          "editableUntil" : "2019-08-02T06:59:47.313Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [
          {
            "text" : "antibiotics",
            "indices" : [
              "49",
              "61"
            ]
          },
          {
            "text" : "AMR",
            "indices" : [
              "133",
              "137"
            ]
          }
        ],
        "symbols" : [ ],
        "user_mentions" : [
          {
            "name" : "CO-ADD Antibiotics",
            "screen_name" : "COADD_news",
            "indices" : [
              "3",
              "14"
            ],
            "id_str" : "3045189728",
            "id" : "3045189728"
          },
          {
            "name" : "Wellcome Sanger Institute",
            "screen_name" : "sangerinstitute",
            "indices" : [
              "116",
              "132"
            ],
            "id_str" : "34222024",
            "id" : "34222024"
          }
        ],
        "urls" : [ ]
      },
      "display_text_range" : [
        "0",
        "140"
      ],
      "favorite_count" : "0",
      "id_str" : "1157176649974243328",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1157176649974243328",
      "created_at" : "Fri Aug 02 06:29:47 +0000 2019",
      "favorited" : false,
      "full_text" : "RT @COADD_news: Superbugs resistant to emergency #antibiotics are spreading in hospitals, a Europe-wide study shows @sangerinstitute #AMR #…",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1155497087624237057"
          ],
          "editableUntil" : "2019-07-28T15:45:48.444Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/B0seahwAB7",
            "expanded_url" : "https://github.com/opensourceantibiotics/murligase/issues/3",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "65",
              "88"
            ]
          }
        ],
        "symbols" : [ ],
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1155497087624237057/photo/1",
            "indices" : [
              "89",
              "112"
            ],
            "url" : "https://t.co/5YT3BN1ijw",
            "media_url" : "http://pbs.twimg.com/media/EAkmedAXsAI9ioP.jpg",
            "id_str" : "1155497084021354498",
            "id" : "1155497084021354498",
            "media_url_https" : "https://pbs.twimg.com/media/EAkmedAXsAI9ioP.jpg",
            "sizes" : {
              "large" : {
                "w" : "1527",
                "h" : "395",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "176",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "310",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/5YT3BN1ijw"
          }
        ],
        "hashtags" : [ ]
      },
      "display_text_range" : [
        "0",
        "112"
      ],
      "favorite_count" : "4",
      "id_str" : "1155497087624237057",
      "truncated" : false,
      "retweet_count" : "5",
      "id" : "1155497087624237057",
      "possibly_sensitive" : false,
      "created_at" : "Sun Jul 28 15:15:48 +0000 2019",
      "favorited" : false,
      "full_text" : "Some ideas on following up the cluster 6 fragment hits for Mur E https://t.co/B0seahwAB7 https://t.co/5YT3BN1ijw",
      "lang" : "en",
      "extended_entities" : {
        "media" : [
          {
            "expanded_url" : "https://twitter.com/OSantibiotics/status/1155497087624237057/photo/1",
            "indices" : [
              "89",
              "112"
            ],
            "url" : "https://t.co/5YT3BN1ijw",
            "media_url" : "http://pbs.twimg.com/media/EAkmedAXsAI9ioP.jpg",
            "id_str" : "1155497084021354498",
            "id" : "1155497084021354498",
            "media_url_https" : "https://pbs.twimg.com/media/EAkmedAXsAI9ioP.jpg",
            "sizes" : {
              "large" : {
                "w" : "1527",
                "h" : "395",
                "resize" : "fit"
              },
              "small" : {
                "w" : "680",
                "h" : "176",
                "resize" : "fit"
              },
              "thumb" : {
                "w" : "150",
                "h" : "150",
                "resize" : "crop"
              },
              "medium" : {
                "w" : "1200",
                "h" : "310",
                "resize" : "fit"
              }
            },
            "type" : "photo",
            "display_url" : "pic.twitter.com/5YT3BN1ijw"
          }
        ]
      }
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1154696498480893952"
          ],
          "editableUntil" : "2019-07-26T10:44:33.118Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/p1kaYBnr5Y",
            "expanded_url" : "https://github.com/opensourceantibiotics/GeneralTopics/issues/3#issuecomment-515395268",
            "display_url" : "github.com/opensourceanti…",
            "indices" : [
              "74",
              "97"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "97"
      ],
      "favorite_count" : "2",
      "id_str" : "1154696498480893952",
      "truncated" : false,
      "retweet_count" : "1",
      "id" : "1154696498480893952",
      "possibly_sensitive" : false,
      "created_at" : "Fri Jul 26 10:14:33 +0000 2019",
      "favorited" : false,
      "full_text" : "Five-Year Analysis Shows Continued Deficiencies in Antibiotic Development https://t.co/p1kaYBnr5Y",
      "lang" : "en"
    }
  },
  {
    "tweet" : {
      "edit_info" : {
        "initial" : {
          "editTweetIds" : [
            "1151818481815425025"
          ],
          "editableUntil" : "2019-07-18T12:08:20.474Z",
          "editsRemaining" : "5",
          "isEditEligible" : true
        }
      },
      "retweeted" : false,
      "source" : "<a href=\"https://tapbots.com/software/tweetbot/mac\" rel=\"nofollow\">Tweetbot for Mac</a>",
      "entities" : {
        "hashtags" : [ ],
        "symbols" : [ ],
        "user_mentions" : [ ],
        "urls" : [
          {
            "url" : "https://t.co/ajS3Kq4QKK",
            "expanded_url" : "https://www.rsc.org/Membership/Networking/InterestGroups/CICAG/Newsletters.asp",
            "display_url" : "rsc.org/Membership/Net…",
            "indices" : [
              "119",
              "142"
            ]
          }
        ]
      },
      "display_text_range" : [
        "0",
        "142"
      ],
      "favorite_count" : "0",
      "id_str" : "1151818481815425025",
      "truncated" : false,
      "retweet_count" : "0",
      "id" : "1151818481815425025",
      "possibly_sensitive" : false,
      "created_at" : "Thu Jul 18 11:38:20 +0000 2019",
      "favorited" : false,
      "full_text" : "The Summer 2019 edition of the CICAG Newsletter has been published and can be downloaded from the Newsletters webpage. https://t.co/ajS3Kq4QKK",
      "lang" : "en"
    }
  }
]