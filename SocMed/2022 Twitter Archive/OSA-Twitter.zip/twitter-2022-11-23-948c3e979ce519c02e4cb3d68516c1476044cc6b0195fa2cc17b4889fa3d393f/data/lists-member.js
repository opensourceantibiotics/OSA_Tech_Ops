window.YTD.lists_member.part0 = [
  {
    "userListInfo" : {
      "url" : "https://twitter.com/cedricgraebin/lists/1448392715096543241"
    }
  },
  {
    "userListInfo" : {
      "url" : "https://twitter.com/cedricgraebin/lists/science-ma-non-troppo"
    }
  }
]