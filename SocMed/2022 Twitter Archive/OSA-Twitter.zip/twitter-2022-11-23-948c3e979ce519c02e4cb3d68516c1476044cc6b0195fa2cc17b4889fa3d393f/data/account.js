window.YTD.account.part0 = [
  {
    "account" : {
      "email" : "chrisjswain007@gmail.com",
      "createdVia" : "oauth:268278",
      "username" : "OSantibiotics",
      "accountId" : "1111629854716428290",
      "createdAt" : "2019-03-29T14:03:05.236Z",
      "accountDisplayName" : "OSantibiotics"
    }
  }
]