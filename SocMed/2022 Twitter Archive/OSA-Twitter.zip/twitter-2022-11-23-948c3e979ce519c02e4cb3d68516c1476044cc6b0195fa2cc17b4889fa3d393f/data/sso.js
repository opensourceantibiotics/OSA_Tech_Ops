window.YTD.sso.part0 = [
  {
    "singleSignOnMetaValues" : {
      "ssoId" : "107813168274506102162",
      "ssoEmail" : "chrisjswain007@gmail.com",
      "associationMethodType" : "Login",
      "createdAt" : "2022-08-22T13:05:30.417Z"
    }
  }
]