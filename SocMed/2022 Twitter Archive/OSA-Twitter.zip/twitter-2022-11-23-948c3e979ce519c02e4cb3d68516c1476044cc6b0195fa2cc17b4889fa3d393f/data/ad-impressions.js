window.YTD.ad_impressions.part0 = [
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1567520641322205188",
                "tweetText" : "RT @BloombergUK: These are the world's most (and least) powerful passports.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Bloomberg",
                "screenName" : "@business"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCNews"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nytimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TIME"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@guardian"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Reuters"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "AIQ_276401_0_1"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Bloomberg: Business News Daily IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Bloomberg: Finance Market News ANDROID All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "AIQ_271882_0_1 - Active Subs"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-11-18 16:47:12"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Canal & River Trust",
                "screenName" : "@CanalRiverTrust"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Dogs"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "England"
                }
              ],
              "impressionTime" : "2022-11-18 16:47:10"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "bioMérieux",
                "screenName" : "@biomerieux"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AMRAlliance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EUjamrai"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-11-19 11:00:53"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1567522909194960904",
                "tweetText" : "RT @BloombergUK: Never had Covid? You could hold the key to beating the virus — and scientists want to study you.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Bloomberg",
                "screenName" : "@business"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Business & finance"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Government/Education"
                },
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Personal finance"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Space and astronomy"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Science news"
                },
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Technology"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "AIQ_276401_0_1"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Bloomberg: Business News Daily IOS All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "AIQ_271882_0_1"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Bloomberg: Finance Market News ANDROID All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "AIQ_271882_0_1 - Active Subs"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                }
              ],
              "impressionTime" : "2022-11-19 11:00:54"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1579201784538484736",
                "tweetText" : "Discover our indulgent cream formulated to provide all-night hydration, while protecting skin against the ageing effects of inflammation.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Cellular Goods",
                "screenName" : "@CellularGoods"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Gender",
                  "targetingValue" : "Women"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 54"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                }
              ],
              "impressionTime" : "2022-11-19 10:56:46"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "BMJMedicine",
                "screenName" : "@BMJMedicine"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@NEJM"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheLancet"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@bmj_latest"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@RoySocMed"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                }
              ],
              "impressionTime" : "2022-11-19 10:56:07"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1567520640877604865",
                "tweetText" : "RT @BloombergUK: Never had Covid? You could hold the key to beating the virus — and scientists want to study you.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Bloomberg",
                "screenName" : "@business"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@BBCNews"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@nytimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TIME"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FT"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@FinancialTimes"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@guardian"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@WSJ"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@TheEconomist"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@Reuters"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "AIQ_276401_0_1"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Bloomberg: Business News Daily IOS All"
                },
                {
                  "targetingType" : "App Activity",
                  "targetingValue" : "Purchase Bloomberg: Finance Market News ANDROID All"
                },
                {
                  "targetingType" : "List",
                  "targetingValue" : "AIQ_271882_0_1 - Active Subs"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                }
              ],
              "impressionTime" : "2022-11-19 10:56:08"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1575416682889224196",
                "tweetText" : "Questions about cancer and relationships? Join the Online Community today and find support from others who've been there too. 24/7 anonymous support is a click away.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Macmillan Cancer Support",
                "screenName" : "@macmillancancer"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@CR_UK"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "18 and up"
                }
              ],
              "impressionTime" : "2022-11-19 10:56:30"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1589518477278449664",
                "tweetText" : "James Fridman, the photoshop master, took some people's requests for edits, and the results made people regret asking him.😱",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "BetterWomanly",
                "screenName" : "@BWomanly"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-11-19 10:56:57"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1587488602799366145",
                "tweetText" : "Looking for your dream sofa?\n\nGet 50% off selected sofas and quick delivery on all orders when you shop online\nhttps://t.co/cDfGYLNrKQ",
                "urls" : [
                  "https://t.co/cDfGYLNrKQ"
                ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Sofahhh",
                "screenName" : "@SofahUK"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Keywords",
                  "targetingValue" : "made.com"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-11-19 09:23:47"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1566792027412566016",
                "tweetText" : "Introducing the new Snapdragon® 8 Gen 1 mobile processor. At the centre of extraordinary gaming with sharp graphics, fast rendering and long battery life.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Snapdragon UK",
                "screenName" : "@Snapdragon_UK"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Interests",
                  "targetingValue" : "Computer gaming"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                }
              ],
              "impressionTime" : "2022-11-19 09:21:49"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1583119859755409408",
                "tweetText" : "There’s no time like the present — especially with deals like these.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "Windows UK",
                "screenName" : "@WindowsUK"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Conversation topics",
                  "targetingValue" : "Tech news"
                },
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 to 49"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                }
              ],
              "impressionTime" : "2022-11-19 09:23:00"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "bioMérieux",
                "screenName" : "@biomerieux"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@AMRAlliance"
                },
                {
                  "targetingType" : "Follower look-alikes",
                  "targetingValue" : "@EUjamrai"
                },
                {
                  "targetingType" : "Languages",
                  "targetingValue" : "English"
                }
              ],
              "impressionTime" : "2022-11-19 09:21:48"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1574404936020131840",
                "tweetText" : "Here are some shoes designs that have just gone wrong. Fashion can be stylish and innovative, but nobody can deny that it often crosses over into the world of funny garments at times.",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "advertiserInfo" : {
                "advertiserName" : "WithMyLadies",
                "screenName" : "@WithMyLadies1"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                }
              ],
              "impressionTime" : "2022-11-19 09:23:56"
            }
          ]
        }
      }
    }
  },
  {
    "ad" : {
      "adsUserData" : {
        "adImpressions" : {
          "impressions" : [
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "TimelineHome",
              "promotedTweetInfo" : {
                "tweetId" : "1594571313313714176",
                "tweetText" : "A train journey that turns into something pretty special…\n\n#ImagineAWin #TNLChristmas",
                "urls" : [ ],
                "mediaUrls" : [ ]
              },
              "promotedTrendInfo" : {
                "trendId" : "92103",
                "name" : "#TNLUK20221121",
                "description" : ""
              },
              "advertiserInfo" : {
                "advertiserName" : "The National Lottery",
                "screenName" : "@TNLUK"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                }
              ],
              "impressionTime" : "2022-11-21 21:46:18"
            },
            {
              "deviceInfo" : {
                "osType" : "Desktop"
              },
              "displayLocation" : "WtfSidebar",
              "advertiserInfo" : {
                "advertiserName" : "Kitforte",
                "screenName" : "@kitforte_media"
              },
              "matchedTargetingCriteria" : [
                {
                  "targetingType" : "Age",
                  "targetingValue" : "25 and up"
                },
                {
                  "targetingType" : "Platforms",
                  "targetingValue" : "Desktop"
                },
                {
                  "targetingType" : "Locations",
                  "targetingValue" : "United Kingdom"
                }
              ],
              "impressionTime" : "2022-11-21 21:46:17"
            }
          ]
        }
      }
    }
  }
]