window.YTD.like.part0 = [
  {
    "like" : {
      "tweetId" : "1595165482034036736",
      "fullText" : "🤯Because of Excel, a THIRD of all genetics papers published in top journals have errors, as many genes have names like SEPT2 (the official name of Septin 2), which Excel automatically makes dates. \n\nThe issue was found in 2016, but still hasn’t improved! https://t.co/9E46yk82cd https://t.co/ixgppwcCoM",
      "expandedUrl" : "https://twitter.com/i/web/status/1595165482034036736"
    }
  },
  {
    "like" : {
      "tweetId" : "1582990182273671168",
      "fullText" : "Follow today's #AntibioticResearchUK conference @1Antruk @arlenebrailey @RyanPharmilton @MatToddChem @School_Pharmacy @SheffChildrens @NDMOxford @iecducl @Leic_hospital https://t.co/ZHwhODCvnf",
      "expandedUrl" : "https://twitter.com/i/web/status/1582990182273671168"
    }
  },
  {
    "like" : {
      "tweetId" : "1580225405218615304",
      "fullText" : "Ordering from @EnamineLtd is fun (as we're doing today in @OSantibiotics https://t.co/J2UoBG4vsa) but also gratifying since we're helping support excellent scientists in #Kyiv who are bravely working through dreadful Russian bombardment of their city @thesgconline https://t.co/JztJIrMiKy",
      "expandedUrl" : "https://twitter.com/i/web/status/1580225405218615304"
    }
  },
  {
    "like" : {
      "tweetId" : "1524026383806181376",
      "fullText" : "@OSantibiotics @SSGCID We figured Open Meetings drive Open Science, so we went ahead and added all your meetings from YouTube to our free https://t.co/PqqrsXAe8B service, which makes them even more accessible, with video-synced transcript + other goodies.\n\nThis one is up at https://t.co/QeQQcW4131",
      "expandedUrl" : "https://twitter.com/i/web/status/1524026383806181376"
    }
  },
  {
    "like" : {
      "tweetId" : "1518993268452864000",
      "fullText" : "Super interesting💥💥\nWe have many reviews about new antibiotics in the pipeline\nA 🆕Review #AAC for antibiotics \"candidates\" with Gram-negative activity that have fallen out of the clinical pipeline over the past decade \"leaks\" #IDTwitter #MedEd #TwitteRx\nhttps://t.co/q4xClW5U4y https://t.co/LfYBRLWhoM",
      "expandedUrl" : "https://twitter.com/i/web/status/1518993268452864000"
    }
  },
  {
    "like" : {
      "tweetId" : "1511705445139894276",
      "fullText" : "@OSantibiotics meeting today at 4 pm UK time https://t.co/38UHP8hs5s @MatToddChem @LoriFerrins @danielgedder @macinchem @mfernflower @emeryfs",
      "expandedUrl" : "https://twitter.com/i/web/status/1511705445139894276"
    }
  },
  {
    "like" : {
      "tweetId" : "1492098701950652423",
      "fullText" : "How a subscription payment model could fight antibiotic-resistant superbugs https://t.co/voqLJXQbT1 @BCG @wellcometrust @novonordiskfond https://t.co/NgGtA7ljmZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1492098701950652423"
    }
  },
  {
    "like" : {
      "tweetId" : "1488879819022606342",
      "fullText" : "If you are proposing combinations of old antibiotics or repurposing drugs to combine with an antibiotic - please listen to the recording of 'Evidence for the use of old and new antibiotics' and possibilities from a clinician's perspective @SMHopkins  #ACC2022",
      "expandedUrl" : "https://twitter.com/i/web/status/1488879819022606342"
    }
  },
  {
    "like" : {
      "tweetId" : "1483437229603274756",
      "fullText" : "I've just sent supply of the compounds below to Warwick for our @OSantibiotics Mur ligase project! Next step: Attemt cocrystallization with MurD. Updates here: https://t.co/70wYZvLsqo\n#OpenScience #AMR https://t.co/KQ5b8GaPvl",
      "expandedUrl" : "https://twitter.com/i/web/status/1483437229603274756"
    }
  },
  {
    "like" : {
      "tweetId" : "1467490027810836492",
      "fullText" : "@TomChivers Very interesting article. Another approach some people are taking is developing open source drugs, like @covid_moonshot and @OSantibiotics. Any thoughts on the idea of patent-free drug discovery?",
      "expandedUrl" : "https://twitter.com/i/web/status/1467490027810836492"
    }
  },
  {
    "like" : {
      "tweetId" : "1465807771786436613",
      "fullText" : "@OSantibiotics @dana_klug @LoriFerrins @Northeastern I will be back to the discussions...after a long break...",
      "expandedUrl" : "https://twitter.com/i/web/status/1465807771786436613"
    }
  },
  {
    "like" : {
      "tweetId" : "1458033369736953862",
      "fullText" : "Delighted that @O_S_M's latest paper is now out in @ACSBioMed https://t.co/jliTfFP49V An #openscience competition to compare methods for the #AI #MachineLearning discovery of new molecules for #malaria that were then synthesised and evaluated consistently. https://t.co/t8jD8Hoc3W",
      "expandedUrl" : "https://twitter.com/i/web/status/1458033369736953862"
    }
  },
  {
    "like" : {
      "tweetId" : "1450399038633881604",
      "fullText" : "Mencionamos também iniciativas como @O_S_M, @MycetOS, @OSantibiotics e outras que estão incorporando os princípios do Software Livre no desenvolvimento de fármacos! Esperamos bons frutos destes grupos no futuro.",
      "expandedUrl" : "https://twitter.com/i/web/status/1450399038633881604"
    }
  },
  {
    "like" : {
      "tweetId" : "1409508530416021506",
      "fullText" : "Fragment screening against a quartet of M. tuberculosis proteins finds multiple starting points: 27 bound X-ray structures could initiate lead development against a growing threat  \nhttps://t.co/7mnYaE08kZ\n@OSantibiotics @CamBiochem @CSB_Journal",
      "expandedUrl" : "https://twitter.com/i/web/status/1409508530416021506"
    }
  },
  {
    "like" : {
      "tweetId" : "1403376021823500288",
      "fullText" : "There is no market for new #antibiotics: this allows an open.... Klug DM et al., published by @WellcomeOpenRes, https://t.co/cjXzKQpx11",
      "expandedUrl" : "https://twitter.com/i/web/status/1403376021823500288"
    }
  },
  {
    "like" : {
      "tweetId" : "1396796820114878467",
      "fullText" : "Likewise #AMR https://t.co/KZ0Fy0QpQC",
      "expandedUrl" : "https://twitter.com/i/web/status/1396796820114878467"
    }
  },
  {
    "like" : {
      "tweetId" : "1390630429779234818",
      "fullText" : "@OSantibiotics @mfernflower @GiadasabatinoC @macinchem @edwintse_ @dana_klug @emeryfs @MatToddChem The compounds from @dana_klug have been received and sent to DNDi for testing!",
      "expandedUrl" : "https://twitter.com/i/web/status/1390630429779234818"
    }
  },
  {
    "like" : {
      "tweetId" : "1390283753201836037",
      "fullText" : "Funding for novel antibiotic development. @RSC_BMCS  https://t.co/sEpvKzplus",
      "expandedUrl" : "https://twitter.com/i/web/status/1390283753201836037"
    }
  },
  {
    "like" : {
      "tweetId" : "1388455515295043586",
      "fullText" : "‘We need to develop new antibiotics’ - The silent pandemic of antimicrobial resistance. This is why the UK supports ⁦@gardp_amr⁩  https://t.co/lR7GzxX9gm https://t.co/IJtZgkHntV",
      "expandedUrl" : "https://twitter.com/i/web/status/1388455515295043586"
    }
  },
  {
    "like" : {
      "tweetId" : "1376481357543641089",
      "fullText" : "A macro to automatically import Open Source Antibiotics @OSantibiotics Data into DataWarrior https://t.co/hNs4E04xY6 #cheminformatics",
      "expandedUrl" : "https://twitter.com/i/web/status/1376481357543641089"
    }
  },
  {
    "like" : {
      "tweetId" : "1372901048013193223",
      "fullText" : "Our paper highlighted on the front cover of @ChemMedChem March issue. Congrats to @danielgedder and thanks to all collaborators @WWU_Muenster @UAntwerpen and @UW in the search of candidates for #trypanosomiases @DNDi_Portugues @DNDi @OSantibiotics @fcfrp_usp https://t.co/JBsFJac47D",
      "expandedUrl" : "https://twitter.com/i/web/status/1372901048013193223"
    }
  },
  {
    "like" : {
      "tweetId" : "1372786197433438214",
      "fullText" : "@OSantibiotics @LoriFerrins @MrBenGP @dana_klug Looks super fun and interesting! ❤️",
      "expandedUrl" : "https://twitter.com/i/web/status/1372786197433438214"
    }
  },
  {
    "like" : {
      "tweetId" : "1366717616233066504",
      "fullText" : "Registration for the Open-Source Tools for Chemistry Workshops is now open: https://t.co/W2VTKAqqoP\n\n4 workshops between March and June\n\n⏺️ChimeraX \n⏺️Chemical Structure Validation/Standardisation\n⏺️GNINA 1.0: Molecular Docking with Deep Learning\n⏺️Advanced DataWarrior\n\nMore👇",
      "expandedUrl" : "https://twitter.com/i/web/status/1366717616233066504"
    }
  },
  {
    "like" : {
      "tweetId" : "1367235927949537281",
      "fullText" : "This really is a fabulous table by @EricTopol on three common variants of concern https://t.co/71jNHQl7OU",
      "expandedUrl" : "https://twitter.com/i/web/status/1367235927949537281"
    }
  },
  {
    "like" : {
      "tweetId" : "1367070284977745928",
      "fullText" : "I've been browsing the GitHub repo of @OSantibiotics maintained by @MatToddChem and @macinchem 🚀. Found a handy guide on how to financially support #opensource projects. https://t.co/7MhN1O6SIn (38 contributors 🤩) cc @ersiliaio",
      "expandedUrl" : "https://twitter.com/i/web/status/1367070284977745928"
    }
  },
  {
    "like" : {
      "tweetId" : "1365374983472635904",
      "fullText" : "@MatToddChem @MrBenGP @DNDi_Portugues @JardaKratz @rsc_medchem @OSantibiotics @LoriFerrins @macinchem @dana_klug @mfernflower Great! Let`s work on it...it'll be great @MatToddChem @MrBenGP @LoriFerrins and colleagues @MrBenGP if needed put all team in touch, please!",
      "expandedUrl" : "https://twitter.com/i/web/status/1365374983472635904"
    }
  },
  {
    "like" : {
      "tweetId" : "1362748161119449094",
      "fullText" : "New results for @OSantibiotics Series 2 compounds and tox data to discuss today! Join us at 2pm London time; link and agenda here: https://t.co/D1rRSRPkO4\n#AMR #OpenScience https://t.co/PLg4ha4rY3",
      "expandedUrl" : "https://twitter.com/i/web/status/1362748161119449094"
    }
  },
  {
    "like" : {
      "tweetId" : "1361508208112787461",
      "fullText" : "The New England NTD Consortium is organizing a webinar to discuss the Vision &amp; Implementation of the #NTD #Roadmap to 2030. Join us on Feb 25th at 12pm EST to hear from Dr. Argaw Dagne, Dr. Mwinzi, &amp; Dr. Karutu. Register today! https://t.co/8mEw0qA342 @BU_Tweets @Northeastern https://t.co/kPDPBXLgHv",
      "expandedUrl" : "https://twitter.com/i/web/status/1361508208112787461"
    }
  },
  {
    "like" : {
      "tweetId" : "1361219067437330433",
      "fullText" : "Interesting thread👇🏻 - where is the clinical need for the next new antibiotic? Is it for hospital use or community (or both)? https://t.co/ybHbMO7dVr",
      "expandedUrl" : "https://twitter.com/i/web/status/1361219067437330433"
    }
  },
  {
    "like" : {
      "tweetId" : "1359531074825707527",
      "fullText" : "Just completed my @School_Pharmacy (virtual) Yr4 MPharm project poster presentation! Getting used to the new ways of working. Really appreciate all the help from Prof @MatToddChem and @OSantibiotics! :) https://t.co/9vyVMsBcn3",
      "expandedUrl" : "https://twitter.com/i/web/status/1359531074825707527"
    }
  },
  {
    "like" : {
      "tweetId" : "1355642399507304453",
      "fullText" : "@MatToddChem Just updated @OSantibiotics Series 2 meeting page from yesterday - hopefully we can get in contact with Paul Stapleton soon!",
      "expandedUrl" : "https://twitter.com/i/web/status/1355642399507304453"
    }
  },
  {
    "like" : {
      "tweetId" : "1346096912911523844",
      "fullText" : "Trying @github as blog. First up a question: what are the best guidelines for donating molecules to #openscience projects? https://t.co/UumycWhZIu featuring @thesgconline @biobricks #openmta @LoriFerrins @DNDi @MrBenGP @OSantibiotics @O_S_M @macinchem Suggestions super welcome https://t.co/9lX19ZLLc9",
      "expandedUrl" : "https://twitter.com/i/web/status/1346096912911523844"
    }
  },
  {
    "like" : {
      "tweetId" : "1332346693803761666",
      "fullText" : "Read about the OpenSource Antibiotics projects. https://t.co/TJ61hlwavo All the structures of the molecules on the project are openly available in a spreadsheet https://t.co/sdFjMckWSx",
      "expandedUrl" : "https://twitter.com/i/web/status/1332346693803761666"
    }
  },
  {
    "like" : {
      "tweetId" : "1324129857182134272",
      "fullText" : "@OSantibiotics please consider submitting a talk to @linuxconfau - CFP closes tomorrow.",
      "expandedUrl" : "https://twitter.com/i/web/status/1324129857182134272"
    }
  },
  {
    "like" : {
      "tweetId" : "1321777262904156160",
      "fullText" : "I &lt;3 compound 865. Oh and 871, from @DNDi (thank you). https://t.co/zKnlVDfmgT",
      "expandedUrl" : "https://twitter.com/i/web/status/1321777262904156160"
    }
  },
  {
    "like" : {
      "tweetId" : "1321226153177305090",
      "fullText" : "@OSantibiotics @PaulHergie Great to see, I recommend checking out our SMILES-based website https://t.co/E1YK0Z1ROC for a start! \n\n(full publication on EntryWay: https://t.co/KocvvMHJCM)\n\nalso tagging someone on the Antibac. team @RJUlrich12 \n\nBest of luck!",
      "expandedUrl" : "https://twitter.com/i/web/status/1321226153177305090"
    }
  },
  {
    "like" : {
      "tweetId" : "1318640771956965376",
      "fullText" : "@dana_klug I found the recipe for the boc removal mix @MatToddChem used back in the day - It's a solution of 5% TFA and 5% Triisopropylsilane in dichloromethane\n\nAnother silicon containing mixture is reported here: https://t.co/ZYjfEOGvUw",
      "expandedUrl" : "https://twitter.com/i/web/status/1318640771956965376"
    }
  },
  {
    "like" : {
      "tweetId" : "1317012940952899585",
      "fullText" : "@OSantibiotics @School_Pharmacy @PDBeurope this may be of help\n\nhttps://t.co/yaFL2T31u7",
      "expandedUrl" : "https://twitter.com/i/web/status/1317012940952899585"
    }
  },
  {
    "like" : {
      "tweetId" : "1317033480451248129",
      "fullText" : "@mfernflower Looks promising, thank you so much!",
      "expandedUrl" : "https://twitter.com/i/web/status/1317033480451248129"
    }
  },
  {
    "like" : {
      "tweetId" : "1304195838378471424",
      "fullText" : "@OSantibiotics @MatToddChem @School_Pharmacy I should be able to attend",
      "expandedUrl" : "https://twitter.com/i/web/status/1304195838378471424"
    }
  },
  {
    "like" : {
      "tweetId" : "1304338498749693952",
      "fullText" : "@OSantibiotics @School_Pharmacy Good stuff - but after  ~ 10 mins I could only get to a structure for  SB-400868 via ChEMBL. I'm sure the SMILES/ InChis  for those 9 are somewhere (I found an IUPAC image in DKs notebook) but could you make it a bit more obvious?  (pro tip, drop that  hyphen from your IDs?) https://t.co/XhTgPpojwH",
      "expandedUrl" : "https://twitter.com/i/web/status/1304338498749693952"
    }
  },
  {
    "like" : {
      "tweetId" : "1289116524528181248",
      "fullText" : "Next @OSantibiotics Series 2 Zoom meeting is TODAY at 2pm London time! Everyone welcome, details here: https://t.co/SxZqOmfnAZ #openscience #opensourcedrugdiscovery #AMR",
      "expandedUrl" : "https://twitter.com/i/web/status/1289116524528181248"
    }
  },
  {
    "like" : {
      "tweetId" : "1283518603313188864",
      "fullText" : "DASH PUBLISHED💥💥 #CID @DrToddLee\nAmong patients with MSSA bloodstream infections, the administration of adjunctive daptomycin therapy to standard of care treatment did NOT shorten the duration of bacteremia and should not be routinely considered. https://t.co/obCAhdm6td https://t.co/x6IO9iyQqE",
      "expandedUrl" : "https://twitter.com/i/web/status/1283518603313188864"
    }
  },
  {
    "like" : {
      "tweetId" : "1284404708766093312",
      "fullText" : "It's time to fix the antibiotic market. Governments must act now to safeguard the world's supply of new antibiotics #StopSuperbugs – says @wellcometrust https://t.co/oJ0DNUAw9I",
      "expandedUrl" : "https://twitter.com/i/web/status/1284404708766093312"
    }
  },
  {
    "like" : {
      "tweetId" : "1273965515942354945",
      "fullText" : "Computational Tools for Drug Discovery Workshops https://t.co/ICBz92xayd",
      "expandedUrl" : "https://twitter.com/i/web/status/1273965515942354945"
    }
  },
  {
    "like" : {
      "tweetId" : "1243579196397551622",
      "fullText" : "Fabulous result https://t.co/bkdXD1H4Wv",
      "expandedUrl" : "https://twitter.com/i/web/status/1243579196397551622"
    }
  },
  {
    "like" : {
      "tweetId" : "1240318572968259584",
      "fullText" : "Calling all medicinal chemists! We released ~60 structures of fragments bound to the Mpro #SARS_COV_2.   https://t.co/eaivngBZOh We are crowdsourcing ideas for what to synthesise and test next https://t.co/Iimh3TWgZV you design it and we'll test the best designs. please RT!",
      "expandedUrl" : "https://twitter.com/i/web/status/1240318572968259584"
    }
  },
  {
    "like" : {
      "tweetId" : "1237106997037760513",
      "fullText" : "Another great roundup - Pandemic preparedness, COVID-19, AMR and treatment failure and more! ⁦@CDDEP⁩  https://t.co/znrQ81M4Ig",
      "expandedUrl" : "https://twitter.com/i/web/status/1237106997037760513"
    }
  },
  {
    "like" : {
      "tweetId" : "1234491912775782400",
      "fullText" : "It's an extraordinary coincidence. But for me, the most powerful bit of the original tv prog was this: \n\nThis is our 2018 simulation of the difference that everyone washing their hands 5-10 times a day might make to the spread of a flu-like virus. \n\nSee how much time it buys us? https://t.co/i19cqpjZua",
      "expandedUrl" : "https://twitter.com/i/web/status/1234491912775782400"
    }
  },
  {
    "like" : {
      "tweetId" : "1234841355467264001",
      "fullText" : "The details on the retrosynthetic engine driving the design of chemical synthesis ⚗️🧪on #rxnforchemistry is now online: https://t.co/6EAJ8C7GfS on @ChemicalScience.",
      "expandedUrl" : "https://twitter.com/i/web/status/1234841355467264001"
    }
  },
  {
    "like" : {
      "tweetId" : "1218177285364293632",
      "fullText" : "If the current system isn't delivering, try something new. https://t.co/R3xcslE48X",
      "expandedUrl" : "https://twitter.com/i/web/status/1218177285364293632"
    }
  },
  {
    "like" : {
      "tweetId" : "1217786074669301761",
      "fullText" : "📢 SCI &amp; @RoySocChem Workshop on Computational Tools for #drugdiscovery \n\nRegister now to try out software packages with expert tuition from vendors: @ccdc_cambridge, @cressetgroup, @knime, @MedChemica @OpenEyeSoftware, @Optibrium\n\n💻 https://t.co/AxFIqoTwYB https://t.co/B5x3zqpewk",
      "expandedUrl" : "https://twitter.com/i/web/status/1217786074669301761"
    }
  },
  {
    "like" : {
      "tweetId" : "1204024481246859264",
      "fullText" : "Do you and your family want a future where #antibiotics work and cure #pneumonia, UTIs and even infected scratches? Here's how... https://t.co/haNEl8T5JR #animation #cartoon #film https://t.co/AzYjN5w5Fv",
      "expandedUrl" : "https://twitter.com/i/web/status/1204024481246859264"
    }
  },
  {
    "like" : {
      "tweetId" : "1202695040906252289",
      "fullText" : "@Fahima_Chem @MatToddChem @dana_klug @OSantibiotics @DiamondLightSou In case it's of interest, here's a talk on hydrogen bonding that I did last week (5/N) https://t.co/Dz4wiXGoLd",
      "expandedUrl" : "https://twitter.com/i/web/status/1202695040906252289"
    }
  },
  {
    "like" : {
      "tweetId" : "1191092489761017862",
      "fullText" : "Raising Awareness of #AMR in World Antibiotic Awareness Week. Public lecture by @BSACPresident Prof Philip Howard on 20th Nov @UniofBradford Pls help PT!\n@AntibioticLeeds @ABsteward  @BSACandJAC @AntibioticResis @TheUrgentNeed @LeedsHospitals @HCAILeeds @500MilesBy4Feet @UoBPaMS https://t.co/zu4pgdV7Dx",
      "expandedUrl" : "https://twitter.com/i/web/status/1191092489761017862"
    }
  },
  {
    "like" : {
      "tweetId" : "1191269125244542976",
      "fullText" : "“Health officials are preparing to release new guidance stressing the need for doctors to ask every patient with an apparent respiratory infection about their #vaping history” https://t.co/FLC8cdiJ2u  #antibiotics",
      "expandedUrl" : "https://twitter.com/i/web/status/1191269125244542976"
    }
  },
  {
    "like" : {
      "tweetId" : "1187630286416121861",
      "fullText" : "Hi all, we're running an antibiotic discovery workshop on Thurs Nov 7 as part of the upcoming National AMR forum in Brisbane on Friday Nov 8th.\nRegister at https://t.co/QRKywraywg\n@COADD_news @UQ_News  @IMBatUQ \n\n#drugresistantinfections  #AntimicrobialResistance https://t.co/68c9wmP9uW",
      "expandedUrl" : "https://twitter.com/i/web/status/1187630286416121861"
    }
  },
  {
    "like" : {
      "tweetId" : "1185900908883918849",
      "fullText" : "Loving @AbdulElSayed’s  #AmericaDissected podcast, esp the latest ep about superbugs. Once you’ve listened, check out @OSantibiotics to learn about our #opensource drug discovery for new antibiotics!",
      "expandedUrl" : "https://twitter.com/i/web/status/1185900908883918849"
    }
  },
  {
    "like" : {
      "tweetId" : "1184757073311096832",
      "fullText" : "I liked the quote someone mentioned at #BeilsteinOS2019 \"The nice thing about standards is that there are so many to choose from\" - was that in @csteinbeck talk? Who was source?",
      "expandedUrl" : "https://twitter.com/i/web/status/1184757073311096832"
    }
  },
  {
    "like" : {
      "tweetId" : "1184423577027858433",
      "fullText" : "@ChemMedChem @MatToddChem @ucl @O_S_M @OSPInfo @MycetOS @OSantibiotics Makes a lot of sense for charity/taxpayer funded#DrugDiscovery but how to attract commercial funding? How will project termination decisions be made? Need more clarity as what constitutes 'source' (e.g. physical samples).",
      "expandedUrl" : "https://twitter.com/i/web/status/1184423577027858433"
    }
  },
  {
    "like" : {
      "tweetId" : "1184373415924453376",
      "fullText" : "Mat Todd (@mattoddchem @ucl) shares his thoughts on open source #drugdiscovery &amp; \"Six Laws\" that could guide #openscience practitioners. @O_S_M @OSPInfo @MycetOS @OSantibiotics #opensource #openaccess #pharma #OpenAccessWeek #OAweek #OA #opensourcescience\n\nhttps://t.co/6xIOFuSqOl https://t.co/sKaKeSV8VU",
      "expandedUrl" : "https://twitter.com/i/web/status/1184373415924453376"
    }
  },
  {
    "like" : {
      "tweetId" : "1183729111287644162",
      "fullText" : "“There has been a worrying lack of progress on some of the critical recommendations from the original document, including the development of incentives for researching new #antibiotics, #vaccines and diagnostics” https://t.co/BGZZmObApU",
      "expandedUrl" : "https://twitter.com/i/web/status/1183729111287644162"
    }
  },
  {
    "like" : {
      "tweetId" : "1170617585169309696",
      "fullText" : "Starting something similar in Antibiotics area https://t.co/gNOzUGhlls early days but since it is a fragment based project could be opportunity for students to make simple compounds to test? https://t.co/6OjySU2TbZ",
      "expandedUrl" : "https://twitter.com/i/web/status/1170617585169309696"
    }
  },
  {
    "like" : {
      "tweetId" : "1167952612861169664",
      "fullText" : "On my way to @RoySocChem #AI in Chemistry symposium (2nd RSC-BMCS / RSC-CICAG\nArtificial Intelligence in Chemistry) #AIChem19 across the pond in Cambridge, UK! https://t.co/ztR1LlaXe6",
      "expandedUrl" : "https://twitter.com/i/web/status/1167952612861169664"
    }
  },
  {
    "like" : {
      "tweetId" : "1168132758671114241",
      "fullText" : "More media interest in #antibiotics resistance over the weekend – keep pressing the case and raising awareness reporter-friends! ANTRUK comment available on 0759 202 8142 https://t.co/fKuRCnT4lq",
      "expandedUrl" : "https://twitter.com/i/web/status/1168132758671114241"
    }
  },
  {
    "like" : {
      "tweetId" : "1167703537742241792",
      "fullText" : "Yay! We reached our target! Enormously grateful to everyone who donated, shared, tweeted @TomBSpencer @DrDianeAshiru @WinterJody @Linda4Gibson @lubegaluv @_Beth_Ward @drcjlittle #antibioticguardians #antimicrobialstewardship #globalproblems https://t.co/oMvQjJHVUV",
      "expandedUrl" : "https://twitter.com/i/web/status/1167703537742241792"
    }
  },
  {
    "like" : {
      "tweetId" : "1167681566971219971",
      "fullText" : "Just getting the lanyards ready for #AIChem19 https://t.co/egypm1IQvL https://t.co/ppxAQl2jYB",
      "expandedUrl" : "https://twitter.com/i/web/status/1167681566971219971"
    }
  },
  {
    "like" : {
      "tweetId" : "1158443970076258304",
      "fullText" : "Still a few places left for the AI in Chemistry Meeting in Cambridge 2nd to 3rd September 2019.  Shaping up to be a fantastic meeting.  https://t.co/egypm1IQvL #AIChem19",
      "expandedUrl" : "https://twitter.com/i/web/status/1158443970076258304"
    }
  },
  {
    "like" : {
      "tweetId" : "1156244168429228032",
      "fullText" : "Superbugs resistant to emergency #antibiotics are spreading in hospitals, a Europe-wide study shows @sangerinstitute #AMR #AntibioticResistance https://t.co/9i1VGGYx2Q",
      "expandedUrl" : "https://twitter.com/i/web/status/1156244168429228032"
    }
  },
  {
    "like" : {
      "tweetId" : "1150740240174333953",
      "fullText" : "We have had a significant unallocated student bursaries for both @RSC_BMCS and @RSC_CICAG meetings over the last few years and we would like to find out why? @RoySocChem #bursaries",
      "expandedUrl" : "https://twitter.com/i/web/status/1150740240174333953"
    }
  },
  {
    "like" : {
      "tweetId" : "1148245885857476610",
      "fullText" : "Fun session talking about @OSantibiotics with @macinchem and @Fahima_Chem at @School_Pharmacy - which compounds to make next in the #fbdd project vs. Mur ligases https://t.co/k05GB2XpwB #openscience #antibiotics @gardp_amr @Wellcome_AMR https://t.co/x1qCbQwOZ2",
      "expandedUrl" : "https://twitter.com/i/web/status/1148245885857476610"
    }
  },
  {
    "like" : {
      "tweetId" : "1141646767236308992",
      "fullText" : "The #MELLODDY @IMI_JU consortium members say au revoir Paris following 2 days of workshops #machinelearning #drugdiscovery. We look forward to sharing project findings throughout our 3-yr journey https://t.co/Meif6ZiUa8",
      "expandedUrl" : "https://twitter.com/i/web/status/1141646767236308992"
    }
  },
  {
    "like" : {
      "tweetId" : "1140923537185787909",
      "fullText" : "A chance for everyone to contribute https://t.co/zoeBgwglxx",
      "expandedUrl" : "https://twitter.com/i/web/status/1140923537185787909"
    }
  },
  {
    "like" : {
      "tweetId" : "1140922301573148674",
      "fullText" : "Awesome way to visualise the bound fragments and design improvements. https://t.co/GMZnHqAREE",
      "expandedUrl" : "https://twitter.com/i/web/status/1140922301573148674"
    }
  },
  {
    "like" : {
      "tweetId" : "1134394615178682368",
      "fullText" : "@heluc @marynmck @WIRED @PeterRolandG Yes, need new models. Made a small start with @OSantibiotics and early stage project at https://t.co/MmLj4EtC8s with @thesgconline @macinchem and others. Seeking inputs and $ #openscience",
      "expandedUrl" : "https://twitter.com/i/web/status/1134394615178682368"
    }
  },
  {
    "like" : {
      "tweetId" : "1139512343983992833",
      "fullText" : "NEW 🔥large cohort @ICHEJournal by @eliowa isolated fluoroquinolone resistance had a larger impact on mortality than any other antibiotic\nphenotypic resistance pattern in hospital onset bacteremia caused by E. coli and Klebsiella spp.\n https://t.co/r2kYgGRgTM https://t.co/Skgdhkuoqw",
      "expandedUrl" : "https://twitter.com/i/web/status/1139512343983992833"
    }
  },
  {
    "like" : {
      "tweetId" : "1127943975443337216",
      "fullText" : "In which area is Artificial Intelligence likely to most impact Chemistry, #AIChem19",
      "expandedUrl" : "https://twitter.com/i/web/status/1127943975443337216"
    }
  },
  {
    "like" : {
      "tweetId" : "1123583180898881536",
      "fullText" : "Practical Fragments ventures on to Twitter. \nOpenSourceAntibiotics has hits against 2 enzymes bacteria need to make cell walls. What should they do next?  #FBDD #FBLD    \nhttps://t.co/TClFZRaPSc\n@macinchem @OSantibiotics @chem4biology @Dereklowe @zenbrainest  @QuantumTessera",
      "expandedUrl" : "https://twitter.com/i/web/status/1123583180898881536"
    }
  },
  {
    "like" : {
      "tweetId" : "1118850879359266816",
      "fullText" : "@OSantibiotics @thesgconline @macinchem @WarwickLifeSci @MatToddChem @gardp_amr @COADD_news @Wellcome_AMR Thought I'd pitch in with a patent search that might have  just come up with some useful SAR,  but these look rather stale beer :( https://t.co/WXFrqNlkKH",
      "expandedUrl" : "https://twitter.com/i/web/status/1118850879359266816"
    }
  },
  {
    "like" : {
      "tweetId" : "1118903445677854720",
      "fullText" : "@MrBenGP @biosolveit @OSantibiotics @TheUrgentNeed @APPGantibiotics @EnamineLtd Why not run a competition. Use the software to nominate fragments, biosolveit staff select what they think are the top ten choices. Then buy them and put them in for testing.",
      "expandedUrl" : "https://twitter.com/i/web/status/1118903445677854720"
    }
  },
  {
    "like" : {
      "tweetId" : "1117270047112691712",
      "fullText" : "Editorial:  JAC-Antimicrobial Resistance  ( JAC-AMR ) a novel open access journal for research and education https://t.co/xQ2RxYWTnL",
      "expandedUrl" : "https://twitter.com/i/web/status/1117270047112691712"
    }
  },
  {
    "like" : {
      "tweetId" : "1118804476306104321",
      "fullText" : "@OSantibiotics @macinchem @TheUrgentNeed @APPGantibiotics 💡: Suggest to d'load free test pkg of https://t.co/3YvCIMgWbO, search 5.1bn(!) @EnamineLtd REAL _Space_ (&gt;&gt; REAL _database_) and do 🍒 picking from there. Delivery approx 3wks with 80%+ success. Pls keep us posted. Thx &amp; good luck!",
      "expandedUrl" : "https://twitter.com/i/web/status/1118804476306104321"
    }
  }
]