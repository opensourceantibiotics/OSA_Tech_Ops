window.YTD.profile.part0 = [
  {
    "profile" : {
      "description" : {
        "bio" : "Open Source Antibiotics. A consortium of researchers interested in open ways to discover new, inexpensive medicines for bacterial infections. Join in!",
        "website" : "https://t.co/vUhmJmIdHn",
        "location" : ""
      },
      "avatarMediaUrl" : "https://pbs.twimg.com/profile_images/1315670322302124032/S7kZMrAR.jpg",
      "headerMediaUrl" : "https://pbs.twimg.com/profile_banners/1111629854716428290/1555448769"
    }
  }
]