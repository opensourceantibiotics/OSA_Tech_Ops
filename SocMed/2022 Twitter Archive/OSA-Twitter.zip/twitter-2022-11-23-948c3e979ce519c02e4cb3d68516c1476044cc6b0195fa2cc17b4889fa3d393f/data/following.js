window.YTD.following.part0 = [
  {
    "following" : {
      "accountId" : "1046768372258689024",
      "userLink" : "https://twitter.com/intent/user?user_id=1046768372258689024"
    }
  },
  {
    "following" : {
      "accountId" : "3157469154",
      "userLink" : "https://twitter.com/intent/user?user_id=3157469154"
    }
  },
  {
    "following" : {
      "accountId" : "819215192265519104",
      "userLink" : "https://twitter.com/intent/user?user_id=819215192265519104"
    }
  },
  {
    "following" : {
      "accountId" : "1120536353853386753",
      "userLink" : "https://twitter.com/intent/user?user_id=1120536353853386753"
    }
  },
  {
    "following" : {
      "accountId" : "189406922",
      "userLink" : "https://twitter.com/intent/user?user_id=189406922"
    }
  },
  {
    "following" : {
      "accountId" : "1219517216",
      "userLink" : "https://twitter.com/intent/user?user_id=1219517216"
    }
  },
  {
    "following" : {
      "accountId" : "54017848",
      "userLink" : "https://twitter.com/intent/user?user_id=54017848"
    }
  },
  {
    "following" : {
      "accountId" : "1303099789",
      "userLink" : "https://twitter.com/intent/user?user_id=1303099789"
    }
  },
  {
    "following" : {
      "accountId" : "1254305675192270848",
      "userLink" : "https://twitter.com/intent/user?user_id=1254305675192270848"
    }
  },
  {
    "following" : {
      "accountId" : "303773007",
      "userLink" : "https://twitter.com/intent/user?user_id=303773007"
    }
  },
  {
    "following" : {
      "accountId" : "76638761",
      "userLink" : "https://twitter.com/intent/user?user_id=76638761"
    }
  },
  {
    "following" : {
      "accountId" : "19492668",
      "userLink" : "https://twitter.com/intent/user?user_id=19492668"
    }
  },
  {
    "following" : {
      "accountId" : "27608329",
      "userLink" : "https://twitter.com/intent/user?user_id=27608329"
    }
  },
  {
    "following" : {
      "accountId" : "3306638471",
      "userLink" : "https://twitter.com/intent/user?user_id=3306638471"
    }
  },
  {
    "following" : {
      "accountId" : "2982937749",
      "userLink" : "https://twitter.com/intent/user?user_id=2982937749"
    }
  },
  {
    "following" : {
      "accountId" : "2813287229",
      "userLink" : "https://twitter.com/intent/user?user_id=2813287229"
    }
  },
  {
    "following" : {
      "accountId" : "190230750",
      "userLink" : "https://twitter.com/intent/user?user_id=190230750"
    }
  },
  {
    "following" : {
      "accountId" : "1335895459680956417",
      "userLink" : "https://twitter.com/intent/user?user_id=1335895459680956417"
    }
  },
  {
    "following" : {
      "accountId" : "1175350863713447936",
      "userLink" : "https://twitter.com/intent/user?user_id=1175350863713447936"
    }
  },
  {
    "following" : {
      "accountId" : "829433776073764864",
      "userLink" : "https://twitter.com/intent/user?user_id=829433776073764864"
    }
  },
  {
    "following" : {
      "accountId" : "409363557",
      "userLink" : "https://twitter.com/intent/user?user_id=409363557"
    }
  },
  {
    "following" : {
      "accountId" : "2842832303",
      "userLink" : "https://twitter.com/intent/user?user_id=2842832303"
    }
  },
  {
    "following" : {
      "accountId" : "1953942966",
      "userLink" : "https://twitter.com/intent/user?user_id=1953942966"
    }
  },
  {
    "following" : {
      "accountId" : "3940619555",
      "userLink" : "https://twitter.com/intent/user?user_id=3940619555"
    }
  },
  {
    "following" : {
      "accountId" : "1110466603710324736",
      "userLink" : "https://twitter.com/intent/user?user_id=1110466603710324736"
    }
  },
  {
    "following" : {
      "accountId" : "722086409599848450",
      "userLink" : "https://twitter.com/intent/user?user_id=722086409599848450"
    }
  },
  {
    "following" : {
      "accountId" : "1389581126503706628",
      "userLink" : "https://twitter.com/intent/user?user_id=1389581126503706628"
    }
  },
  {
    "following" : {
      "accountId" : "805025179",
      "userLink" : "https://twitter.com/intent/user?user_id=805025179"
    }
  },
  {
    "following" : {
      "accountId" : "450384442",
      "userLink" : "https://twitter.com/intent/user?user_id=450384442"
    }
  },
  {
    "following" : {
      "accountId" : "1017479731472723969",
      "userLink" : "https://twitter.com/intent/user?user_id=1017479731472723969"
    }
  },
  {
    "following" : {
      "accountId" : "536409536",
      "userLink" : "https://twitter.com/intent/user?user_id=536409536"
    }
  },
  {
    "following" : {
      "accountId" : "2997727057",
      "userLink" : "https://twitter.com/intent/user?user_id=2997727057"
    }
  },
  {
    "following" : {
      "accountId" : "2804352177",
      "userLink" : "https://twitter.com/intent/user?user_id=2804352177"
    }
  },
  {
    "following" : {
      "accountId" : "1106120948934209536",
      "userLink" : "https://twitter.com/intent/user?user_id=1106120948934209536"
    }
  },
  {
    "following" : {
      "accountId" : "423373977",
      "userLink" : "https://twitter.com/intent/user?user_id=423373977"
    }
  },
  {
    "following" : {
      "accountId" : "1189170398207926272",
      "userLink" : "https://twitter.com/intent/user?user_id=1189170398207926272"
    }
  },
  {
    "following" : {
      "accountId" : "14252342",
      "userLink" : "https://twitter.com/intent/user?user_id=14252342"
    }
  },
  {
    "following" : {
      "accountId" : "55243439",
      "userLink" : "https://twitter.com/intent/user?user_id=55243439"
    }
  },
  {
    "following" : {
      "accountId" : "2570913493",
      "userLink" : "https://twitter.com/intent/user?user_id=2570913493"
    }
  },
  {
    "following" : {
      "accountId" : "2855320951",
      "userLink" : "https://twitter.com/intent/user?user_id=2855320951"
    }
  },
  {
    "following" : {
      "accountId" : "1396787767544328198",
      "userLink" : "https://twitter.com/intent/user?user_id=1396787767544328198"
    }
  },
  {
    "following" : {
      "accountId" : "189868631",
      "userLink" : "https://twitter.com/intent/user?user_id=189868631"
    }
  },
  {
    "following" : {
      "accountId" : "35873707",
      "userLink" : "https://twitter.com/intent/user?user_id=35873707"
    }
  },
  {
    "following" : {
      "accountId" : "3084793295",
      "userLink" : "https://twitter.com/intent/user?user_id=3084793295"
    }
  },
  {
    "following" : {
      "accountId" : "2530098408",
      "userLink" : "https://twitter.com/intent/user?user_id=2530098408"
    }
  },
  {
    "following" : {
      "accountId" : "731545620520030210",
      "userLink" : "https://twitter.com/intent/user?user_id=731545620520030210"
    }
  },
  {
    "following" : {
      "accountId" : "3182481331",
      "userLink" : "https://twitter.com/intent/user?user_id=3182481331"
    }
  },
  {
    "following" : {
      "accountId" : "110283849",
      "userLink" : "https://twitter.com/intent/user?user_id=110283849"
    }
  },
  {
    "following" : {
      "accountId" : "1270709401192718337",
      "userLink" : "https://twitter.com/intent/user?user_id=1270709401192718337"
    }
  },
  {
    "following" : {
      "accountId" : "735152474538049536",
      "userLink" : "https://twitter.com/intent/user?user_id=735152474538049536"
    }
  },
  {
    "following" : {
      "accountId" : "825110000972464128",
      "userLink" : "https://twitter.com/intent/user?user_id=825110000972464128"
    }
  },
  {
    "following" : {
      "accountId" : "1202241406615588864",
      "userLink" : "https://twitter.com/intent/user?user_id=1202241406615588864"
    }
  },
  {
    "following" : {
      "accountId" : "1111596784978149376",
      "userLink" : "https://twitter.com/intent/user?user_id=1111596784978149376"
    }
  },
  {
    "following" : {
      "accountId" : "1051819040379953153",
      "userLink" : "https://twitter.com/intent/user?user_id=1051819040379953153"
    }
  },
  {
    "following" : {
      "accountId" : "3151901774",
      "userLink" : "https://twitter.com/intent/user?user_id=3151901774"
    }
  },
  {
    "following" : {
      "accountId" : "162018067",
      "userLink" : "https://twitter.com/intent/user?user_id=162018067"
    }
  },
  {
    "following" : {
      "accountId" : "28023025",
      "userLink" : "https://twitter.com/intent/user?user_id=28023025"
    }
  },
  {
    "following" : {
      "accountId" : "1131887774527840256",
      "userLink" : "https://twitter.com/intent/user?user_id=1131887774527840256"
    }
  },
  {
    "following" : {
      "accountId" : "1094656135074697217",
      "userLink" : "https://twitter.com/intent/user?user_id=1094656135074697217"
    }
  },
  {
    "following" : {
      "accountId" : "342023138",
      "userLink" : "https://twitter.com/intent/user?user_id=342023138"
    }
  },
  {
    "following" : {
      "accountId" : "418583301",
      "userLink" : "https://twitter.com/intent/user?user_id=418583301"
    }
  },
  {
    "following" : {
      "accountId" : "1088022968628924421",
      "userLink" : "https://twitter.com/intent/user?user_id=1088022968628924421"
    }
  },
  {
    "following" : {
      "accountId" : "21448858",
      "userLink" : "https://twitter.com/intent/user?user_id=21448858"
    }
  },
  {
    "following" : {
      "accountId" : "1174233288",
      "userLink" : "https://twitter.com/intent/user?user_id=1174233288"
    }
  },
  {
    "following" : {
      "accountId" : "1951791067",
      "userLink" : "https://twitter.com/intent/user?user_id=1951791067"
    }
  },
  {
    "following" : {
      "accountId" : "2758766167",
      "userLink" : "https://twitter.com/intent/user?user_id=2758766167"
    }
  },
  {
    "following" : {
      "accountId" : "3292777305",
      "userLink" : "https://twitter.com/intent/user?user_id=3292777305"
    }
  },
  {
    "following" : {
      "accountId" : "398581149",
      "userLink" : "https://twitter.com/intent/user?user_id=398581149"
    }
  },
  {
    "following" : {
      "accountId" : "1549966591",
      "userLink" : "https://twitter.com/intent/user?user_id=1549966591"
    }
  },
  {
    "following" : {
      "accountId" : "1080448066165985281",
      "userLink" : "https://twitter.com/intent/user?user_id=1080448066165985281"
    }
  },
  {
    "following" : {
      "accountId" : "3045189728",
      "userLink" : "https://twitter.com/intent/user?user_id=3045189728"
    }
  }
]