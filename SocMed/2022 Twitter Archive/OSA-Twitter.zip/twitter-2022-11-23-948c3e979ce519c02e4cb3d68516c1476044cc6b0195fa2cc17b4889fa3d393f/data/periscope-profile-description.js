window.YTD.periscope_profile_description.part0 = [
  {
    "periscopeProfileDescription" : {
      "bio" : "Open Source Antibiotics. A consortium of researchers interested in open ways to discover new, inexpensive medicines for bacterial infections. Join in!"
    }
  }
]