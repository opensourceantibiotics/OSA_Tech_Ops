window.YTD.device_token.part0 = [
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "Wq8HVefc1050cZOJ8ICglHhf3zsLfh3ejWZO3tpv",
      "createdAt" : "2022-08-22T13:05:30.404Z",
      "lastSeenAt" : "2022-08-22T13:05:30.406Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "z6kSDC6bJtoDJsXnvOIlmZPHhCbM40ZQwMNiM991",
      "createdAt" : "2022-11-18T16:37:47.100Z",
      "lastSeenAt" : "2022-11-18T16:47:09.033Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  },
  {
    "deviceToken" : {
      "clientApplicationId" : "3033300",
      "token" : "N535yX1rvquw1lG198BcP9UgrV15hvuTitbvPJfJ",
      "createdAt" : "2022-11-19T09:21:46.028Z",
      "lastSeenAt" : "2022-11-19T09:21:46.029Z",
      "clientApplicationName" : "Twitter Web App (Twitter. Inc)"
    }
  }
]