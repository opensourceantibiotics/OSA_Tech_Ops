window.YTD.personalization.part0 = [
  {
    "p13nData" : {
      "demographics" : {
        "languages" : [
          {
            "language" : "English",
            "isDisabled" : false
          }
        ],
        "genderInfo" : {
          "gender" : "female"
        }
      },
      "interests" : {
        "interests" : [
          {
            "name" : "Agriculture",
            "isDisabled" : false
          },
          {
            "name" : "Agriculture trading",
            "isDisabled" : false
          },
          {
            "name" : "Animated films",
            "isDisabled" : false
          },
          {
            "name" : "Animation",
            "isDisabled" : false
          },
          {
            "name" : "Apple",
            "isDisabled" : false
          },
          {
            "name" : "Architecture",
            "isDisabled" : false
          },
          {
            "name" : "BBC",
            "isDisabled" : false
          },
          {
            "name" : "Baking",
            "isDisabled" : false
          },
          {
            "name" : "Barclays Premier League Football",
            "isDisabled" : false
          },
          {
            "name" : "Barclays Premier League Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Biology",
            "isDisabled" : false
          },
          {
            "name" : "Botany",
            "isDisabled" : false
          },
          {
            "name" : "Brazil political events",
            "isDisabled" : false
          },
          {
            "name" : "Brazil political figures",
            "isDisabled" : false
          },
          {
            "name" : "Brazil politics",
            "isDisabled" : false
          },
          {
            "name" : "Business & finance",
            "isDisabled" : false
          },
          {
            "name" : "Business personalities",
            "isDisabled" : false
          },
          {
            "name" : "COVID-19",
            "isDisabled" : false
          },
          {
            "name" : "Chemistry",
            "isDisabled" : false
          },
          {
            "name" : "Computer gaming",
            "isDisabled" : false
          },
          {
            "name" : "Computer programming",
            "isDisabled" : false
          },
          {
            "name" : "Cristiano Ronaldo",
            "isDisabled" : false
          },
          {
            "name" : "Cuisines",
            "isDisabled" : false
          },
          {
            "name" : "Design",
            "isDisabled" : false
          },
          {
            "name" : "Dinner",
            "isDisabled" : false
          },
          {
            "name" : "Discord",
            "isDisabled" : false
          },
          {
            "name" : "Dogs",
            "isDisabled" : false
          },
          {
            "name" : "Drinks",
            "isDisabled" : false
          },
          {
            "name" : "EE",
            "isDisabled" : false
          },
          {
            "name" : "Elizabeth Holmes",
            "isDisabled" : false
          },
          {
            "name" : "Elon Musk",
            "isDisabled" : false
          },
          {
            "name" : "English Premier League Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Entertainment",
            "isDisabled" : false
          },
          {
            "name" : "European cuisine",
            "isDisabled" : false
          },
          {
            "name" : "Events",
            "isDisabled" : false
          },
          {
            "name" : "Family & relationships",
            "isDisabled" : false
          },
          {
            "name" : "Food",
            "isDisabled" : false
          },
          {
            "name" : "GitHub",
            "isDisabled" : false
          },
          {
            "name" : "Greek cuisine",
            "isDisabled" : false
          },
          {
            "name" : "House of Commons",
            "isDisabled" : false
          },
          {
            "name" : "Meals",
            "isDisabled" : false
          },
          {
            "name" : "Movies",
            "isDisabled" : false
          },
          {
            "name" : "News",
            "isDisabled" : false
          },
          {
            "name" : "News outlets",
            "isDisabled" : false
          },
          {
            "name" : "Open source",
            "isDisabled" : false
          },
          {
            "name" : "Philip W. Schiller",
            "isDisabled" : false
          },
          {
            "name" : "Podcasts & radio",
            "isDisabled" : false
          },
          {
            "name" : "Political events",
            "isDisabled" : false
          },
          {
            "name" : "Political figures",
            "isDisabled" : false
          },
          {
            "name" : "Politics",
            "isDisabled" : false
          },
          {
            "name" : "Premier League",
            "isDisabled" : false
          },
          {
            "name" : "Science",
            "isDisabled" : false
          },
          {
            "name" : "Science news",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Soccer",
            "isDisabled" : false
          },
          {
            "name" : "Social media",
            "isDisabled" : false
          },
          {
            "name" : "Space",
            "isDisabled" : false
          },
          {
            "name" : "Space and astronomy",
            "isDisabled" : false
          },
          {
            "name" : "Sporting events",
            "isDisabled" : false
          },
          {
            "name" : "Sports",
            "isDisabled" : false
          },
          {
            "name" : "Sports events",
            "isDisabled" : false
          },
          {
            "name" : "Sports news",
            "isDisabled" : false
          },
          {
            "name" : "Taxes",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Tech news",
            "isDisabled" : false
          },
          {
            "name" : "Tech personalities",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Technology",
            "isDisabled" : false
          },
          {
            "name" : "Tedros Adhanom Ghebreyesus",
            "isDisabled" : false
          },
          {
            "name" : "Television",
            "isDisabled" : false
          },
          {
            "name" : "The Daily Telegraph",
            "isDisabled" : false
          },
          {
            "name" : "The Telegraph",
            "isDisabled" : false
          },
          {
            "name" : "Twitter",
            "isDisabled" : false
          },
          {
            "name" : "UEFA Champions League Soccer",
            "isDisabled" : false
          },
          {
            "name" : "UEFA Champions League Soccer",
            "isDisabled" : false
          },
          {
            "name" : "University of Oxford",
            "isDisabled" : false
          },
          {
            "name" : "Weather",
            "isDisabled" : false
          },
          {
            "name" : "Wine",
            "isDisabled" : false
          },
          {
            "name" : "Wired",
            "isDisabled" : false
          },
          {
            "name" : "YouTube",
            "isDisabled" : false
          }
        ],
        "partnerInterests" : [ ],
        "audienceAndAdvertisers" : {
          "lookalikeAdvertisers" : [
            "@ABEMA",
            "@CoupangEats",
            "@Evony_TKR",
            "@Gemini",
            "@LINEmangaPR",
            "@LinkedIn",
            "@McDonalds_BR",
            "@NieR_Rein",
            "@Omiai_jp",
            "@PetzOficial",
            "@RappiBrasil",
            "@RappiMexico",
            "@Spotify",
            "@TiktokKR",
            "@Uber",
            "@_WinTicket",
            "@bodyfastapp",
            "@gopayindonesia",
            "@houchishoujo",
            "@inDriveBrasil",
            "@mercari_wolf",
            "@piccoma_jp",
            "@tapple_official",
            "@tiktok_kuromame",
            "@tiktok_us",
            "@28dayschallenge",
            "@ABPI_UK",
            "@Athleta",
            "@Atlassian",
            "@BMWUSA",
            "@BestBuy",
            "@CMEGroup",
            "@DellTechUK",
            "@Discovery",
            "@Disneyland",
            "@Drive_pedia",
            "@EYnews",
            "@FoodNetwork",
            "@GoogleWorkspace",
            "@Hallmark",
            "@HomeDepot",
            "@IPSY",
            "@Intuit",
            "@LGUSAMobile",
            "@Lenovo",
            "@LifeSaver_H2020",
            "@LincolnMotorCo",
            "@LumixUSA",
            "@NEOM",
            "@NYCHRA",
            "@NameThatTune",
            "@Nequi",
            "@NintendoAmerica",
            "@NissanLatino",
            "@NissanUSA",
            "@O2",
            "@OldNavy",
            "@PanasonicUK",
            "@PayPalUK",
            "@PayPayBankCorp",
            "@Predator_USA",
            "@RishabhAdvert",
            "@SAPAnalytics",
            "@SpotifyJP",
            "@Spotify_PH",
            "@Starbucks",
            "@TDAmeritrade",
            "@TheDaddest",
            "@TimHortons",
            "@TwitterBlue",
            "@TwitterMktgUK",
            "@VMware",
            "@VelaEdFund",
            "@Venmo",
            "@Wix",
            "@Xero",
            "@asahi_globe",
            "@business",
            "@cbasahi",
            "@chevrolet",
            "@cruelsummer",
            "@digitalocean",
            "@discoveryplus",
            "@dunkindonuts",
            "@eToroFr",
            "@enstars_music",
            "@famitsuApp",
            "@finestqapp",
            "@global_big",
            "@guardian",
            "@hatebu",
            "@hgtv",
            "@hootsuite",
            "@janellebruland",
            "@lipsjp",
            "@lovelink_line",
            "@monmouthu",
            "@nobleaudio_jp",
            "@nytimes",
            "@oneplus",
            "@pr_canadel",
            "@prodigalsonfox",
            "@sega_pso2",
            "@spotifypodcasts",
            "@taimiapp",
            "@vodafone_de",
            "@voice_evidence",
            "@wileyinresearch"
          ],
          "advertisers" : [
            "@ABPI_UK",
            "@DellTechUK",
            "@EYnews",
            "@GoogleWorkspace",
            "@Lenovo",
            "@LifeSaver_H2020",
            "@LumixUSA",
            "@NEOM",
            "@PanasonicUK",
            "@RishabhAdvert",
            "@TwitterBlue",
            "@TwitterMktgUK",
            "@VMware",
            "@pr_canadel",
            "@sega_pso2",
            "@vodafone_de"
          ],
          "doNotReachAdvertisers" : [ ],
          "catalogAudienceAdvertisers" : [ ],
          "numAudiences" : "27"
        },
        "shows" : [
          "Barclays Premier League Football",
          "Barclays Premier League Soccer",
          "English Premier League Soccer",
          "Premier League",
          "UEFA Champions League Soccer"
        ]
      },
      "locationHistory" : [ ],
      "inferredAgeInfo" : {
        "age" : [
          "13-54"
        ],
        "birthDate" : ""
      }
    }
  }
]